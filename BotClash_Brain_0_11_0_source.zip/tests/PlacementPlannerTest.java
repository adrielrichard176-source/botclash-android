import com.botclash.teste.*;
import java.util.*;

public final class PlacementPlannerTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    private static Enemy.Unit unit(String name, float x, float y) {
        return new Enemy.Unit(name, x - 30, y - 70, x + 30, y, .95f);
    }

    public static void main(String[] args) {
        Enemy.Unit flying = unit("flying_machine", 535, 700);
        PlacementPlanner.Point musketeer = PlacementPlanner.defense(11, flying, true,
                Collections.singletonList(flying));
        check(musketeer.x >= 65 && musketeer.x <= 626 && musketeer.y >= 780 && musketeer.y <= 1160,
                "Musketeer placement stays inside the friendly arena");
        check(Math.hypot(musketeer.x - flying.x(), musketeer.y - flying.y()) >= 130,
                "ranged support is not dropped on top of the threat");
        check(musketeer.y > flying.y(), "ranged support is placed behind the threat");

        PlacementPlanner.Point tesla = PlacementPlanner.defense(9, flying, true,
                Collections.singletonList(flying));
        check(Math.abs(tesla.x - 380f) < 1.0f && tesla.y > 800,
                "Tesla uses a central pull zone");

        Enemy.Unit ground = unit("hog_rider", 150, 930);
        PlacementPlanner.Point skeletons = PlacementPlanner.defense(14, ground, false,
                Collections.singletonList(ground));
        check(Math.abs(skeletons.x - ground.x()) > 45 && skeletons.y >= 790,
                "Skeletons are offset to distract instead of stacking on the target");
        System.out.println("PASS role-aware defense placement and ranged-unit separation");
    }
}
