import com.botclash.teste.*;
import java.util.Arrays;

public final class VisionDeckFilterTest {
    public static void main(String[] args) {
        Vision vision = new Vision();
        int[] sample = new int[24 * 28];
        Arrays.fill(sample, 0x334455);
        vision.templates.put("next_0", sample.clone());
        vision.templates.put("next_10", new int[24 * 28]);
        if (vision.matchNext(sample) != 0) {
            throw new AssertionError("next-card recognition must include a local template outside Deck 4");
        }
        System.out.println("PASS local card-template catalog is not artificially restricted to Deck 4");
    }
}
