import com.botclash.teste.*;
import java.util.*;

public class StrategyTest {
 static int checks;
 static void ck(boolean ok,String message){checks++;if(!ok)throw new AssertionError(message);}
 static Vision.Reading hand(int elixir,int... cards){Vision.Reading r=new Vision.Reading();r.valid=true;r.elixir=elixir;r.cards=cards;return r;}
 static Enemy.Unit unit(String name,float x,float y){return new Enemy.Unit(name,x-30,y-70,x+30,y,.95f);}
 static Enemy.Scene scene(long now,Enemy.Unit... units){Enemy.Scene s=new Enemy.Scene();s.time=now;s.units.addAll(Arrays.asList(units));if(units.length>0)s.main=units[0];return s;}
 static Advice.Suggestion opening(Vision.Reading hand){Strategy strategy=new Strategy();Advice.Suggestion out=null;for(long t=0;t<=2000;t+=500)out=strategy.choose(hand,scene(t),t);return out;}
 public static void main(String[] args){
  Advice.Suggestion a=opening(hand(10,10,9,11,-1));ck(a.card==10,"known Hog can attack with one unknown slot");
  a=opening(hand(7,1,9,-1,-1));ck(a.card==1&&a.cost==3,"Barrel opening without enemy action retains four elixir");
  a=opening(hand(6,1,9,-1,-1));ck(a.slot<0,"do not spend the defensive reserve");
  a=opening(hand(9,12,9,11,14));ck(a.card==12&&a.phase.equals("PREPARAR"),"rear preparation without win condition in hand");
  a=opening(hand(10,10,1,13,14));ck(a.slot<0,"cheap cycle cards alone are not a substantial defensive reserve");
  Strategy proactive=new Strategy();Vision.Reading proactiveHand=hand(10,10,9,11,-1);
  Enemy.Unit farEnemy=unit("giant",535,600);Enemy.Scene farScene=scene(0,farEnemy);
  for(long t=0;t<=1000;t+=500)a=proactive.choose(proactiveHand,farScene,t);
  ck(a.card==10&&a.phase.equals("ATACAR")&&a.x<300,
    "a distant opponent setup must not block a proactive Hog attack on the opposite lane");
  Strategy st=new Strategy();Vision.Reading r=hand(10,10,9,11,-1);
  st.choose(r,scene(0),0);st.choose(r,scene(500),500);
  Enemy.Scene blocked=scene(2000);blocked.obstructed=true;ck(st.choose(r,blocked,2000).slot<0,"covered arena cannot imply safe pressure");
  ck(st.choose(r,scene(0),2500).slot<0,"stale results suppressed");
  ck(st.choose(r,scene(3000),2500).slot<0,"future timestamp suppressed");
  Enemy.Unit giant=unit("giant",535,740),witch=unit("witch",145,760),unknown=unit("unknown",145,950);
  a=Defense.choose(hand(10,-1,9,10,1),scene(1000,unknown,giant),1000);ck(a.card==9&&a.target==giant,"known threat in other lane survives uncertainty");
  a=Defense.choose(hand(3,-1,9,10,1),scene(1000,giant),1000);ck(a.slot<0,"never suggest unaffordable Tesla");
  a=Defense.choose(hand(10,10,1,-1,-1),scene(1000,giant),1000);ck(a.slot<0,"offensive-only hand must not pretend defense");
  a=Defense.choose(hand(10,12,8,1,10),scene(1000,unit("balloon",535,760)),1000);ck(a.slot<0,"ground troops cannot defend air");
  a=Defense.choose(hand(5,11,12,1,10),scene(1000,unit("flying_machine",535,550)),1000);ck(a.card==11&&a.phase.equals("PREPARAR"),"air support can be prepared before bridge contact");
  a=Defense.choose(hand(8,6,11,9,1),scene(1000,unit("pekka",145,760),witch),1000);ck(a.slot>=0&&a.card!=6,"splash support blocks swarm defense");
  Enemy.Unit suspect=unit("giant",535,760);suspect.teamUncertain=true;
  ck(Defense.choose(hand(10,9,11,8,14),scene(1000,suspect),1000).slot<0,"unconfirmed team is not an enemy defense target");
  a=Defense.choose(hand(10,9,-1,-1,-1),scene(1000,unit("giant",535,990)),1000);ck(a.slot<0,"late central pull is withheld");
  a=Defense.choose(hand(4,11,-1,-1,-1),scene(1000,unit("witch",535,1000)),1000);
  ck(a.card==11&&Math.hypot(a.x-535,a.y-1000)>=180,"ranged defense maintains distance at deep invasion");
  st=new Strategy();r=hand(10,10,9,11,-1);for(long t=0;t<=2000;t+=500)st.choose(r,scene(t),t);
  st.noteOwnCardPlayed(2100);ck(st.choose(r,scene(2500),2500).slot<0,"wait for effects of a played card");
  // Property sweep: costs, card membership, placement and air compatibility over both lanes and depths.
  for(String name:new String[]{"giant","witch","skeleton","balloon","pekka","flying_machine"})
   for(int x:new int[]{145,535})for(int y:new int[]{550,740,900,1050})for(int e:new int[]{1,3,4,7,10})
    for(int card=0;card<Vision.NAMES.length;card++){
     Enemy.Unit target=unit(name,x,y);a=Defense.choose(hand(e,card,-1,-1,-1),scene(1000,target),1000);
     if(a.slot>=0){ck(a.card==card&&a.cost<=e,"candidate belongs to affordable hand");ck(PlacementPlanner.legal(a.x,a.y),"candidate avoids tower footprints and illegal area");
      if(Enemy.air(name))ck(a.card==6||a.card==7||a.card==9||a.card==11||a.card==13,"air compatibility");
      if(a.card==11||a.card==7||a.card==6)ck(Math.hypot(a.x-x,a.y-y)>=(Enemy.splash(name)?180:140),"ranged standoff");
     }
    }
  System.out.println("PASS "+checks+" tactical assertions: pressure, reserve, both lanes, early defense, uncertainty and placement");
 }
}
