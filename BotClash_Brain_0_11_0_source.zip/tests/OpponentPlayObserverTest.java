import com.botclash.teste.*;
public final class OpponentPlayObserverTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    private static Enemy.Unit unit(String name, float x, float y) {
        Enemy.Unit u = new Enemy.Unit(name, x - 12, y - 20, x + 12, y + 20, 0.95f);
        u.newlyConfirmed = true;
        return u;
    }

    public static void main(String[] args) {
        OpponentPlayObserver observer = new OpponentPlayObserver();
        observer.reset(1000L);

        Enemy.Scene scene = new Enemy.Scene();
        scene.units.add(unit("goblin", 150, 700));
        OpponentElixirTracker.Snapshot first = observer.observe(scene, 1000L, 1.0f);
        check(first.min == 0.0f && first.max == 8.0f,
                "mid-match unknown baseline must remain broad after an ambiguous 2-4 elixir play");

        Enemy.Scene duplicate = new Enemy.Scene();
        duplicate.units.add(unit("goblin", 155, 705));
        OpponentElixirTracker.Snapshot second = observer.observe(duplicate, 1100L, 1.0f);
        check(second.min > first.min && second.max > first.max,
                "duplicate troop must not be charged again; only regeneration advances");
        check(second.max - second.min > 7.9f,
                "deduplicated interval must preserve uncertainty from an unknown starting point");

        Enemy.Scene spawnedToken = new Enemy.Scene();
        spawnedToken.units.add(unit("golemite", 250, 700));
        OpponentElixirTracker.Snapshot third = observer.observe(spawnedToken, 1200L, 1.0f);
        check(third.min > second.min && third.max > second.max,
                "spawned golemites must not be counted as a separate card");

        OpponentPlayObserver.Cost hog = OpponentPlayObserver.costForUnit("hog_rider");
        check(hog != null && hog.min == 4 && hog.max == 4,
                "Hog Rider must map to four elixir");
        check(OpponentPlayObserver.costForUnit("phoenix_small") == null,
                "Phoenix egg/small form must not count as another card");
        OpponentPlayObserver.Cost babyDragon = OpponentPlayObserver.costForUnit("hungry_dragon");
        check(babyDragon != null && babyDragon.min == 4 && babyDragon.max == 4,
                "Baby Dragon must be mapped to its four-elixir card cost");
        OpponentPlayObserver.Cost flyingMachine = OpponentPlayObserver.costForUnit("flying_machine");
        check(flyingMachine != null && flyingMachine.min == 4 && flyingMachine.max == 4,
                "Flying Machine must be mapped to its four-elixir card cost");
        check(OpponentPlayObserver.costForUnit("not_a_card") == null,
                "unknown unit must not invent an elixir cost");

        System.out.println("PASS opponent play events, ambiguous cost intervals, duplicate suppression and spawned-token filtering");
    }
}
