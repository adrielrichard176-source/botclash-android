import com.botclash.teste.Enemy;
import com.botclash.teste.TeamEvidence;

public final class TeamEvidenceTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    private static Enemy.Unit unit() {
        return new Enemy.Unit("hog_rider", 200, 700, 300, 790, .95f);
    }

    public static void main(String[] args) {
        int[] pixels = new int[691 * 1536];
        Enemy.Unit box = unit();
        for (int x = 215; x <= 285; x++) pixels[670 * 691 + x] = 0xffdf4a4a;
        TeamEvidence.Result red = TeamEvidence.classify(pixels, box);
        check(red.team == TeamEvidence.ENEMY && red.confidence > .7f,
                "red health bar must be opponent evidence");

        java.util.Arrays.fill(pixels, 0);
        for (int x = 215; x <= 285; x++) pixels[670 * 691 + x] = 0xff4b9fe0;
        TeamEvidence.Result blue = TeamEvidence.classify(pixels, box);
        check(blue.team == TeamEvidence.FRIENDLY && blue.confidence > .7f,
                "blue health bar must be friendly evidence");

        java.util.Arrays.fill(pixels, 0);
        TeamEvidence.Result unknown = TeamEvidence.classify(pixels, box);
        check(unknown.team == TeamEvidence.UNKNOWN,
                "absence of a health bar must remain unknown");
        System.out.println("PASS red/blue health-bar evidence and conservative unknown classification");
    }
}
