import com.botclash.teste.OpponentElixirTracker;

public final class OpponentElixirTrackerTest {
    static void ck(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        OpponentElixirTracker t = new OpponentElixirTracker();
        t.reset(0L);
        OpponentElixirTracker.Snapshot s = t.snapshot(2800L, 1f);
        ck(Math.abs(s.min - 1f) < .001f && Math.abs(s.max - 10f) < .001f,
                "unknown mid-match baseline remains an interval");
        ck(!s.baselineKnown, "mid-match start is not presented as a known baseline");

        t.resetAtMatchStart(0L);
        s = t.snapshot(2800L, 1f);
        ck(Math.abs(s.min - 6f) < .001f && Math.abs(s.max - 6f) < .001f,
                "single elixir regeneration from a confirmed match start");

        ck(t.onCardPlayed(2800L, 1f, "play-1", 4, 4, .95f),
                "count first confirmed card");
        s = t.snapshot(2800L, 1f);
        ck(Math.abs(s.min - 2f) < .001f && Math.abs(s.max - 2f) < .001f,
                "subtract exact cost");
        ck(!t.onCardPlayed(2800L, 1f, "play-1", 4, 4, .95f),
                "deduplicate repeated visual event");

        s = t.snapshot(4200L, 2f);
        ck(Math.abs(s.min - 3f) < .001f && Math.abs(s.max - 3f) < .001f,
                "double elixir regeneration");
        ck(t.onCardPlayed(4200L, 2f, "play-2", 3, 5, .95f),
                "count uncertain cost");
        s = t.snapshot(4200L, 2f);
        ck(Math.abs(s.min - 0f) < .001f && Math.abs(s.max - 0f) < .001f,
                "cost interval cannot produce negative elixir");

        t.reset(10000L);
        ck(t.onCardPlayed(10000L, 1f, "weak-play", 4, 4, .20f),
                "count low-confidence play conservatively");
        s = t.snapshot(10000L, 1f);
        ck(s.min == 0f && s.max > 0f && s.max <= 7f,
                "weak visual identity widens uncertainty");

        t.reset(0L);
        s = t.snapshot(100000L, 3f);
        ck(s.min == 10f && s.max == 10f, "cap at ten");
        System.out.println("PASS opponent elixir range, phase regeneration, deduplication and conservative uncertainty");
    }
}
