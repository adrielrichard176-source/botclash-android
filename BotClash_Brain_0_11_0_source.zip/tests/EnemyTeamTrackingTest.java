import com.botclash.teste.*;
import java.util.*;

public final class EnemyTeamTrackingTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    private static Enemy.Unit unit(String name, float y) {
        return new Enemy.Unit(name, 200, y - 70, 270, y + 20, .94f);
    }

    public static void main(String[] args) {
        int[] blank = new int[691 * 1536];
        Enemy tracker = new Enemy();
        Enemy.Scene scene = null;
        for (int i = 0; i < 4; i++) {
            scene = tracker.update(Collections.singletonList(unit("hog_rider", 600 + i * 12)), blank, 1000L + i * 500L);
        }
        check(scene != null && !scene.units.isEmpty(),
                "three consistent downward movements should confirm a probable opponent unit");
        Enemy.Unit tracked = scene.units.get(0);
        check(!tracked.teamUncertain && tracked.enemy && tracked.enemyProbability >= .75f,
                "movement evidence should promote the track to opponent after temporal confirmation");
        check(tracked.newlyConfirmed, "confirmed class and team should emit one opponent play event");

        tracker.reset();
        for (int i = 0; i < 3; i++) {
            scene = tracker.update(Collections.singletonList(unit("hog_rider", 740 + i * 12)), blank, 3000L + i * 500L);
        }
        Vision.Reading hand = new Vision.Reading();
        hand.valid = true; hand.elixir = 10; hand.cards = new int[]{11, 9, 12, 14};
        BattleState state = new BattleState(hand, scene, 4000L);
        check(state.possibleThreats.size() == 1 && state.threats.isEmpty(),
                "consistent motion can create a probable threat without falsely confirming a card play");
        Advice.Suggestion cautious = TacticalEngine.defend(state);
        check(cautious.slot >= 0 && cautious.uncertainTarget,
                "probable threat may receive a clearly marked low-risk defensive suggestion");

        tracker.reset();
        int[] redBar = new int[691 * 1536];
        for (int x = 215; x <= 285; x++) redBar[540 * 691 + x] = 0xffdf4a4a;
        tracker.update(Collections.singletonList(unit("flying_machine", 620)), redBar, 4000L);
        scene = tracker.update(Collections.singletonList(unit("flying_machine", 620)), redBar, 4500L);
        check(scene.units.size() == 1 && !scene.units.get(0).teamUncertain,
                "two red health-bar observations should confirm opponent team");

        tracker.reset();
        int[] blueBar = new int[691 * 1536];
        for (int x = 215; x <= 285; x++) blueBar[860 * 691 + x] = 0xff4b9fe0;
        tracker.update(Collections.singletonList(unit("musketeer", 950)), blueBar, 6000L);
        scene = tracker.update(Collections.singletonList(unit("musketeer", 950)), blueBar, 6500L);
        check(scene.units.isEmpty(), "two blue health-bar observations must not become enemy threats");
        System.out.println("PASS temporal team tracking, opponent event confirmation and friendly suppression");
    }
}
