# BotClash Brain 0.11.0-alpha

Guia visual local para Android. O pacote foi reconstruido a partir do APK 0.10.0 enviado pelo usuario. Esta revisao nao e um motor profissional e nao executa toques.

## Requisitos

- Android 11 ou posterior; alvo ARM64 para o runtime ONNX incluido.
- Java 17, Android SDK 35, Build Tools 35.0.0.
- Android Gradle Plugin 8.13.2 e Gradle 8.13.2.
- ONNX Runtime Android 1.23.2.

## O que mudou nesta revisao

- Leitor consulta todas as 15 miniaturas RGB locais, sem filtro fixo para as oito cartas do Deck 4.
- O catalogo ainda nao inclui todas as cartas do jogo; cartas sem miniatura continuam desconhecidas.
- Equipe das tropas combina barra vermelha/azul e movimento temporal.
- Ameaças confirmadas e provaveis sao separadas; sugestoes para equipe incerta ficam marcadas como POSSIVEL.
- Unidades ainda distantes nao bloqueiam automaticamente pressao ofensiva.
- Elixir rival comeca em faixa 0-10 se GUIAR pode iniciar no meio da partida.
- Modelo ONNX de 97 classes nao foi retreinado.

## Instalar e usar

1. Instale o APK compilado `BotClash-Brain-0.11.0-alpha-debug.apk`.
2. Desative o servico de acessibilidade do BotClash Lab 0.10.0 para evitar dois paineis/detectores concorrentes.
3. Abra BotClash Brain e autorize Acessibilidade.
4. Toque em Mostrar painel e abrir Clash.
5. Em replay ou treino, toque GUIAR. O app captura, analisa e mostra recomendacoes/setas; voce confirma e executa os toques.
6. PARAR encerra a captura.

## Limites

- Perfil tatico permanece baseado no Deck 4 anterior.
- Reconhecimento de cartas usa 15 templates locais e comparacao RGB; nao e universal.
- TeamEvidence e uma heuristica; precisa ser validada em replays reais.
- Sem OCR completo de torres/cronometro, detector completo de feiticos, inferencia exata do ciclo rival ou simulacao de pathfinding/dano.
- `canPerformGestures=false`: nao ha automacao de toques.
- Precisao, latencia, temperatura e taxa de vitoria no POCO X6 Pro ainda nao foram medidas.

## Testes

Execute `bash scripts/run-pure-tests.sh`. Os testes Java puros passaram nesta revisao, mas nao substituem a compilacao Android nem testes em partidas reais.

## Compilacao

```bash
gradle -p android-studio-project --no-daemon :app:assembleDebug
```

O workflow `GITHUB_ACTIONS_WORKFLOW.yml` prepara Java 17, Android SDK 35, Gradle 8.13.2, executa os testes e publica o APK como Artifact.
