package com.botclash.teste;
import java.util.*;
/** Bounded role heuristics, evaluating identified threats in BOTH lanes. Not optimal play. */
public final class Defense {
 static boolean swarm(String n){return Arrays.asList("skeleton","guard","goblin","spear_goblin","royal_recruit","barbarian").contains(n);}
 static float urgency(Enemy.Unit u,List<Enemy.Unit> all){float score=(Enemy.buildingTarget(u.name)?14:Enemy.kite(u.name)?11:Enemy.splash(u.name)?9:4)+Math.max(0,u.y()-550)/35;
  for(Enemy.Unit v:all)if(v!=u&&!v.name.equals("unknown")&&Math.hypot(u.x()-v.x(),u.y()-v.y())<180)score+=1.5;
  if(u.y()>945&&u.x()>160&&u.x()<530)score+=25;return score;
 }
 public static Advice.Suggestion choose(Vision.Reading r,Enemy.Scene s,long now){
  return TacticalEngine.defend(new BattleState(r,s,now));
 }
}
