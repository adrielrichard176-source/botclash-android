package com.botclash.teste;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Converts newly confirmed enemy units into a conservative elixir interval.
 * It deliberately ignores ambiguous spawned tokens and never claims exact
 * opponent elixir. Regeneration phase is supplied by the caller.
 */
public final class OpponentPlayObserver {
    private static final long FAMILY_DEDUPE_MS = 1700L;
    private static final long POSITION_DEDUPE_MS = 6000L;
    private static final long CLUSTER_DEDUPE_MS = 650L;
    private static final float CLUSTER_DISTANCE = 135.0f;

    private final OpponentElixirTracker tracker = new OpponentElixirTracker();
    private final Map<String, Long> lastFamily = new HashMap<>();
    private final Map<String, Long> lastPosition = new HashMap<>();
    private long lastClusterAt = -1L;
    private float lastClusterX;
    private float lastClusterY;
    private String lastClusterFamily = "";

    public synchronized void reset(long nowMs) {
        tracker.reset(nowMs);
        lastFamily.clear();
        lastPosition.clear();
        lastClusterAt = -1L;
        lastClusterFamily = "";
    }

    public synchronized OpponentElixirTracker.Snapshot observe(
            Enemy.Scene scene, long nowMs, float regenerationMultiplier) {
        if (scene != null) {
            for (Enemy.Unit unit : scene.units) {
                if (unit == null || unit.teamUncertain || !unit.newlyConfirmed || unit.name == null) continue;
                Cost cost = costForUnit(unit.name);
                if (cost == null) continue;

                String positionKey = cost.family + ":"
                        + Math.round(unit.x() / 96.0f) + ":"
                        + Math.round(unit.y() / 96.0f);
                Long seenAt = lastPosition.get(positionKey);
                if (seenAt != null && nowMs - seenAt < POSITION_DEDUPE_MS) continue;

                Long familyAt = lastFamily.get(cost.family);
                if (familyAt != null && nowMs - familyAt < FAMILY_DEDUPE_MS) {
                    lastPosition.put(positionKey, nowMs);
                    continue;
                }

                boolean sameCluster = lastClusterAt >= 0L
                        && nowMs - lastClusterAt < CLUSTER_DEDUPE_MS
                        && !lastClusterFamily.equals(cost.family)
                        && Math.hypot(unit.x() - lastClusterX, unit.y() - lastClusterY)
                                < CLUSTER_DISTANCE;
                if (sameCluster) {
                    lastPosition.put(positionKey, nowMs);
                    continue;
                }

                String eventKey = positionKey + ":" + nowMs;
                if (tracker.onCardPlayed(nowMs, regenerationMultiplier, eventKey,
                        cost.min, cost.max, unit.confidence)) {
                    lastFamily.put(cost.family, nowMs);
                    lastPosition.put(positionKey, nowMs);
                    lastClusterAt = nowMs;
                    lastClusterX = unit.x();
                    lastClusterY = unit.y();
                    lastClusterFamily = cost.family;
                }
            }
        }
        expire(nowMs);
        return tracker.snapshot(nowMs, regenerationMultiplier);
    }

    private void expire(long nowMs) {
        Iterator<Map.Entry<String, Long>> families = lastFamily.entrySet().iterator();
        while (families.hasNext()) {
            if (nowMs - families.next().getValue() > 12000L) families.remove();
        }
        Iterator<Map.Entry<String, Long>> positions = lastPosition.entrySet().iterator();
        while (positions.hasNext()) {
            if (nowMs - positions.next().getValue() > POSITION_DEDUPE_MS) positions.remove();
        }
    }

    public static Cost costForUnit(String name) {
        if (name == null) return null;
        switch (name) {
            case "hog": case "hog_rider": return exact("hog", 4);
            case "musketeer": return exact(name, 4);
            case "dark_prince": return exact(name, 4);
            case "knight": return exact(name, 3);
            case "minipekka": return exact(name, 4);
            case "pekka": return exact(name, 7);
            case "valkyrie": return exact(name, 4);
            case "witch": return exact(name, 5);
            case "wizard": return exact(name, 5);
            case "electro_wizard": return exact(name, 4);
            case "firecracker": return exact(name, 3);
            case "balloon": return exact(name, 5);
            case "giant": return exact(name, 5);
            case "golem": return exact(name, 8);
            case "miner": return exact(name, 3);
            case "princess": return exact(name, 3);
            case "dart_goblin": return exact(name, 3);
            case "magic_archer": return exact(name, 4);
            case "executioner": return exact(name, 5);
            case "hunter": return exact(name, 4);
            case "bowler": return exact(name, 5);
            case "bandit": return exact(name, 3);
            case "fisherman": return exact(name, 3);
            case "ram_rider": return exact(name, 5);
            case "battle_ram": return exact(name, 4);
            case "royal_giant": return exact(name, 6);
            case "electro_giant": return exact(name, 7);
            case "royal_hog": return exact(name, 5);
            case "archer": return exact(name, 3);
            case "goblin_cage": return exact(name, 4);
            case "wall_breaker": return exact(name, 2);
            case "x_bow": return exact(name, 6);
            case "mortar": return exact(name, 4);
            case "inferno_tower": return exact(name, 5);
            case "tesla": return exact(name, 4);
            case "cannon": return exact(name, 3);
            case "bomb_tower": return exact(name, 4);
            case "tombstone": return exact(name, 3);
            case "goblin_drill": return exact(name, 4);
            case "elixir_collector": return exact(name, 6);
            case "furnace": return exact(name, 4);
            case "goblin_hut": return exact(name, 4);
            case "barbarian_hut": return exact(name, 6);
            case "sparky": return exact(name, 6);
            case "mega_knight": return exact(name, 7);
            case "electro_dragon": return exact(name, 5);
            case "hungry_dragon": return exact(name, 4);
            case "flying_machine": return exact(name, 4);
            case "skeleton_dragon": return exact(name, 4);
            case "mother_witch": return exact(name, 4);
            case "night_witch": return exact(name, 4);
            case "zappy": return exact(name, 4);
            case "inferno_dragon": return exact(name, 4);
            case "lava_hound": return exact(name, 7);
            case "phoenix_large": return exact("phoenix", 4);
            case "giant_skeleton": return exact(name, 6);
            case "royal_recruit": return exact(name, 7);
            case "guard": return exact("guards", 3);
            case "skeleton_king": return exact(name, 4);
            case "monk": return exact(name, 5);
            case "golden_knight": return exact(name, 4);
            case "mighty_miner": return exact(name, 4);
            case "archer_queen": return exact(name, 5);
            case "little_prince": return exact(name, 3);
            case "royal_ghost": return exact(name, 3);
            case "ice_golem": return exact(name, 2);
            case "bomber": return exact(name, 2);
            case "ice_spirit": case "fire_spirit": case "electro_spirit":
            case "heal_spirit": return exact("spirit", 1);
            case "rascal_boy": case "rascal_girl": return exact("rascals", 5);
            case "elixir_golem_large": return exact("elixir_golem", 3);
            case "goblin": return range("goblins", 2, 4);
            case "spear_goblin": return range("spear_goblins", 2, 3);
            case "skeleton": return range("skeletons", 1, 3);
            case "minion": return range("minions", 3, 5);
            case "barbarian": return range("barbarians", 2, 5);
            case "bat": return range("bats", 2, 5);
            // These are normally spawned by another card, not separate plays.
            case "golemite": case "lava_pup": case "phoenix_small":
            case "phoenix_egg": case "elixir_golem_medium":
            case "elixir_golem_small": return null;
            default: return null;
        }
    }

    private static Cost exact(String family, int value) {
        return new Cost(family, value, value);
    }

    private static Cost range(String family, int min, int max) {
        return new Cost(family, min, max);
    }

    public static final class Cost {
        public final String family;
        public final int min;
        public final int max;

        Cost(String family, int min, int max) {
            this.family = family;
            this.min = min;
            this.max = max;
        }
    }
}
