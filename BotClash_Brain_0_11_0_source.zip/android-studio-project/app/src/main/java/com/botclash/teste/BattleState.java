package com.botclash.teste;

import java.util.ArrayList;
import java.util.List;

/** A time-bounded battle snapshot with confirmed and probable threats separated. */
public final class BattleState {
    public final Vision.Reading hand;
    public final Enemy.Scene scene;
    public final long now;
    public final List<Enemy.Unit> threats = new ArrayList<>();
    public final List<Enemy.Unit> possibleThreats = new ArrayList<>();
    public final boolean usable;
    public boolean uncertain;

    public BattleState(Vision.Reading hand, Enemy.Scene scene, long now) {
        this.hand = hand;
        this.scene = scene;
        this.now = now;
        usable = hand != null && hand.valid && hand.elixir >= 0 && hand.elixir <= 10
                && scene != null && now >= scene.time && now - scene.time <= 1400L;
        if (!usable) return;

        uncertain = scene.uncertain || scene.obstructed;
        List<Enemy.Unit> all = new ArrayList<>(scene.units);
        if (all.isEmpty() && scene.main != null) all.add(scene.main);
        for (Enemy.Unit unit : all) {
            if (unit == null) continue;
            if (unit.time > 0L && (now < unit.time || now - unit.time > 1400L)) {
                uncertain = true;
                continue;
            }
            if (unit.teamUncertain) {
                uncertain = true;
                // Movement toward the player's towers is a useful warning, but not
                // strong enough to treat as a confirmed card play.
                boolean movingTowardPlayer = unit.enemyProbability >= 0.62f
                        && unit.y() >= 690f && unit.velocityY > 0.5f;
                boolean deepUnknown = unit.confidence >= 0.85f && unit.y() >= 930f
                        && unit.enemyProbability >= 0.50f;
                if (movingTowardPlayer || deepUnknown) possibleThreats.add(unit);
                continue;
            }
            // A confirmed opponent team with an unknown class is still a threat.
            threats.add(unit);
            if ("unknown".equals(unit.name)) uncertain = true;
        }
        if (scene.markers > all.size()) uncertain = true;
    }

    public boolean hasUrgentThreat() {
        for (Enemy.Unit unit : threats) if (unit.y() >= 650f) return true;
        for (Enemy.Unit unit : possibleThreats) if (unit.y() >= 760f) return true;
        return false;
    }

    public boolean hasAnyOpponent() {
        return !threats.isEmpty() || !possibleThreats.isEmpty();
    }

    public boolean affordable(int slot) {
        if (!usable || slot < 0 || slot >= hand.cards.length) return false;
        int card = hand.cards[slot];
        return card >= 0 && card < Vision.COST.length && Vision.COST[card] <= hand.elixir;
    }
}
