package com.botclash.teste;

/** Temporal policy. Distant enemy units no longer freeze the offensive engine. */
public final class Strategy {
    private long clearSince = -1L, lastThreat = -1L, playedAt = -10000L;
    private int lastElixir = -1;
    private final HandStability stability = new HandStability();
    private boolean lastThreatRight;

    public void noteOwnCardPlayed(long now) { playedAt = now; clearSince = -1L; }

    public void reset() {
        clearSince = lastThreat = -1L;
        playedAt = -10000L;
        lastElixir = -1;
        stability.reset();
        lastThreatRight = false;
    }

    public Advice.Suggestion choose(Vision.Reading reading, Enemy.Scene scene, long now) {
        return choose(reading, scene, now, null);
    }

    public Advice.Suggestion choose(Vision.Reading reading, Enemy.Scene scene, long now,
                                    OpponentElixirTracker.Snapshot opponent) {
        Advice.Suggestion wait = new Advice.Suggestion();
        wait.reason = "Aguardando leitura atual da partida.";
        BattleState state = new BattleState(reading, scene, now);
        if (!state.usable) { stability.reset(); return wait; }
        stability.observe(reading);
        if (lastElixir >= 0 && lastElixir - reading.elixir >= 2) noteOwnCardPlayed(now);
        lastElixir = reading.elixir;

        boolean urgent = state.hasUrgentThreat();
        if (urgent) {
            clearSince = -1L;
            lastThreat = now;
            Enemy.Unit main = scene.main;
            if (main != null) lastThreatRight = main.x() > 345.5f;
        } else if (clearSince < 0L) {
            clearSince = now;
        }

        if (now - playedAt < 900L) {
            wait.reason = "Carta jogada: confirmando a nova mao e reavaliando a defesa.";
            return wait;
        }

        // Each visible slot is confirmed independently; an unknown slot does not
        // suppress a different, stable and recognized card.
        Vision.Reading confirmed = new Vision.Reading();
        confirmed.valid = reading.valid;
        confirmed.elixir = reading.elixir;
        confirmed.cards = reading.cards.clone();
        for (int slot = 0; slot < confirmed.cards.length; slot++) {
            Advice.Suggestion probe = new Advice.Suggestion();
            probe.slot = slot;
            probe.card = reading.cards[slot];
            if (!stability.ready(probe, reading)) confirmed.cards[slot] = -1;
        }
        state = new BattleState(confirmed, scene, now);

        if (state.hasUrgentThreat()) {
            Advice.Suggestion defense = TacticalEngine.defend(state);
            if (defense.slot >= 0) return defense;
            wait.reason = "Ameaca urgente reconhecida, mas nenhuma resposta segura foi confirmada na mao.";
            return wait;
        }
        if (scene.obstructed) {
            wait.reason = "Painel cobre parte da arena. Mova-o para o topo antes de atacar.";
            return wait;
        }

        // Only a short settle window is used after a threat disappears. The old
        // four-second lockout made the bot miss counter-pressure opportunities.
        long quiet = lastThreat < 0L ? 700L : 1200L;
        if (clearSince < 0L || now - clearSince < quiet) {
            wait.reason = "Reavaliando a arena e a reserva defensiva.";
            return wait;
        }

        return TacticalEngine.pressure(state, lastThreatRight, opponent);
    }
}
