package com.botclash.teste;

/**
 * Interval estimator for opponent elixir. Starting a guide mid-match does not
 * reveal the opponent's current elixir, so the default baseline is unknown.
 */
public final class OpponentElixirTracker {
    public static final float MAX_ELIXIR = 10.0f;
    public static final float START_ELIXIR = 5.0f;
    public static final long SINGLE_ELIXIR_PERIOD_MS = 2800L;

    private float minElixir = 0.0f;
    private float maxElixir = MAX_ELIXIR;
    private long lastUpdateMs = -1L;
    private long lastPlayMs = -1L;
    private String lastEventKey = "";
    private boolean baselineKnown;

    /** Unknown starting point: correct when GUIAR may begin after the match started. */
    public synchronized void reset(long nowMs) {
        minElixir = 0.0f;
        maxElixir = MAX_ELIXIR;
        lastUpdateMs = nowMs;
        lastPlayMs = -1L;
        lastEventKey = "";
        baselineKnown = false;
    }

    /** Use only when the app has positively detected the start of a fresh match. */
    public synchronized void resetAtMatchStart(long nowMs) {
        minElixir = START_ELIXIR;
        maxElixir = START_ELIXIR;
        lastUpdateMs = nowMs;
        lastPlayMs = -1L;
        lastEventKey = "";
        baselineKnown = true;
    }

    public synchronized Snapshot snapshot(long nowMs, float multiplier) {
        advance(nowMs, multiplier);
        return new Snapshot(minElixir, maxElixir, nowMs, lastPlayMs, baselineKnown);
    }

    /** Records one observed card play using a cost interval, never a guessed exact cost. */
    public synchronized boolean onCardPlayed(long nowMs, float multiplier, String eventKey,
                                             int minCost, int maxCost, float confidence) {
        advance(nowMs, multiplier);
        String key = eventKey == null ? "" : eventKey.trim();
        if (!key.isEmpty() && key.equals(lastEventKey)
                && lastPlayMs >= 0L && nowMs - lastPlayMs < 2200L) return false;

        int low = clampCost(Math.min(minCost, maxCost));
        int high = clampCost(Math.max(minCost, maxCost));
        float c = Math.max(0.0f, Math.min(1.0f, confidence));
        if (c < 0.55f) {
            low = Math.max(1, low - 1);
            high = Math.min(9, high + 2);
        } else if (c < 0.80f && low == high) {
            low = Math.max(1, low - 1);
            high = Math.min(9, high + 1);
        }

        minElixir = clampElixir(minElixir - high);
        maxElixir = clampElixir(maxElixir - low);
        if (minElixir > maxElixir) minElixir = maxElixir;
        lastPlayMs = nowMs;
        if (!key.isEmpty()) lastEventKey = key;
        return true;
    }

    private void advance(long nowMs, float multiplier) {
        if (lastUpdateMs < 0L) { lastUpdateMs = nowMs; return; }
        if (nowMs <= lastUpdateMs) return;
        float safeMultiplier = multiplier >= 2.5f ? 3.0f : multiplier >= 1.5f ? 2.0f : 1.0f;
        float gained = (nowMs - lastUpdateMs) * safeMultiplier / (float) SINGLE_ELIXIR_PERIOD_MS;
        minElixir = clampElixir(minElixir + gained);
        maxElixir = clampElixir(maxElixir + gained);
        lastUpdateMs = nowMs;
    }

    private static int clampCost(int cost) { return Math.max(0, Math.min(10, cost)); }
    private static float clampElixir(float value) { return Math.max(0.0f, Math.min(MAX_ELIXIR, value)); }

    public static final class Snapshot {
        public final float min, max;
        public final long atMs, lastPlayMs;
        public final boolean baselineKnown;

        Snapshot(float min, float max, long atMs, long lastPlayMs, boolean baselineKnown) {
            this.min = min;
            this.max = max;
            this.atMs = atMs;
            this.lastPlayMs = lastPlayMs;
            this.baselineKnown = baselineKnown;
        }

        public float uncertainty() { return max - min; }
        public boolean isNarrow() { return uncertainty() <= 1.25f; }
        public String label() {
            return String.format(java.util.Locale.US, "%.1f-%.1f", min, max);
        }
    }
}
