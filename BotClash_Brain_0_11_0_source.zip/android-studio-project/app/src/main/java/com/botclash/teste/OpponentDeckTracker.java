package com.botclash.teste;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Tracks opponent cards that were actually confirmed from troop detections. */
public final class OpponentDeckTracker {
    private static final int DECK_SIZE = 8;
    private static final int RECENT_SIZE = 8;
    private final Set<String> seen = new LinkedHashSet<>();
    private final ArrayDeque<String> recent = new ArrayDeque<>();

    public synchronized void reset() {
        seen.clear();
        recent.clear();
    }

    public synchronized void observe(Enemy.Scene scene) {
        if (scene == null) return;
        for (Enemy.Unit unit : scene.units) {
            if (unit == null || unit.teamUncertain || !unit.newlyConfirmed || unit.name == null) continue;
            OpponentPlayObserver.Cost cost = OpponentPlayObserver.costForUnit(unit.name);
            if (cost == null) continue;
            String family = cost.family;
            recent.addLast(family);
            while (recent.size() > RECENT_SIZE) recent.removeFirst();
            if (seen.size() < DECK_SIZE) seen.add(family);
        }
    }

    public synchronized int knownCount() { return seen.size(); }

    public synchronized List<String> knownCards() { return new ArrayList<>(seen); }

    public synchronized String summary() {
        if (seen.isEmpty()) return "Deck rival: 0/8 cartas confirmadas";
        StringBuilder out = new StringBuilder("Deck rival: ").append(seen.size()).append("/8 conhecidas • ");
        int count = 0;
        for (String card : seen) {
            if (count++ > 0) out.append(", ");
            out.append(label(card));
        }
        return out.toString();
    }

    public synchronized String recentSummary() {
        if (recent.isEmpty()) return "Ciclo rival: aguardando jogadas confirmadas";
        StringBuilder out = new StringBuilder("Jogadas rivais observadas: ");
        int count = 0;
        for (String card : recent) {
            if (count++ > 0) out.append(" · ");
            out.append(label(card));
        }
        out.append(" • mão não inferida");
        return out.toString();
    }

    private static String label(String family) {
        if (family == null || family.isEmpty()) return "?";
        String[] parts = family.split("_");
        StringBuilder out = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) continue;
            if (out.length() > 0) out.append(' ');
            out.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return out.toString();
    }
}
