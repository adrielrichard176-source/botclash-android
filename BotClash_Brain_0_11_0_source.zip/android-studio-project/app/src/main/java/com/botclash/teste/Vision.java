package com.botclash.teste;

import java.util.HashMap;
import java.util.Map;

/** Pure Java visual reader for the local card-template catalog and normalized arena layout. */
public final class Vision {
    public static final String[] NAMES = {
            "Golem de Gelo", "Barril de Goblins", "Fantasma Real", "Barril de Barbaro",
            "Torre de Bombas", "Relampago", "Horda de Servos", "Mago Eletrico",
            "Principe das Trevas", "Tesla", "Corredor", "Mosqueteira", "Cavaleiro Heroi",
            "Espirito de Gelo", "Esqueletos"
    };
    public static final int[] COST = {2, 3, 3, 2, 4, 6, 5, 4, 4, 4, 4, 4, 3, 1, 1};

    public static int templateId(String key) {
        try {
            String[] parts = key.split("_");
            int id = Integer.parseInt(parts[1]);
            return id >= 0 && id < NAMES.length ? id : -1;
        } catch (RuntimeException ignored) {
            return -1;
        }
    }

    public final Map<String, int[]> templates = new HashMap<>();

    public static final class Reading {
        public boolean valid;
        public int elixir = -1, next = -1;
        public int[] nextPixels;
        public int[] cards = {-1, -1, -1, -1};
        public double[] confidence = new double[4];
    }

    public static int[] crop(int[] source, int width, int height, int left, int top, int cropWidth, int cropHeight) {
        int[] output = new int[24 * 28];
        for (int y = 0; y < 28; y++) {
            for (int x = 0; x < 24; x++) {
                int sx = left + (int) ((x + 0.5) * cropWidth / 24.0);
                int sy = top + (int) ((y + 0.5) * cropHeight / 28.0);
                output[y * 24 + x] = sx >= 0 && sx < width && sy >= 0 && sy < height
                        ? source[sy * width + sx] : 0;
            }
        }
        return output;
    }

    /** Similarity of packed RGB template pixels. */
    public static double score(int[] a, int[] b) {
        if (a == null || b == null || a.length != b.length || a.length == 0) return 0.0;
        double error = 0.0;
        for (int i = 0; i < a.length; i++) {
            int p = a[i], q = b[i];
            error += Math.abs(((p >>> 16) & 255) - ((q >>> 16) & 255));
            error += Math.abs(((p >>> 8) & 255) - ((q >>> 8) & 255));
            error += Math.abs((p & 255) - (q & 255));
        }
        return 1.0 - error / (a.length * 765.0);
    }

    private static boolean purple(int pixel) {
        int r = (pixel >>> 16) & 255, g = (pixel >>> 8) & 255, b = pixel & 255;
        return r > 100 && b > 90 && r > g * 1.25f && b > g * 1.15f;
    }

    public Reading read(int[] pixels) {
        Reading reading = new Reading();
        int[] hudAnchor = crop(pixels, 691, 1536, 20, 1414, 90, 22);
        int[] hud = templates.get("hud");
        if (hud == null || score(hudAnchor, hud) < 0.88) return reading;

        int blue = 0;
        for (int x = 130; x < 680; x += 30) {
            int color = pixels[1315 * 691 + x];
            if ((color & 255) > ((color >>> 16) & 255) + 40) blue++;
        }
        if (blue < 10) return reading;

        reading.valid = true;
        reading.elixir = 0;
        boolean gap = false;
        for (int i = 0; i < 10; i++) {
            int x = 188 + (i + 1) * 48 - 8;
            int hits = 0;
            for (int y = 1501; y <= 1511; y += 2) if (purple(pixels[y * 691 + x])) hits++;
            boolean filled = hits >= 4;
            if (filled && gap) { reading.elixir = -1; break; }
            if (filled) reading.elixir++; else gap = true;
        }

        for (int slot = 0; slot < 4; slot++) {
            double[] scores = new double[NAMES.length];
            for (int dy = -24; dy <= 4; dy += 4) {
                int[] crop = crop(pixels, 691, 1536, 175 + 130 * slot, 1345 + dy, 80, 100);
                for (Map.Entry<String, int[]> entry : templates.entrySet()) {
                    if (!entry.getKey().startsWith("hand_")) continue;
                    int id = templateId(entry.getKey());
                    // Do not filter by Deck 4: recognize every identity for which
                    // this build actually contains a local template.
                    if (id >= 0) scores[id] = Math.max(scores[id], score(crop, entry.getValue()));
                }
            }
            int best = 0;
            double second = 0.0;
            for (int i = 1; i < NAMES.length; i++) if (scores[i] > scores[best]) best = i;
            for (int i = 0; i < NAMES.length; i++) if (i != best) second = Math.max(second, scores[i]);
            reading.confidence[slot] = scores[best];
            if (scores[best] >= 0.88 && scores[best] - second >= 0.035) reading.cards[slot] = best;
        }

        // Duplicate detections are ambiguous because a normal deck has one copy
        // of a card identity in the hand at a time.
        for (int i = 0; i < 4; i++) {
            for (int j = i + 1; j < 4; j++) {
                if (reading.cards[i] >= 0 && reading.cards[i] == reading.cards[j]) {
                    reading.cards[i] = -1;
                    reading.cards[j] = -1;
                }
            }
        }
        reading.nextPixels = smoothNext(pixels);
        reading.next = matchNext(reading.nextPixels);
        return reading;
    }

    public static int[] smoothNext(int[] source) {
        int[] output = new int[672];
        for (int y = 0; y < 28; y++) {
            for (int x = 0; x < 24; x++) {
                int xx = 44 + (int) ((x + 0.5) * 40 / 24.0);
                int yy = 1465 + (int) ((y + 0.5) * 40 / 28.0);
                int red = 0, green = 0, blue = 0;
                for (int dy = -2; dy <= 2; dy++) {
                    for (int dx = -2; dx <= 2; dx++) {
                        int color = source[(yy + dy) * 691 + xx + dx];
                        red += (color >>> 16) & 255;
                        green += (color >>> 8) & 255;
                        blue += color & 255;
                    }
                }
                output[y * 24 + x] = ((red / 25) << 16) | ((green / 25) << 8) | (blue / 25);
            }
        }
        return output;
    }

    public int matchNext(int[] nextPixels) {
        double[] scores = new double[NAMES.length];
        for (Map.Entry<String, int[]> entry : templates.entrySet()) {
            if (!entry.getKey().startsWith("next_")) continue;
            int id = templateId(entry.getKey());
            if (id >= 0 && id < NAMES.length) scores[id] = Math.max(scores[id], score(nextPixels, entry.getValue()));
        }
        int best = 0;
        double second = 0.0;
        for (int i = 1; i < NAMES.length; i++) if (scores[i] > scores[best]) best = i;
        for (int i = 0; i < NAMES.length; i++) if (i != best) second = Math.max(second, scores[i]);
        return scores[best] >= 0.86 && scores[best] - second >= 0.06 ? best : -1;
    }
}
