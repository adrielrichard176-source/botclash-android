package com.botclash.teste;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Detection filtering and temporal tracking in the normalized 691 x 1536 arena. */
public final class Enemy {
    public static final class Unit {
        public String name;
        public float x1, y1, x2, y2, confidence;
        public float velocityY;
        public float enemyProbability = 0.5f;
        public float teamConfidence;
        public int hits = 1;
        public long time;
        public boolean enemy, newlyConfirmed, teamUncertain;

        public Unit(String name, float left, float top, float right, float bottom, float confidence) {
            this.name = name;
            this.x1 = left;
            this.y1 = top;
            this.x2 = right;
            this.y2 = bottom;
            this.confidence = confidence;
        }

        public float x() { return (x1 + x2) / 2f; }
        public float y() { return y2; }
    }

    public static final class Scene {
        public List<Unit> units = new ArrayList<>();
        public Unit main;
        public boolean right, splash, air, uncertain, obstructed;
        public long time;
        public int markers;
        public String summary = "Nenhuma ameaca confirmada";
    }

    static final class Badge {
        float x, y;
        boolean red;
        Badge(float x, float y, boolean red) { this.x = x; this.y = y; this.red = red; }
    }

    static final class Track {
        float x, y;
        int hits;
        long seen;
        Unit box;
        boolean playEventEmitted;
        int enemyBarHits, friendlyBarHits, enemyMotionHits, friendlyMotionHits;
        boolean teamEnemyConfirmed, teamFriendlyConfirmed;
        final ArrayDeque<String> votes = new ArrayDeque<>();
    }

    private long last;
    private final List<Track> tracks = new ArrayList<>();
    private final List<Track> rawTracks = new ArrayList<>();

    public void reset() {
        tracks.clear();
        rawTracks.clear();
        last = 0L;
    }

    static boolean color(int p, boolean red) {
        int r = (p >>> 16) & 255, g = (p >>> 8) & 255, b = p & 255;
        return red ? r > 70 && r < 210 && g < 90 && b > 20 && r > g * 1.6f && r > b * 1.12f
                : b > 80 && r < g * 0.85f && g > 50 && g < 180 && b > r * 1.3f;
    }

    static boolean white(int p) {
        int r = (p >>> 16) & 255, g = (p >>> 8) & 255, b = p & 255;
        int min = Math.min(r, Math.min(g, b));
        int max = Math.max(r, Math.max(g, b));
        return min > 205 && max - min < 55;
    }

    static List<Badge> badges(int[] pixels) {
        List<Badge> out = new ArrayList<>();
        int width = 691;
        int[] directions = {-1, 1, -width, width};
        boolean[] seen = new boolean[pixels.length];
        int[] queue = new int[pixels.length];
        for (int y = 350; y < 1480; y++) {
            for (int x = 28; x < 663; x++) {
                int start = y * width + x;
                if (seen[start] || !white(pixels[start])) continue;
                int head = 0, tail = 0, left = x, right = x, top = y, bottom = y;
                queue[tail++] = start;
                seen[start] = true;
                while (head < tail) {
                    int index = queue[head++], xx = index % width, yy = index / width;
                    left = Math.min(left, xx); right = Math.max(right, xx);
                    top = Math.min(top, yy); bottom = Math.max(bottom, yy);
                    for (int direction : directions) {
                        int next = index + direction;
                        int nx = next % width, ny = next / width;
                        if (nx < 28 || nx >= 663 || ny < 350 || ny >= 1480
                                || seen[next] || !white(pixels[next])) continue;
                        seen[next] = true;
                        queue[tail++] = next;
                    }
                }
                int boxWidth = right - left + 1, boxHeight = bottom - top + 1;
                if (boxWidth < 3 || boxWidth > 19 || boxHeight < 8 || boxHeight > 20 || tail < 12) continue;
                int red = 0, blue = 0, redTop = 0, redBottom = 0, blueTop = 0, blueBottom = 0;
                for (int yy = top - 3; yy <= bottom + 3; yy++) {
                    for (int xx = left - 3; xx <= right + 3; xx++) {
                        int pixel = pixels[yy * width + xx];
                        if (color(pixel, true)) { red++; if (yy < top) redTop++; if (yy > bottom) redBottom++; }
                        if (color(pixel, false)) { blue++; if (yy < top) blueTop++; if (yy > bottom) blueBottom++; }
                    }
                }
                boolean hostile = red >= 30 && red > blue * 2 && redTop >= 4 && redBottom >= 4;
                boolean friendly = blue >= 30 && blue > red * 2 && blueTop >= 4 && blueBottom >= 4;
                if (!hostile && !friendly) continue;
                float cx = (left + right) / 2f, cy = (top + bottom) / 2f;
                Badge merged = null;
                for (Badge badge : out) {
                    if (badge.red == hostile && Math.abs(badge.x - cx) < 19 && Math.abs(badge.y - cy) < 5) {
                        merged = badge; break;
                    }
                }
                if (merged == null) out.add(new Badge(cx, cy, hostile));
                else { merged.x = (merged.x + cx) / 2f; merged.y = (merged.y + cy) / 2f; }
            }
        }
        return out;
    }

    static boolean outside(Unit unit) {
        float x = unit.x(), y = (unit.y1 + unit.y2) / 2f;
        return y < 180 || y > 1480 || x < 28 || x > 663;
    }

    static double badgeDistance(Unit unit, Badge badge) {
        if (badge.x < unit.x1 - 27 || badge.x > unit.x2 + 20
                || badge.y < unit.y1 - 58 || badge.y > unit.y1 + (unit.y2 - unit.y1) * 0.6f) return 1e6;
        return Math.abs(badge.x - unit.x()) * 0.45 + Math.abs(badge.y - unit.y1);
    }

    public Scene update(List<Unit> raw, int[] pixels, long now) {
        if (last != 0L && (now - last > 1400L || now < last)) {
            tracks.clear(); rawTracks.clear();
        }
        last = now;
        Scene scene = new Scene();
        scene.time = now;
        List<Badge> marks = badges(pixels);
        List<Track> nextBadgeTracks = new ArrayList<>();
        Set<Track> usedBadgeTracks = new HashSet<>();
        Set<Unit> usedUnits = new HashSet<>();

        // Strong red level badges identify opponent units.
        for (Badge badge : marks) {
            if (!badge.red) continue;
            scene.markers++;
            Track track = nearestTrack(tracks, usedBadgeTracks, badge.x, badge.y, now, 85.0);
            if (track == null) track = new Track(); else usedBadgeTracks.add(track);
            Unit best = nearestDetection(raw, usedUnits, badge, marks);
            if (best != null) usedUnits.add(best);
            track.x = badge.x; track.y = badge.y; track.seen = now; track.hits++;
            track.votes.addLast(best == null ? "?" : best.name);
            while (track.votes.size() > 4) track.votes.removeFirst();
            String name = votedName(track.votes);
            Unit unit = best == null
                    ? new Unit(name, badge.x - 25, badge.y + 8, badge.x + 30, Math.min(1130, badge.y + 85), 0f)
                    : copy(best, name);
            unit.enemy = true;
            unit.teamUncertain = false;
            unit.enemyProbability = 0.98f;
            unit.teamConfidence = 0.98f;
            unit.time = now;
            unit.hits = track.hits;
            unit.newlyConfirmed = !"unknown".equals(name) && !track.playEventEmitted;
            if (unit.newlyConfirmed) track.playEventEmitted = true;
            track.box = unit;
            nextBadgeTracks.add(track);
            if (track.hits >= 2) {
                scene.units.add(unit);
                if ("unknown".equals(name)) scene.uncertain = true;
            }
        }

        // Fallback tracks boxes without a readable level badge. Health-bar color is
        // strong team evidence; movement toward the player's side is secondary evidence.
        List<Track> nextRawTracks = new ArrayList<>();
        Set<Track> usedRawTracks = new HashSet<>();
        if (raw != null) for (Unit candidate : raw) {
            if (candidate == null || usedUnits.contains(candidate) || candidate.confidence < 0.68f
                    || outside(candidate) || "giant_snowball".equals(candidate.name)
                    || "phoenix_egg".equals(candidate.name)) continue;
            boolean redNear = false, blueNear = false;
            for (Badge badge : marks) {
                if (badgeDistance(candidate, badge) < 1e6) {
                    if (badge.red) redNear = true; else blueNear = true;
                }
            }
            if (redNear || blueNear) continue;

            float cx = candidate.x(), cy = (candidate.y1 + candidate.y2) / 2f;
            Track track = nearestTrack(rawTracks, usedRawTracks, cx, cy, now, 125.0);
            float deltaY = 0f;
            if (track == null) track = new Track();
            else {
                usedRawTracks.add(track);
                if (track.hits > 0) deltaY = cy - track.y;
            }
            TeamEvidence.Result evidence = TeamEvidence.classify(pixels, candidate);
            if (evidence.team == TeamEvidence.ENEMY) {
                track.enemyBarHits++;
                track.friendlyBarHits = 0;
            } else if (evidence.team == TeamEvidence.FRIENDLY) {
                track.friendlyBarHits++;
                track.enemyBarHits = 0;
            } else if (deltaY > 4f) {
                track.enemyMotionHits++;
                track.friendlyMotionHits = Math.max(0, track.friendlyMotionHits - 1);
            } else if (deltaY < -4f) {
                track.friendlyMotionHits++;
                track.enemyMotionHits = Math.max(0, track.enemyMotionHits - 1);
            }

            track.x = cx; track.y = cy; track.seen = now; track.hits++;
            track.votes.addLast(candidate.name);
            while (track.votes.size() > 4) track.votes.removeFirst();
            String name = votedName(track.votes);
            boolean enemyByBar = track.enemyBarHits >= 2;
            boolean friendlyByBar = track.friendlyBarHits >= 2;
            boolean enemyByMotion = track.enemyMotionHits >= 3
                    || (track.enemyBarHits >= 1 && track.enemyMotionHits >= 1);
            boolean friendlyByMotion = track.friendlyMotionHits >= 3
                    || (track.friendlyBarHits >= 1 && track.friendlyMotionHits >= 1);
            boolean enemyConfirmed = enemyByBar || enemyByMotion;
            boolean friendlyConfirmed = friendlyByBar || friendlyByMotion;
            if (enemyConfirmed && friendlyConfirmed) {
                enemyConfirmed = false;
                friendlyConfirmed = false;
            }
            track.teamEnemyConfirmed = enemyConfirmed;
            track.teamFriendlyConfirmed = friendlyConfirmed;

            float probability;
            if (enemyByBar) probability = Math.min(0.98f, 0.82f + evidence.confidence * 0.16f);
            else if (friendlyByBar) probability = 0.02f;
            else probability = clamp01(0.5f + (track.enemyMotionHits - track.friendlyMotionHits) * 0.10f);

            Unit unit = copy(candidate, name);
            unit.time = now;
            unit.hits = track.hits;
            unit.velocityY = deltaY;
            unit.enemyProbability = probability;
            unit.teamConfidence = Math.abs(probability - 0.5f) * 2f;
            unit.enemy = enemyConfirmed;
            unit.teamUncertain = !enemyConfirmed && !friendlyConfirmed;
            unit.newlyConfirmed = enemyConfirmed && !"unknown".equals(name) && !track.playEventEmitted;
            if (unit.newlyConfirmed) track.playEventEmitted = true;
            track.box = unit;
            nextRawTracks.add(track);

            if (friendlyConfirmed) continue;
            if (!enemyConfirmed) scene.uncertain = true;
            if (track.hits >= 2) {
                scene.markers++;
                scene.units.add(unit);
                if (unit.teamUncertain || "unknown".equals(name)) scene.uncertain = true;
            }
        }

        // Retain a short-lived presence marker through one missed frame, but never
        // turn a stale identity into a new opponent card event.
        for (Track track : rawTracks) {
            if (!usedRawTracks.contains(track) && !track.teamFriendlyConfirmed
                    && now - track.seen <= 500L && track.hits >= 2) {
                nextRawTracks.add(track);
                Unit previous = track.box;
                Unit unit = copy(previous, track.teamEnemyConfirmed ? previous.name : "unknown");
                unit.time = track.seen;
                unit.newlyConfirmed = false;
                unit.teamUncertain = !track.teamEnemyConfirmed;
                unit.enemy = track.teamEnemyConfirmed;
                unit.enemyProbability = track.teamEnemyConfirmed ? 0.90f : 0.5f;
                scene.units.add(unit);
                scene.markers++;
                scene.uncertain = true;
            }
        }
        for (Track track : tracks) {
            if (!usedBadgeTracks.contains(track) && now - track.seen <= 750L && track.hits >= 2) {
                nextBadgeTracks.add(track);
                Unit previous = track.box;
                Unit unit = copy(previous, "unknown");
                unit.time = track.seen;
                unit.newlyConfirmed = false;
                unit.teamUncertain = false;
                unit.enemy = true;
                unit.enemyProbability = 0.90f;
                unit.teamConfidence = 0.90f;
                scene.units.add(unit);
                scene.markers++;
                scene.uncertain = true;
            }
        }

        tracks.clear(); tracks.addAll(nextBadgeTracks);
        rawTracks.clear(); rawTracks.addAll(nextRawTracks);
        float leftDanger = 0f, rightDanger = 0f;
        for (Unit unit : scene.units) {
            if (unit.teamUncertain && unit.enemyProbability < 0.62f) continue;
            float value = danger(unit);
            if (unit.x() > 345.5f) rightDanger += value; else leftDanger += value;
        }
        scene.right = rightDanger > leftDanger;
        for (Unit unit : scene.units) {
            if (unit.teamUncertain && unit.enemyProbability < 0.62f) continue;
            if ((unit.x() > 345.5f) == scene.right) {
                if (scene.main == null || danger(unit) > danger(scene.main)) scene.main = unit;
                if (splash(unit.name)) scene.splash = true;
                if (air(unit.name)) scene.air = true;
            }
        }
        if (scene.main != null) {
            StringBuilder names = new StringBuilder();
            Set<String> added = new HashSet<>();
            List<Unit> sorted = new ArrayList<>(scene.units);
            sorted.sort((a, b) -> Float.compare(danger(b), danger(a)));
            for (Unit unit : sorted) {
                if (unit.teamUncertain && unit.enemyProbability < 0.62f) continue;
                if ((unit.x() > 345.5f) == scene.right && added.add(unit.name) && added.size() <= 2) {
                    if (names.length() > 0) names.append(" + ");
                    names.append(label(unit.name));
                }
            }
            scene.summary = (scene.right ? "Direita" : "Esquerda") + " • " + names;
        } else if (scene.markers > 0) {
            scene.summary = "Unidade visivel • confirmando equipe e identidade";
        } else {
            scene.summary = "Sem inimigo identificado nesta leitura";
        }
        return scene;
    }

    private static Track nearestTrack(List<Track> source, Set<Track> used, float x, float y,
                                      long now, double maxDistance) {
        Track best = null;
        double nearest = maxDistance;
        for (Track track : source) {
            double distance = Math.hypot(track.x - x, track.y - y);
            if (!used.contains(track) && now - track.seen <= 1100L && distance < nearest) {
                best = track;
                nearest = distance;
            }
        }
        return best;
    }

    private static Unit nearestDetection(List<Unit> raw, Set<Unit> used, Badge badge, List<Badge> marks) {
        Unit best = null;
        double quality = -1.0;
        if (raw == null) return null;
        for (Unit unit : raw) {
            if (used.contains(unit) || unit == null || unit.confidence < 0.62f || outside(unit)
                    || "giant_snowball".equals(unit.name) || "phoenix_egg".equals(unit.name)) continue;
            double red = badgeDistance(unit, badge);
            if (red >= 1e6) continue;
            double blue = 1e6, otherRed = red;
            for (Badge marker : marks) {
                if (!marker.red) blue = Math.min(blue, badgeDistance(unit, marker));
                else otherRed = Math.min(otherRed, badgeDistance(unit, marker));
            }
            if (red > otherRed + 1 || red + 10 >= blue) continue;
            double score = unit.confidence - red * 0.003;
            if (score > quality) { best = unit; quality = score; }
        }
        return best;
    }

    private static String votedName(ArrayDeque<String> votes) {
        String best = "unknown";
        int bestCount = 0;
        for (String candidate : votes) {
            if (candidate == null || "?".equals(candidate) || "unknown".equals(candidate)) continue;
            int count = 0;
            for (String vote : votes) if (candidate.equals(vote)) count++;
            if (count > bestCount) { best = candidate; bestCount = count; }
        }
        return bestCount >= 2 && bestCount * 3 >= votes.size() * 2 ? best : "unknown";
    }

    private static Unit copy(Unit source, String name) {
        Unit out = new Unit(name, source.x1, source.y1, source.x2, source.y2, source.confidence);
        out.hits = source.hits;
        out.time = source.time;
        out.velocityY = source.velocityY;
        out.enemyProbability = source.enemyProbability;
        out.teamConfidence = source.teamConfidence;
        out.enemy = source.enemy;
        out.newlyConfirmed = source.newlyConfirmed;
        out.teamUncertain = source.teamUncertain;
        return out;
    }

    private static float clamp01(float value) { return Math.max(0f, Math.min(1f, value)); }

    static float iou(Unit a, Unit b) {
        float intersection = Math.max(0, Math.min(a.x2, b.x2) - Math.max(a.x1, b.x1))
                * Math.max(0, Math.min(a.y2, b.y2) - Math.max(a.y1, b.y1));
        float area = (a.x2 - a.x1) * (a.y2 - a.y1) + (b.x2 - b.x1) * (b.y2 - b.y1) - intersection;
        return intersection / Math.max(1f, area);
    }

    public static boolean air(String name) {
        return Arrays.asList("balloon", "bat", "electro_dragon", "flying_machine", "hungry_dragon",
                "inferno_dragon", "lava_hound", "lava_pup", "mega_minion", "minion", "phoenix_large",
                "phoenix_small", "skeleton_dragon").contains(name);
    }

    public static boolean splash(String name) {
        return Arrays.asList("witch", "wizard", "executioner", "hungry_dragon", "electro_dragon",
                "firecracker", "ice_wizard", "magic_archer", "dark_prince").contains(name);
    }

    public static boolean kite(String name) {
        return Arrays.asList("pekka", "minipekka", "knight", "prince", "elite_barbarian", "lumberjack").contains(name);
    }

    public static boolean buildingTarget(String name) {
        return Arrays.asList("hog_rider", "hog", "royal_hog", "ram_rider", "battle_ram", "giant", "golem",
                "golemite", "royal_giant", "electro_giant", "elixir_golem_large", "balloon", "lava_hound",
                "wall_breaker").contains(name);
    }

    static float danger(Unit unit) {
        float base = "unknown".equals(unit.name) ? 5f : kite(unit.name) ? 8f
                : buildingTarget(unit.name) ? 9f : splash(unit.name) ? 7f : 2f;
        return base * (0.5f + Math.max(0f, unit.y() - 400f) / 400f)
                * (0.65f + Math.max(0f, Math.min(1f, unit.enemyProbability)) * 0.35f);
    }

    public static String label(String name) {
        switch (name) {
            case "unknown": return "tipo incerto";
            case "guard": return "Guarda";
            case "musketeer": return "Mosqueteira";
            case "battle_healer": return "Curadora Guerreira";
            case "golden_knight": return "Cavaleiro Dourado";
            case "pekka": return "P.E.K.K.A";
            case "witch": return "Bruxa";
            case "minipekka": return "Mini P.E.K.K.A";
            case "knight": return "Cavaleiro";
            case "royal_recruit": return "Recruta Real";
            case "skeleton": return "Esqueleto";
            case "wizard": return "Mago";
            case "hog_rider": return "Corredor";
            case "giant": return "Gigante";
            case "golem": return "Golem";
            case "balloon": return "Balao";
            case "valkyrie": return "Valquiria";
            case "minion": return "Servo";
            case "hungry_dragon": return "Bebe Dragao";
            case "prince": return "Principe";
            case "mega_knight": return "Megacavaleiro";
            case "electro_wizard": return "Mago Eletrico";
            case "flying_machine": return "Maquina Voadora";
            case "rascal_girl": return "Menina Patife";
            case "rascal_boy": return "Menino Patife";
            default: return name == null ? "tipo incerto" : name.replace('_', ' ');
        }
    }
}
