package com.botclash.teste;

import java.util.ArrayList;
import java.util.List;

/**
 * Tactical candidate scorer. It is an explainable heuristic policy, not a
 * trained Clash Royale policy or a combat simulator.
 */
public final class TacticalEngine {
    private TacticalEngine() {}

    public static Advice.Suggestion defend(BattleState state) {
        Advice.Suggestion best = new Advice.Suggestion();
        best.reason = "Ameaca sem resposta compativel confirmada nesta mao.";
        if (!state.usable) return best;

        List<ThreatCandidate> candidates = new ArrayList<>();
        List<Enemy.Unit> allThreats = new ArrayList<>();
        for (Enemy.Unit unit : state.threats) { candidates.add(new ThreatCandidate(unit, false)); allThreats.add(unit); }
        for (Enemy.Unit unit : state.possibleThreats) { candidates.add(new ThreatCandidate(unit, true)); allThreats.add(unit); }

        double bestScore = -Double.MAX_VALUE;
        for (ThreatCandidate candidate : candidates) {
            Enemy.Unit target = candidate.unit;
            if (target.y() < 500f) continue;
            for (int slot = 0; slot < state.hand.cards.length; slot++) {
                if (!state.affordable(slot)) continue;
                int card = state.hand.cards[slot];
                double fit = effectiveness(card, target, state);
                if (candidate.probable) {
                    // For uncertain team/identity, only low-risk universal answers are offered.
                    if (card != 9 && card != 11 && card != 13) continue;
                    fit -= 2.5;
                }
                if (fit <= 0) continue;
                PlacementPlanner.Point point = PlacementPlanner.defense(card, target,
                        target.x() > 345.5f, allThreats);
                if (point == null) continue;
                double urgency = Math.max(0, target.y() - 530f) / 12.0
                        + (Enemy.buildingTarget(target.name) ? 18 : 0)
                        + (Enemy.splash(target.name) ? 9 : 0)
                        + (target.y() > 1080f ? 18 : 0);
                double score = urgency + fit * 10.0 - Vision.COST[card] * 1.5;
                if (candidate.probable) score -= 10.0;
                if (score <= bestScore) continue;
                bestScore = score;
                best.card = card;
                best.slot = slot;
                best.cost = Vision.COST[card];
                best.target = target;
                best.x = point.x;
                best.y = point.y;
                best.uncertainTarget = candidate.probable || "unknown".equals(target.name);
                best.confidence = best.uncertainTarget ? Math.min(0.72f, target.enemyProbability) : target.confidence;
                best.phase = target.y() < 760f ? "PREPARAR" : "DEFENDER";
                best.reason = (target.x() > 345.5f ? "Direita" : "Esquerda") + " • "
                        + Enemy.label(target.name) + (candidate.probable
                        ? ". Ameaca provavel: confira o lado antes de jogar."
                        : ". " + instruction(card));
            }
        }

        if (best.slot < 0 && !candidates.isEmpty()) {
            boolean distant = true;
            for (ThreatCandidate candidate : candidates) distant &= candidate.unit.y() < 650f;
            if (distant) best.reason = "Ameaca ainda distante: acompanhe a aproximacao e preserve elixir.";
        }
        return best;
    }

    static double effectiveness(int card, Enemy.Unit target, BattleState state) {
        String name = target.name;
        float y = target.y();
        if ("unknown".equals(name)) {
            if (card == 9) return y >= 650f ? 5.5 : 0;
            if (card == 11) return y >= 650f ? 5.0 : 0;
            if (card == 13) return y >= 760f ? 2.0 : 0;
            return 0;
        }
        boolean air = Enemy.air(name);
        boolean pull = Enemy.buildingTarget(name);
        boolean splash = Enemy.splash(name);
        boolean clusterSplash = splash;
        int group = 0;
        for (Enemy.Unit unit : state.threats) {
            if (Math.hypot(unit.x() - target.x(), unit.y() - y) < 210.0) {
                clusterSplash |= Enemy.splash(unit.name);
                group++;
            }
        }

        // Win conditions and spell-like pressure cards are not defensive fallbacks.
        if (card == 1 || card == 5 || card == 10) return 0;
        if (air && card != 6 && card != 7 && card != 9 && card != 11 && card != 13) return 0;
        if ((card == 4 || card == 9) && (y > 920f || y < 610f)) return 0;
        if ((card == 6 || card == 14) && (clusterSplash || state.uncertain)) return 0;
        if (card == 0) return !air && Enemy.kite(name) && y >= 650f && y <= 865f ? 8 : 0;
        if (card == 14) return !air && !pull && y >= 680f ? 2 : 0;
        if (card == 13) return y >= 700f ? 1.5 : 0;
        if (card == 9) return pull ? 10 : air ? 7 : 5;
        if (card == 4) return pull ? 9 : group >= 3 ? 8 : 4;
        if (card == 11) return air ? 10 : pull || Enemy.kite(name) ? 7 : 5;
        if (card == 7) return air ? 8 : group >= 3 ? 8 : 6;
        if (card == 6) return air ? 8 : group >= 3 ? 8 : 6;
        if (card == 3) return !air && y >= 700f && (Defense.swarm(name) || splash) ? 6 : 0;
        if (card == 8 || card == 2) return !air && y >= 630f ? (group >= 3 || splash ? 9 : 6) : 0;
        if (card == 12) return !air && y >= 630f ? (splash ? 8 : 6) : 0;
        return 0;
    }

    static String instruction(int card) {
        if (card == 0) return "Atraia ao centro; sera necessario dano de apoio.";
        if (card == 4 || card == 9) return "Construcao central para tentar atrair; confira a rota.";
        if (card == 11 || card == 7 || card == 6) return "Apoio afastado do grupo inimigo; preserve a distancia.";
        if (card == 13 || card == 14) return "Ganhe tempo; esta carta nao resolve sozinha o ataque.";
        if (card == 3) return "Role o barril na rota das tropas terrestres.";
        return "Intercepte pelo lado indicado, com apoio das torres.";
    }

    public static Advice.Suggestion pressure(BattleState state, boolean right) {
        return pressure(state, right, null);
    }

    public static Advice.Suggestion pressure(BattleState state, boolean right,
                                             OpponentElixirTracker.Snapshot opponent) {
        Advice.Suggestion out = new Advice.Suggestion();
        out.reason = "Guarde elixir para uma pressao com reserva defensiva.";
        if (!state.usable || state.scene.obstructed || state.hasUrgentThreat()) return out;

        // If the opponent is building on one lane but has not crossed, pressure the other.
        boolean enemyOnRight = false, enemyOnLeft = false;
        for (Enemy.Unit unit : state.threats) {
            if (unit.y() >= 650f) continue;
            if (unit.x() > 345.5f) enemyOnRight = true; else enemyOnLeft = true;
        }
        if (enemyOnRight != enemyOnLeft) right = !enemyOnRight;

        int defensiveReserve = 0;
        boolean reserveAvailable = false;
        for (int slot = 0; slot < state.hand.cards.length; slot++) {
            int card = state.hand.cards[slot];
            if (card < 0 || card >= Vision.COST.length) continue;
            if (card == 9 || card == 11 || card == 12 || card == 8) {
                reserveAvailable = true;
                defensiveReserve = Math.max(defensiveReserve, Math.min(3, Vision.COST[card]));
            }
        }
        if (!reserveAvailable) return out;
        defensiveReserve = Math.max(2, defensiveReserve);

        double best = -1.0;
        for (int slot = 0; slot < state.hand.cards.length; slot++) {
            if (!state.affordable(slot)) continue;
            int card = state.hand.cards[slot];
            int remaining = state.hand.elixir - Vision.COST[card];
            if (remaining < defensiveReserve + 1) continue;
            double score;
            float x = right ? 535f : 145f;
            float y;
            String reason;
            if (card == 10 && state.hand.elixir >= 7) {
                score = 10.0;
                y = 790f;
                reason = "Corredor na ponte; reserva defensiva mantida.";
            } else if (card == 1 && state.hand.elixir >= 6) {
                score = 8.0;
                x = right ? 550f : 140f;
                y = 360f;
                reason = "Pressao com Barril; confira a resposta de feitico do rival.";
            } else if (card == 12 && state.hand.elixir >= 9) {
                score = 5.0;
                x = right ? 440f : 250f;
                y = 1135f;
                reason = "Preparacao atras da torre do Rei; mantenha defesa disponivel.";
            } else {
                continue;
            }
            if (opponent != null && opponent.uncertainty() <= 3.0f && opponent.max <= 4.5f) {
                score += 1.5;
                reason += " O intervalo rival sugere pouco elixir, mas nao e certeza.";
            }
            if (score <= best) continue;
            best = score;
            out.card = card;
            out.slot = slot;
            out.cost = Vision.COST[card];
            out.x = x;
            out.y = y;
            out.phase = card == 12 ? "PREPARAR" : "ATACAR";
            out.reason = reason;
            out.confidence = opponent != null && opponent.uncertainty() <= 3.0f ? 0.75f : 0.60f;
        }
        return out;
    }

    private static final class ThreatCandidate {
        final Enemy.Unit unit;
        final boolean probable;
        ThreatCandidate(Enemy.Unit unit, boolean probable) { this.unit = unit; this.probable = probable; }
    }
}
