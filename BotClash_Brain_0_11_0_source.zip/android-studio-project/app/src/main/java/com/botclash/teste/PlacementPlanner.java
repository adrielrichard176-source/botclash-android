package com.botclash.teste;

import java.util.List;

/** Candidate grid in the normalized 691 x 1536 arena. Distances are heuristics. */
public final class PlacementPlanner {
    private PlacementPlanner() {}
    public static Point defense(int card, Enemy.Unit target, boolean right, List<Enemy.Unit> enemies) {
        float tx = target.x(), ty = target.y();
        if (card == 4 || card == 9) return new Point(right ? 380 : 311, 825);
        if (card == 0) return new Point(right ? 300 : 391, clamp(ty + 60, 795, 860));
        boolean ranged = card == 11 || card == 7 || card == 6;
        if (!ranged) {
            float desiredX = tx + (right ? -60 : 60);
            float desiredY = clamp(ty + (card == 3 ? 95 : 55), 785, 1145);
            return nearestLegal(desiredX, desiredY);
        }
        Point best = null; double bestScore = Double.MAX_VALUE;
        for (int y = 780; y <= 1150; y += 20) for (int x = 65; x <= 625; x += 20) {
            if (!legal(x, y)) continue;
            double distance = Math.hypot(x - tx, y - ty);
            if (distance > 330) continue;
            boolean safe = true;
            if (enemies != null) for (Enemy.Unit enemy : enemies) {
                double separation = Math.hypot(x - enemy.x(), y - enemy.y());
                if (separation < (Enemy.splash(enemy.name) ? 180 : 140)) { safe = false; break; }
            }
            if (distance < (Enemy.splash(target.name) ? 180 : 140) || !safe) continue;
            double score = Math.abs(distance - 200) + (y < ty ? 70 : 0)
                    + Math.abs(x - (right ? 425 : 266)) * .08;
            if (score < bestScore) { bestScore = score; best = new Point(x, y); }
        }
        return best; // Never output a fabricated safe point when none was found.
    }
    private static Point nearestLegal(float wantedX, float wantedY) {
        Point best = null; double distance = Double.MAX_VALUE;
        for (int y = 780; y <= 1150; y += 10) for (int x = 65; x <= 625; x += 10) {
            if (!legal(x, y)) continue;
            double d = Math.hypot(x - wantedX, y - wantedY);
            if (d < distance) { distance = d; best = new Point(x, y); }
        }
        return best;
    }
    public static boolean legal(float x, float y) {
        if (x < 65 || x > 626 || y < 775 || y > 1150) return false;
        // Conservative tower footprints, also excluded when a tower has fallen.
        if (y >= 865 && y <= 1005 && ((x >= 90 && x <= 200) || (x >= 490 && x <= 600))) return false;
        return !(x >= 275 && x <= 415 && y >= 960 && y <= 1130);
    }
    private static float clamp(float x, float min, float max) { return Math.max(min, Math.min(max, x)); }
    public static final class Point {
        public final float x, y;
        Point(float x, float y) { this.x = x; this.y = y; }
    }
}
