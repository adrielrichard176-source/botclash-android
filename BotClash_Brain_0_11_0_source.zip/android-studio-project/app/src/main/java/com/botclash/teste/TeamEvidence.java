package com.botclash.teste;

/**
 * Reads the colored health bar above a detected unit.
 * Coordinates use the normalized 691 x 1536 arena image.
 * This is evidence, not a guaranteed team label; temporal confirmation is
 * performed by Enemy before a unit becomes a confirmed opponent event.
 */
public final class TeamEvidence {
    public static final int UNKNOWN = 0;
    public static final int ENEMY = 1;
    public static final int FRIENDLY = 2;

    private TeamEvidence() {}

    public static Result classify(int[] pixels, Enemy.Unit unit) {
        if (pixels == null || pixels.length != 691 * 1536 || unit == null) {
            return new Result(UNKNOWN, 0f, 0, 0);
        }

        int left = clamp((int) Math.floor(unit.x1) - 5, 0, 690);
        int right = clamp((int) Math.ceil(unit.x2) + 5, 0, 690);
        int top = clamp((int) Math.floor(unit.y1) - 42, 0, 1535);
        int bottom = clamp((int) Math.floor(unit.y1) + 8, 0, 1535);
        if (right - left < 8 || bottom < top) {
            return new Result(UNKNOWN, 0f, 0, 0);
        }

        int redPixels = 0;
        int bluePixels = 0;
        int bestRedRun = 0;
        int bestBlueRun = 0;
        for (int y = top; y <= bottom; y++) {
            int redRun = 0;
            int blueRun = 0;
            for (int x = left; x <= right; x++) {
                int color = pixels[y * 691 + x];
                if (isEnemyRed(color)) {
                    redPixels++;
                    redRun++;
                    blueRun = 0;
                } else if (isFriendlyBlue(color)) {
                    bluePixels++;
                    blueRun++;
                    redRun = 0;
                } else {
                    redRun = 0;
                    blueRun = 0;
                }
                if (redRun > bestRedRun) bestRedRun = redRun;
                if (blueRun > bestBlueRun) bestBlueRun = blueRun;
            }
        }

        int minRun = Math.max(7, Math.min(18, (right - left + 1) / 5));
        boolean red = bestRedRun >= minRun && redPixels >= minRun * 2
                && redPixels > bluePixels * 1.35f;
        boolean blue = bestBlueRun >= minRun && bluePixels >= minRun * 2
                && bluePixels > redPixels * 1.35f;
        if (red == blue) return new Result(UNKNOWN, 0f, redPixels, bluePixels);

        int team = red ? ENEMY : FRIENDLY;
        int dominant = red ? redPixels : bluePixels;
        int other = red ? bluePixels : redPixels;
        float ratio = dominant / (float) Math.max(1, dominant + other);
        float runQuality = Math.min(1f, (red ? bestRedRun : bestBlueRun) / (float) (minRun * 2));
        float confidence = Math.min(0.98f, 0.55f + ratio * 0.30f + runQuality * 0.13f);
        return new Result(team, confidence, redPixels, bluePixels);
    }

    private static boolean isEnemyRed(int c) {
        int r = (c >>> 16) & 255;
        int g = (c >>> 8) & 255;
        int b = c & 255;
        return r >= 105 && r > g * 1.32f && r > b * 1.16f && g < 175;
    }

    private static boolean isFriendlyBlue(int c) {
        int r = (c >>> 16) & 255;
        int g = (c >>> 8) & 255;
        int b = c & 255;
        return b >= 105 && b > r * 1.18f && b > g * 1.04f && r < 175;
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    public static final class Result {
        public final int team;
        public final float confidence;
        public final int redPixels;
        public final int bluePixels;

        Result(int team, float confidence, int redPixels, int bluePixels) {
            this.team = team;
            this.confidence = confidence;
            this.redPixels = redPixels;
            this.bluePixels = bluePixels;
        }
    }
}
