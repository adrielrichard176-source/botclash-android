# BotClash Brain 0.11.0-alpha

## Reconstrucao inicial do motor de decisao

- Leitor de cartas consulta todas as 15 miniaturas locais, em vez de filtrar apenas o Deck 4.
- Novo `TeamEvidence` analisa barras de vida vermelhas/azuis.
- Rastreamento temporal combina evidencia de cor e movimento para classificar a equipe.
- `BattleState` separa ameacas confirmadas e provaveis.
- Ameaca provavel pode gerar somente uma recomendacao defensiva de baixa confianca, marcada como POSSIVEL.
- Estrategia separa tropas distantes de ameacas urgentes.
- Pressao ofensiva pode usar a faixa oposta a uma preparacao adversaria distante.
- Pausa apos carta propria: 0,9 s; janela de reavaliacao apos ameaca: 1,2 s.
- Elixir rival inicia como intervalo 0-10 se o guia pode comecar no meio da partida.
- Custos de Bebe Dragao e Maquina Voadora adicionados ao observador rival.
- Novo pacote Android separado: `com.botclash.teste.brain011`.

## Validacao

- 13 suites de testes Java passaram.
- 2.695 assercoes taticas passaram.
- Testes sinteticos de barra vermelha/azul e movimento temporal passaram.
- Nenhum novo treinamento do modelo ONNX foi realizado.
- Nenhuma compilacao Android ou partida real no POCO foi realizada nesta sessao.
