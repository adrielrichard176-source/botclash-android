# Gerar o APK BotClash Brain 0.11.0-alpha

O projeto-fonte inclui o app Android, os modelos ONNX, as miniaturas locais e 13 suites de testes Java. O APK ainda precisa ser compilado pelo GitHub Actions.

## Preparar o repositorio existente

Repositorio: https://github.com/adrielrichard176-source/botclash-android

1. Envie `BotClash_Brain_0_11_0_source.zip` para a raiz do repositorio.
2. Faca commit diretamente na branch `main`.
3. Edite `.github/workflows/build-android.yml` e substitua o conteudo pelo arquivo `GITHUB_ACTIONS_WORKFLOW.yml` deste pacote.
4. Faca commit do workflow.
5. Como o workflow dispara quando o ZIP novo e enviado, abra **Actions** e confira a execucao mais recente. Se necessario, use **Run workflow**.
6. Aguarde os 13 conjuntos de testes Java e a tarefa `:app:assembleDebug`.
7. Em **Artifacts**, baixe `BotClash-Brain-0.11.0-alpha-APK` e extraia o APK e `SHA256SUMS.txt`.

## Aviso sobre instalacao

- O novo pacote usa `applicationId` `com.botclash.teste.brain011`, por isso instala separado do Lab 0.10.0.
- Antes de testar, desative/pare o servico de acessibilidade do Lab 0.10.0 para evitar dois paineis e duas capturas ao mesmo tempo.
- A chave de assinatura do novo APK pode ser diferente; por isso o pacote foi separado em vez de tentar atualizar o 0.10.0.
- Mantenha o Google Play Protect ligado.
- O app continua no modo GUIA manual: nao executa gestos nem joga sozinho.
- Teste primeiro em treino/replay. Os testes Java nao provam precisao visual nem qualidade competitiva.
