# Comparação e validação — 14/11/2026

## Materiais inspecionados

- Android: https://github.com/adrielrichard176-source/botclash-android
  commit f7fa4394d58093aaa4390bdae37c555f0a00b5c9,
  arquivo BotClash_Android_0_9_0_Advanced_source.zip.
- ZIP anexado: um APK 0.9.0 e SHA256SUMS.txt; não contém projeto-fonte.
- Original: https://github.com/pyclashbot/py-clash-bot
  master, commit 34d11e577689510a75f3e5fac0104214102b664d.
- Instalador anexado: py-clash-bot-v3.3.0-macos.dmg. Não é um pacote Android.
  Não foi executado. O master consultado não necessariamente equivale à versão do DMG.
- Vídeo anexado: 8,82 segundos. Frame intermediário inspecionado: painel exibe
  elixir, mão inferida e simulação. Não foi localizado esse motor no master consultado.
  Não é possível identificar sua implementação só pelo vídeo.

## Achados no Android 0.9.0

| Local | Comportamento observado no código | Efeito provável |
|---|---|---|
| Strategy.java | Só abre com Corredor, elixir >=9, quatro cartas conhecidas | Passividade mesmo com carta utilizável |
| Strategy.java | Oito segundos de espera após ameaça desaparecer e após gasto | Contra-ataque e pressão tardios |
| Strategy.java | Barril sempre retido por falta de ciclo conhecido | Condição secundária nunca sugerida |
| Defense.java | Primeira carta de uma lista de opções | Não compara posicionamentos/custo/urgência de todos os candidatos |
| PlacementPlanner.java | Empurra apoio para baixo, saturando o limite | Distância mínima pode continuar insuficiente |
| Enemy.java | Detecção sem barra na metade superior ganha equipe inimiga | Pode contar aliado avançando como adversário |
| OpponentPlayObserver.java | Tropas recém-confirmadas viram gastos, inclusive entidades ambíguas | Gasto e deck rival podem ser fictícios |
| BotService.java | Estimativa rival calculada apenas para exibição | Histórico no painel não significa que a estratégia o utiliza |
| BotService.java | Esconde o guia em toda captura alternativa | Setas podem piscar |

## O que há no PyClashBot público consultado

`pyclashbot/bot/fight.py`, funções `select_card_index` e `play_a_card`, escolhem
entre cartas disponíveis com aleatoriedade e histórico recente de espaços.
`card_detection.py` define perfis e coordenadas de colocação. Isso é automação
por imagem e regras, não evidência de um solucionador mestre como no xadrez.
O repositório cita `rl-bot` em comentários, mas o motor exibido no vídeo não foi
identificado. Nenhum código do PyClashBot foi copiado para esta revisão Android.

## Validação executada

- 11 executáveis de testes Java passaram, incluindo reconhecimento limitado ao
  deck, transições próprias, eventos rivais e posicionamento.
- StrategyTest: 2.694 verificações em cenários sintéticos de cartas disponíveis,
  orçamento, ameaças em duas rotas, ar/solo, abertura e separação das tropas.
- AdviceTest legado: 120.960 combinações de invariantes de orçamento/papel/posição;
  não mede a inteligência do motor tático novo nem substitui partidas.
- Compilação de todas as classes Android e empacotamento ARM64.
- Assinatura e alinhamento do APK verificados.

Não executado: instalação em POCO, teste de acessibilidade no aparelho, FPS,
aquecimento, taxa de acerto do detector, integração em partida, taxa de vitórias.
O APK é uma entrega de desenvolvimento, não uma versão competitiva comprovada.

## Próximos trabalhos necessários para o objetivo completo

1. Criar conjunto de vídeos Android rotulados e medir equipe, identidade, posição,
   tempo até detecção e cartas da mão. Testar offline antes de gastar troféus.
2. Trocar confirmação por posição por rastreamento persistente de aliados/inimigos;
   unificar eventos para não confundir surgimento de esqueletos com carta jogada.
3. Detectar relógio/torres/feitiços e tratar elixir rival como crença incompleta,
   não como número verdadeiro. Ciclo só pode ser inferido com eventos suficientes.
4. Comparar ações com dados de alcance, velocidade, tempo de implantação e alvos;
   validar simulador/planner contra vídeos reais. As pontuações atuais não são isso.
5. Medir o modelo no aparelho e otimizar captura/inferência sem fila de quadros velhos.
