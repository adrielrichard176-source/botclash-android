# BotClash Brain 0.11.0-alpha — inicio rapido

Esta revisao parte do APK 0.10.0 enviado pelo usuario e corrige alguns bloqueios identificados no codigo.

## O que foi corrigido

- Leitura de cartas deixou de descartar identidades fora do Deck 4 quando existe miniatura local. O catalogo atual tem 15 identidades, ainda nao todas as cartas do jogo.
- Barra vermelha/azul e movimento entre quadros passam a ajudar a identificar a equipe das tropas.
- Ameacas confirmadas e provaveis ficam separadas. Uma ameaca provavel pode gerar apenas sugestao de baixa confianca.
- Tropas ainda no lado adversario nao bloqueiam automaticamente toda tentativa de pressao.
- A estrategia pode sugerir Corredor/Barril na faixa oposta a uma preparacao distante, mantendo reserva defensiva.
- Elixir rival comeca como intervalo 0-10 quando o guia pode ser iniciado no meio da partida.

## Instalar e usar

1. Compile o APK pelo GitHub Actions conforme `GITHUB_BUILD_PTBR.md`.
2. Instale `BotClash-Brain-0.11.0-alpha-debug.apk`.
3. Desative o servico de acessibilidade do BotClash Lab 0.10.0.
4. Abra BotClash Brain, autorize a Acessibilidade e abra o Clash Royale.
5. Use replay/partida de treino, toque GUIAR e confira as sugestoes antes de executar qualquer jogada.
6. PARAR encerra a captura. O aplicativo nao executa toques.

## Limites

- O modelo de 97 classes nao foi retreinado.
- A leitura da mao ainda usa RGB e 15 miniaturas locais.
- O perfil tatico continua configurado para Deck 4.
- A equipe por barra de vida/movimento e uma heuristica que precisa de validacao em imagens reais.
- Sem OCR completo de torres/cronometro, detector completo de feiticos, inferencia exata do ciclo rival ou simulacao de combate.
- A precisao, latencia e temperatura no POCO X6 Pro ainda nao foram medidas.

Veja `BRAIN_AUDIT_0_11.md` para a auditoria e `README.md` para compilacao e validacao.
