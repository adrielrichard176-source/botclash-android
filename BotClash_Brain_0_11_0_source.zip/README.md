# BotClash Brain Android 0.11.0-alpha

Esta revisao parte do APK BotClash-Lab-0.10.0.apk enviado pelo usuario. O objetivo desta fase e corrigir causas concretas da passividade defensiva e ofensiva, sem afirmar equivalencia com o PyClashBot original.

## Mudancas reais nesta revisao

- O reconhecimento da mao deixou de filtrar as leituras apenas para o Deck 4 e consulta todas as 15 identidades para as quais o APK 0.10.0 continha miniaturas RGB locais.
- Adicionado `TeamEvidence`: procura evidencias de barra de vida vermelha/azul acima de cada caixa detectada.
- O rastreador de tropas agora combina cor da barra e deslocamento entre quadros para classificar a equipe temporalmente. A ausencia de evidencia continua sendo tratada como incerta.
- `BattleState` separa ameacas confirmadas de ameacas provaveis. Uma unidade provavel pode gerar somente uma sugestao defensiva de baixo risco, claramente marcada para confirmacao.
- `Strategy` distingue tropas ainda distantes de ameacas urgentes. Uma tropa no lado adversario nao bloqueia automaticamente toda pressao ofensiva.
- A espera depois de uma ameaca foi reduzida de 4 s para uma janela de reavaliacao de 1,2 s; apos uma carta propria, a pausa e 0,9 s.
- A pressao pode escolher a faixa oposta a uma preparacao adversaria distante e conserva uma carta defensiva de custo medio.
- O elixir rival nao parte mais de 5 exatos quando GUIAR pode ser iniciado no meio da partida. O estado inicial agora e 0-10; uma faixa mais estreita depende de jogadas confirmadas. Existe uma API separada para inicio de partida confirmado, ainda nao ligada a um detector de cronometro.
- Mapeados custos de unidades adicionais, incluindo Bebe Dragao e Maquina Voadora.
- Diagnostico e interface informam quando a sugestao usa uma ameaca provavel.

## O que ainda nao foi resolvido

- O catalogo visual local tem apenas 15 identidades de cartas. Isso nao e reconhecimento universal de todas as cartas do Clash Royale. Cartas fora desse catalogo continuam podendo aparecer como `?`.
- O modelo ONNX de 97 classes e o mesmo do 0.10.0. Essas classes descrevem unidades no campo, nao o catalogo completo de cartas/arte das cartas. Nao houve novo treinamento nem validacao de mAP neste trabalho.
- A classificacao por barra de vida e movimento e heuristica. Os testes atuais usam imagens sinteticas; precisa ser calibrada com replays reais em diferentes resolucoes, animacoes e efeitos.
- Nao ha OCR confiavel da vida das torres ou do cronometro, deteccao completa de feiticos, inferencia completa das oito cartas rivais, simulacao de dano/pathfinding ou politica treinada.
- O app continua no modo GUIA: captura local, analisa e mostra setas. `canPerformGestures=false`; nao executa toques nem joga sozinho.
- O perfil tatico continua baseado no Deck 4 configurado anteriormente. Se a partida de treino usar outro deck, a leitura de algumas cartas pode melhorar, mas as regras taticas precisam de perfil/custos/funcao especificos.
- O APK Android ainda nao foi compilado nesta sessao nem testado no POCO X6 Pro. O workflow GitHub Actions foi preparado para essa compilacao.

## Validacao local

Execute:

```bash
bash scripts/run-pure-tests.sh
```

Resultado desta revisao: 13 suites de testes Java passaram, incluindo 2.695 assercoes taticas, testes sinteticos de barra de vida vermelha/azul, confirmacao temporal de equipe, ameaca provavel, pressao na faixa oposta e intervalo de elixir rival.

Esses testes nao simulam uma partida real, nao medem precisao visual e nao provam taxa de vitoria.

## Compilar

- Java 17
- Android Gradle Plugin 8.13.2
- Gradle 8.13.2
- Android SDK / Build Tools 35
- ONNX Runtime Android 1.23.2

Com Android SDK e Gradle configurados:

```bash
gradle -p android-studio-project --no-daemon :app:assembleDebug
```

O workflow `GITHUB_ACTIONS_WORKFLOW.yml` gera o artefato `BotClash-Brain-0.11.0-alpha-APK`.

## Pacote e seguranca

- `applicationId`: `com.botclash.teste.brain011` (instala separado do Lab 0.10.0).
- Android 11 ou posterior; ARM64 esperado pelo runtime ONNX incluido.
- Acessibilidade permite captura de tela; gestos globais permanecem desativados.
- Mantenha o Google Play Protect ligado e teste primeiro em treino/replay.
- Licencas e avisos acompanham `licenses/` e `app/src/main/assets/licenses/`.
