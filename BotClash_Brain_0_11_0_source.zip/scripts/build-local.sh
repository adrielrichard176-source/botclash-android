#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="$ROOT/android-studio-project/app/src/main"
: "${ANDROID_SDK_ROOT:?Set Android SDK path}"
: "${ECJ_JAR:?Set Eclipse Java compiler jar path}"
: "${ORT_DIR:?Directory with classes.jar and jni/arm64-v8a from onnxruntime-android 1.23.2}"
BT="$ANDROID_SDK_ROOT/build-tools/35.0.0"
PLATFORM="$ANDROID_SDK_ROOT/platforms/android-35/android.jar"
OUT="$ROOT/build"
mkdir -p "$OUT/classes" "$OUT/dex"
java -jar "$ECJ_JAR" -8 -proc:none -nowarn -cp "$PLATFORM:$ORT_DIR/classes.jar" -d "$OUT/classes" "$APP"/java/com/botclash/teste/*.java
"$BT/aapt2" compile --dir "$APP/res" -o "$OUT/res.zip"
python3 - "$APP/AndroidManifest.xml" "$OUT/AndroidManifest.xml" <<'PYXML'
from pathlib import Path
import sys
text=Path(sys.argv[1]).read_text()
text=text.replace('<manifest ', '<manifest package="com.botclash.teste.lab" ', 1)
Path(sys.argv[2]).write_text(text)
PYXML
"$BT/aapt2" link -o "$OUT/base.apk" -I "$PLATFORM" --manifest "$OUT/AndroidManifest.xml" "$OUT/res.zip"
"$BT/d8" --lib "$PLATFORM" --min-api 30 --output "$OUT/dex" "$ORT_DIR/classes.jar" "$OUT"/classes/com/botclash/teste/*.class
python3 - "$ROOT" "$ORT_DIR" <<'PY'
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import sys
root=Path(sys.argv[1]);ort=Path(sys.argv[2]);app=root/'android-studio-project/app/src/main'
with ZipFile(root/'build/base.apk','a',compression=ZIP_DEFLATED,compresslevel=9) as z:
 for p in (root/'build/dex').glob('*.dex'): z.write(p,p.name)
 for p in (ort/'jni/arm64-v8a').glob('*.so'): z.write(p,'lib/arm64-v8a/'+p.name)
 for p in (app/'assets').rglob('*'):
  if p.is_file():z.write(p,'assets/'+str(p.relative_to(app/'assets')))
 for p in root.rglob('*'):
  rel=p.relative_to(root)
  if p.is_file() and 'build' not in rel.parts and 'assets' not in rel.parts and not p.name.startswith('.'):
   z.write(p,'assets/source/'+str(rel))
PY
"$BT/zipalign" -f -P 16 4 "$OUT/base.apk" "$OUT/aligned.apk"
if [[ -n "${BOTCLASH_KEYSTORE:-}" ]]; then
 : "${BOTCLASH_KEY_ALIAS:?Set signing alias}"
 : "${BOTCLASH_KEY_PASS:?Set signing password}"
 "$BT/apksigner" sign --ks "$BOTCLASH_KEYSTORE" --ks-key-alias "$BOTCLASH_KEY_ALIAS" --ks-pass env:BOTCLASH_KEY_PASS --out "$OUT/BotClash-Brain-0.11.0-alpha.apk" "$OUT/aligned.apk"
 "$BT/apksigner" verify --verbose "$OUT/BotClash-Brain-0.11.0-alpha.apk"
else
 echo 'Unsigned aligned APK: build/aligned.apk; sign before installation.'
fi
