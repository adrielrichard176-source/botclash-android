#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="$ROOT/android-studio-project/app/src/main/java/com/botclash/teste"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
mapfile -t sources < <(find "$APP" -name '*.java' ! -name BotService.java ! -name MainActivity.java ! -name EnemyModel.java)
if command -v javac >/dev/null; then
 javac -encoding UTF-8 -d "$OUT" "${sources[@]}" "$ROOT"/tests/*.java
else
 : "${ECJ_JAR:?Set ECJ_JAR to Eclipse compiler jar when javac is unavailable}"
 java -jar "$ECJ_JAR" -17 -proc:none -encoding UTF-8 -d "$OUT" "${sources[@]}" "$ROOT"/tests/*.java
fi
for source in "$ROOT"/tests/*Test.java; do
 test="$(basename "$source" .java)"
 java -cp "$OUT" "$test"
done
