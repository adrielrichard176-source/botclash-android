# Auditoria tecnica e reconstrucao do cerebro — 0.11.0-alpha

## Fonte auditada

- Arquivo recebido: `BotClash-Lab-0.10.0.apk`.
- SHA-256 do APK de entrada: `2fb1c23feca1bc531fae931414309361ac150d66bb24b8f3cdfb42a091ab946b`.
- O APK continha codigo Java em `assets/source`, o modelo `assets/enemy/units_int8.onnx`, nomes de classes e miniaturas RGB em `assets/vision`.
- O projeto Android foi reconstruido a partir desses arquivos. Os modelos e miniaturas foram recolocados em `app/src/main/assets`, porque nao estavam dentro da pasta de fontes embutida.

## Causas encontradas no 0.10.0

### 1. Cartas filtradas pelo Deck 4

`Vision.read()` e `Vision.matchNext()` chamavam `DeckProfile.contains(id)`. Isso limitava o reconhecimento as oito cartas do perfil Deck 4, apesar de existirem miniaturas locais para 15 identidades. Uma carta fora das oito era descartada antes da classificacao e podia aparecer como `?` mesmo quando havia template local.

**Correcao 0.11:** o leitor consulta as 15 identidades com miniaturas. Continua limitado a esse catalogo local; nao e um classificador universal.

### 2. Equipe incerta bloqueava a defesa

O fallback de `Enemy` podia acompanhar caixas ONNX sem conseguir ler o emblema/numero de nivel. Essas unidades ficavam com `teamUncertain=true`. `BattleState` descartava unidades com equipe incerta da lista de ameacas, e `TacticalEngine.defend()` nao recebia alvo para escolher resposta.

**Correcao 0.11:** `TeamEvidence` procura uma barra vermelha/azul acima da caixa. Se a barra nao for encontrada, o rastreador usa deslocamento temporal como evidencia secundaria. A equipe so e confirmada depois de evidencia repetida. Unidades ainda incertas podem gerar alerta de baixa confianca apenas quando a posicao/movimento indica risco; a sugestao fica marcada como POSSIVEL e limitada a Tesla, Mosqueteira ou Espirito de Gelo.

### 3. Tropas distantes bloqueavam ataques

A politica anterior tratava qualquer unidade detectada ou qualquer incerteza como ameaca geral. Uma unidade ainda no lado adversario podia impedir pressao ofensiva. Havia tambem uma espera de ate quatro segundos apos uma ameaca e tres segundos apos gasto proprio.

**Correcao 0.11:** `BattleState.hasUrgentThreat()` separa ameacas urgentes de unidades distantes. A estrategia pode pressionar a faixa oposta quando a unidade adversaria ainda esta distante, respeitando reserva defensiva. A janela de reavaliacao foi reduzida.

### 4. Elixir rival iniciava em 5 exatos mesmo ao entrar no meio da partida

`OpponentElixirTracker.reset()` definia min=max=5. Se GUIAR fosse iniciado com a partida em andamento, esse valor inventava uma linha de base.

**Correcao 0.11:** o reset normal passa a iniciar em intervalo 0-10. `resetAtMatchStart()` mantem a possibilidade de iniciar em 5 apenas quando o inicio da partida for detectado com confianca. Esse detector ainda nao existe; portanto, a interface mostra a linha de base como desconhecida.

### 5. Custos ausentes no observador rival

O mapa de custos nao cobria algumas unidades observadas no teste, como `hungry_dragon` (Bebe Dragao) e `flying_machine` (Maquina Voadora).

**Correcao 0.11:** foram adicionados custos conhecidos para essas e outras classes. Uma unidade so gera evento de carta se for confirmada como rival e o evento temporal nao estiver duplicado.

## Pipeline 0.11

1. Captura da tela e normalizacao para 691 x 1536.
2. Detector ONNX de unidades (97 classes, modelo inalterado).
3. Classificacao da equipe por barra de vida e movimento temporal.
4. Rastreamento e deduplicacao de unidades/eventos.
5. Leitura das cartas: 15 templates RGB locais, sem filtro fixo de oito cartas.
6. Estado de batalha: mao valida, elixir, ameacas confirmadas e provaveis.
7. Motor tatico: defesa urgente, preparacao e pressao ofensiva.
8. Posicionamento heuristico e seta visual para confirmacao manual.

## Testes adicionados/alterados

- Barra de vida vermelha -> evidencia de adversario.
- Barra de vida azul -> evidencia de aliado.
- Ausencia de barra -> equipe permanece desconhecida.
- Tres movimentos consistentes para o lado do jogador -> confirmacao temporal de equipe.
- Equipe incerta em aproximacao -> sugestao defensiva de baixa confianca, explicitamente marcada.
- Unidade adversaria distante -> nao bloqueia automaticamente a pressao; a carta de ataque vai para a faixa oposta.
- Elixir rival com inicio desconhecido -> intervalo amplo, sem fingir que comecou em 5.
- Bebe Dragao e Maquina Voadora -> custos mapeados para eventos confirmados.
- Catalogo de cartas -> templates locais fora do Deck 4 nao sao descartados.

## Limites e criterios de aceite antes de um proximo APK

- Medir precisao/recall por classe em replays que nao participaram do treinamento.
- Validar equipe por barra vermelha/azul em resolucoes, brilho, animacoes e sobreposicoes reais.
- Medir falsos positivos de movimento (tropas aliadas, tropas paradas e efeitos).
- Expandir o catalogo de cartas para o conjunto atual do jogo e treinar/validar classificador dedicado de mao.
- Implementar OCR/ancoras de torres e cronometro, detector de feiticos e inferencia de ciclo rival.
- Executar testes em replays no POCO X6 Pro, medindo latencia e estabilidade termica.
- Nao habilitar execucao de gestos ate que a percepcao e a decisao passem pelos criterios de aceite.

## Referencias publicas para a proxima fase

- PyClashBot: https://github.com/pyclashbot/py-clash-bot
- RoyaleTrainer: https://www.royaletrainer.com/ (anotacoes de posicao, tipo, lado, vida das torres e cartas da mao)
- Documentacao publica do endpoint de cartas: https://github.com/jthingelstad/cr-agent-api-docs/blob/main/cards.md

Nenhuma base externa de imagens ou pesos novos foi incorporada nesta revisao. A expansao do catalogo e do treinamento sera uma fase separada, com licencas e procedencia verificadas.
