# Gerar o APK BotClash Android 0.9.0-alpha

Este pacote contém o projeto Android e o workflow GitHub Actions. O APK precisa ser compilado pelo GitHub Actions com Android SDK/Build Tools e Gradle.

## O que o workflow faz

1. Baixa o repositório.
2. Configura Java 17 e Android SDK usando `android-actions/setup-android@v4`.
3. Instala Android Platform 35, Build Tools 35.0.0 e Platform Tools.
4. Executa onze conjuntos de testes Java puros.
5. Compila `:app:assembleDebug`.
6. Publica o APK e o SHA-256 como artefato e release de pré-lançamento `v0.9.0-alpha`.

## Atualizar seu repositório pelo Android

O repositório existente é `adrielrichard176-source/botclash-android`.

1. Baixe `BotClash_Android_0_9_0_Advanced_source.zip` deste pacote.
2. Abra a raiz do seu repositório no GitHub e remova o ZIP antigo `BotClash_Android_0_8_2_Deck4_source.zip` (ou deixe-o arquivado fora da raiz).
3. Use **Add file → Upload files** e envie `BotClash_Android_0_9_0_Advanced_source.zip` para a raiz. Faça commit.
4. Abra `.github/workflows/build-android.yml`, toque em Edit e substitua o conteúdo pelo arquivo `GITHUB_ACTIONS_WORKFLOW.yml` deste pacote. Confirme o commit.
5. Abra **Actions**. Se o workflow não iniciar automaticamente, abra **BotClash Android APK** e toque em **Run workflow**.
6. Aguarde os testes e a compilação. Em **Artifacts**, baixe `BotClash-Android-0.9.0-debug-APK`. A página **Releases** também recebe `BotClash-Android-0.9.0-debug.apk`.
7. Extraia o ZIP do artefato, instale o APK e mantenha o Google Play Protect ligado.

## Importante

- O APK é `debug`, assinado com chave de teste do Android Gradle Plugin.
- `applicationId` de debug é `com.botclash.teste.debug`.
- Esta versão é GUIA manual: captura, analisa e mostra setas; você confirma e realiza os toques. Não há execução automática.
- Use treino/replay para validar. As novas funções são experimentais e não garantem precisão ou vitória.
- Preserve AGPL-3.0 e avisos de terceiros ao redistribuir.
