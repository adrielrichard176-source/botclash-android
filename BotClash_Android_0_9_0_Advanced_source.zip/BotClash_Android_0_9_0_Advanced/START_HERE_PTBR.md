# BotClash Android 0.9.0-alpha — início rápido

Esta versão deixa de tratar cada captura como uma leitura isolada. Ela acrescenta memória temporal para a mão própria, observações do deck rival e fase de elixir, além de manter a leitura da arena mesmo quando a mão está incerta.

## O que mudou

- Detector de tropas continua rodando quando a leitura da mão falha.
- Fallback temporal para caixas ONNX sem barra de vida reconhecida, com confirmação em mais de um frame e salvaguarda de lado.
- `OwnDeckTracker`: registra cartas próprias somente após transição estável e compatível com o ciclo de quatro cartas.
- `OpponentDeckTracker`: lista cartas rivais vistas e histórico recente; não inventa a mão adversária.
- `BattlePhaseTracker`: estima fase de regeneração a partir do próprio elixir; precisa de várias janelas para confirmar.
- `PlacementPlanner`: separa apoio à distância da ameaça e usa zonas específicas para construções/distrações.
- Modo GUIA manual: o app sugere; você confirma e faz os toques.

## Limites importantes

- A mão própria ainda depende das amostras RGB e pode retornar `?`.
- O deck rival é parcial e baseado em tropas confirmadas. Feitiços e edifícios podem não entrar no histórico; a mão rival não é inferida.
- O elixir rival parte de 5 quando GUIAR é iniciado. Se iniciar no meio da partida, a faixa pode estar errada.
- A fase de elixir é estimada, não lida por cronômetro OCR.
- Não há OCR da vida das torres, detector de feitiços, habilidade do Cavaleiro Herói nem toques automáticos.
- O detector e posicionamento precisam de validação em treino/replay no POCO X6 Pro.

## Testes locais

Execute `bash scripts/run-pure-tests.sh`. Onze conjuntos de testes passaram nesta revisão. Eles validam lógica Java isolada, não a integração Android nem uma partida real.

## Seu Deck 4

Corredor, Cavaleiro Herói, Mosqueteira, Esqueletos, Tesla, Príncipe das Trevas, Barril de Goblins e Espírito de Gelo. Média 3,0.

## Compilar APK

Siga `GITHUB_BUILD_PTBR.md`. O APK 0.9.0 deve ser compilado pelo workflow GitHub Actions. Não foi compilado nesta sessão.
