package com.botclash.teste;

import java.util.List;

/** Card-role placement planner in the normalized 691 x 1536 arena coordinate space. */
public final class PlacementPlanner {
    private PlacementPlanner() {}

    public static Point defense(int card, Enemy.Unit threat, boolean right, List<Enemy.Unit> nearby) {
        float tx = threat.x();
        float ty = threat.y();
        float x;
        float y;

        if (card == 9 || card == 4) { // Tesla / Bomb Tower: central pull zone.
            x = 345.5f + (right ? 34.0f : -34.0f);
            y = clamp(ty + 105.0f, 820.0f, 1015.0f);
        } else if (card == 11 || card == 7 || card == 6) { // Ranged / anti-air support.
            x = clamp(tx + (right ? -92.0f : 92.0f), 65.0f, 626.0f);
            y = clamp(ty + 150.0f, 850.0f, 1110.0f);
            if (distance(x, y, tx, ty) < 130.0f) y = clamp(y + 55.0f, 850.0f, 1150.0f);
        } else if (card == 14) { // Skeletons: side distraction, not on top of splash units.
            x = clamp(tx + (right ? -68.0f : 68.0f), 65.0f, 626.0f);
            y = clamp(ty + 28.0f, 790.0f, 1110.0f);
        } else if (card == 13) { // Ice Spirit: delay and freeze.
            x = clamp(tx + (right ? -38.0f : 38.0f), 65.0f, 626.0f);
            y = clamp(ty + 48.0f, 800.0f, 1110.0f);
        } else if (card == 12 || card == 8 || card == 2) { // Hero Knight / Dark Prince / melee.
            x = clamp(tx + (right ? -34.0f : 34.0f), 65.0f, 626.0f);
            y = clamp(ty + 68.0f, 805.0f, 1120.0f);
        } else { // Conservative generic placement.
            x = clamp(tx + (right ? -70.0f : 70.0f), 65.0f, 626.0f);
            y = clamp(ty + 115.0f, 835.0f, 1110.0f);
        }

        // Keep ranged support away from the target and avoid stacking on a known cluster.
        if (card == 11 || card == 7 || card == 6) {
            for (int pass = 0; pass < 3; pass++) {
                boolean crowded = false;
                if (nearby != null) {
                    for (Enemy.Unit unit : nearby) {
                        if (unit == null || unit == threat) continue;
                        if (distance(x, y, unit.x(), unit.y()) < 105.0f) {
                            crowded = true;
                            break;
                        }
                    }
                }
                if (!crowded && distance(x, y, tx, ty) >= 130.0f) break;
                y = clamp(y + 42.0f, 850.0f, 1160.0f);
            }
        }
        return new Point(x, y);
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private static float distance(float ax, float ay, float bx, float by) {
        return (float) Math.hypot(ax - bx, ay - by);
    }

    public static final class Point {
        public final float x;
        public final float y;
        Point(float x, float y) { this.x = x; this.y = y; }
    }
}
