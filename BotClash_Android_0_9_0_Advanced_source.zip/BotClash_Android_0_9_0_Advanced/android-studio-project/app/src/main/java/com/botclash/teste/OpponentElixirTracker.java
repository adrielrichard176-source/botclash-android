package com.botclash.teste;

/**
 * Conservative opponent-elixir estimator.
 *
 * It intentionally returns a range, not a fabricated exact value. The caller
 * must report a card play only once, after a newly observed play is confirmed.
 * All times are monotonic elapsed-realtime milliseconds.
 */
public final class OpponentElixirTracker {
    public static final float MAX_ELIXIR = 10.0f;
    public static final float START_ELIXIR = 5.0f;
    public static final long SINGLE_ELIXIR_PERIOD_MS = 2800L;

    private float minElixir = START_ELIXIR;
    private float maxElixir = START_ELIXIR;
    private long lastUpdateMs = -1L;
    private long lastPlayMs = -1L;
    private String lastEventKey = "";

    public synchronized void reset(long nowMs) {
        minElixir = START_ELIXIR;
        maxElixir = START_ELIXIR;
        lastUpdateMs = nowMs;
        lastPlayMs = -1L;
        lastEventKey = "";
    }

    /**
     * Advances regeneration. multiplier must be 1.0, 2.0 or 3.0 for the
     * currently observed game phase. If phase is uncertain, pass 1.0.
     */
    public synchronized Snapshot snapshot(long nowMs, float multiplier) {
        advance(nowMs, multiplier);
        return new Snapshot(minElixir, maxElixir, nowMs, lastPlayMs);
    }

    /**
     * Records one opponent card play with a cost interval.
     *
     * @return false if the same visual event was already counted.
     */
    public synchronized boolean onCardPlayed(
            long nowMs,
            float multiplier,
            String eventKey,
            int minCost,
            int maxCost,
            float confidence) {
        advance(nowMs, multiplier);
        String key = eventKey == null ? "" : eventKey.trim();
        if (!key.isEmpty() && key.equals(lastEventKey)
                && lastPlayMs >= 0 && nowMs - lastPlayMs < 2200L) {
            return false;
        }

        int low = clampCost(Math.min(minCost, maxCost));
        int high = clampCost(Math.max(minCost, maxCost));
        float c = Math.max(0.0f, Math.min(1.0f, confidence));

        // When visual confidence is weak, widen the cost interval instead of
        // pretending the card identity is certain.
        if (c < 0.55f) {
            low = Math.max(1, low - 1);
            high = Math.min(9, high + 2);
        } else if (c < 0.80f && low == high) {
            low = Math.max(1, low - 1);
            high = Math.min(9, high + 1);
        }

        // The minimum possible remaining elixir pays the largest possible
        // cost; the maximum possible remaining elixir pays the smallest.
        minElixir = clampElixir(minElixir - high);
        maxElixir = clampElixir(maxElixir - low);
        if (minElixir > maxElixir) minElixir = maxElixir;

        lastPlayMs = nowMs;
        if (!key.isEmpty()) lastEventKey = key;
        return true;
    }

    private void advance(long nowMs, float multiplier) {
        if (lastUpdateMs < 0L) {
            lastUpdateMs = nowMs;
            return;
        }
        if (nowMs <= lastUpdateMs) return;
        float safeMultiplier = multiplier >= 2.5f ? 3.0f
                : multiplier >= 1.5f ? 2.0f : 1.0f;
        float gained = (nowMs - lastUpdateMs) * safeMultiplier
                / (float) SINGLE_ELIXIR_PERIOD_MS;
        minElixir = clampElixir(minElixir + gained);
        maxElixir = clampElixir(maxElixir + gained);
        lastUpdateMs = nowMs;
    }

    private static int clampCost(int cost) {
        return Math.max(0, Math.min(10, cost));
    }

    private static float clampElixir(float value) {
        return Math.max(0.0f, Math.min(MAX_ELIXIR, value));
    }

    public static final class Snapshot {
        public final float min;
        public final float max;
        public final long atMs;
        public final long lastPlayMs;

        Snapshot(float min, float max, long atMs, long lastPlayMs) {
            this.min = min;
            this.max = max;
            this.atMs = atMs;
            this.lastPlayMs = lastPlayMs;
        }

        public float uncertainty() { return max - min; }
        public boolean isNarrow() { return uncertainty() <= 1.25f; }
        public String label() {
            return String.format(java.util.Locale.US, "%.1f–%.1f", min, max);
        }
    }
}
