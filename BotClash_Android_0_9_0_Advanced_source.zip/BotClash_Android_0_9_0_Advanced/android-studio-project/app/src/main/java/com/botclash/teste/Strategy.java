package com.botclash.teste;

import java.util.Arrays;

/** Stateful, bounded guidance. An empty detector result never proves a safe attack. */
public final class Strategy {
    private long clearSince = -1, lastThreat = -1, playedAt = -10000;
    private int lastElixir = -1;
    private int[] lastHand;
    private int stable;

    public void noteOwnCardPlayed(long now) {
        playedAt = now;
        clearSince = -1;
    }

    public void reset() {
        clearSince = -1;
        lastThreat = -1;
        playedAt = -10000;
        lastElixir = -1;
        lastHand = null;
        stable = 0;
    }

    public Advice.Suggestion choose(Vision.Reading r, Enemy.Scene s, long now) {
        Advice.Suggestion a = new Advice.Suggestion();
        a.reason = "Aguardando uma leitura atual da partida.";
        if (!r.valid || s == null || now - s.time > 1400) return a;

        boolean same = lastHand != null && Arrays.equals(lastHand, r.cards);
        stable = same ? stable + 1 : 1;
        if (lastHand != null && r.elixir >= 0 && lastElixir - r.elixir >= 2) {
            playedAt = now;
            clearSince = -1;
        }
        lastHand = r.cards.clone();
        lastElixir = r.elixir;

        boolean threat = s.markers > 0 || s.main != null || s.uncertain || !s.units.isEmpty();
        if (threat) {
            clearSince = -1;
            lastThreat = now;
        } else if (clearSince < 0) {
            clearSince = now;
        }

        if (r.elixir < 0) {
            a.reason = "Elixir incerto. Aguarde a leitura; confira a defesa.";
            return a;
        }
        if (now - playedAt < 900) {
            a.reason = "Carta jogada. Reavaliando antes de gastar mais.";
            return a;
        }
        if (s.main != null || !s.units.isEmpty()) return Defense.choose(r, s, now);
        if (threat) {
            a.reason = "Ameaça em confirmação. Prepare a defesa; posição ainda incerta.";
            return a;
        }

        long quiet = lastThreat < 0 ? 2500 : 8000;
        if (clearSince < 0 || now - clearSince < quiet || stable < 2) {
            a.reason = lastThreat >= 0
                    ? "Ataque perdeu visibilidade. Confira a arena antes de avançar."
                    : "Observando a abertura. Guarde elixir por enquanto.";
            return a;
        }
        if (now - playedAt < 8000) {
            a.reason = "Reponha elixir e confira a defesa antes de outra pressão.";
            return a;
        }
        if (r.elixir < 9) {
            a.reason = "Junte elixir; mantenha uma carta para responder ao adversário.";
            return a;
        }
        for (int c : r.cards) {
            if (c < 0) {
                a.reason = "Elixir alto, mas há carta incerta. Confira a mão.";
                return a;
            }
        }

        boolean reserve = false;
        for (int c : r.cards) if (DeckProfile.isReserveCard(c)) reserve = true;
        if (reserve) {
            // Corredor is the primary win condition in this deck. Hero Knight is
            // held as a defensive/interception card, not spent as an opening push.
            for (int slot = 0; slot < 4; slot++) {
                int card = r.cards[slot];
                if (!DeckProfile.isPrimaryWinCondition(card)) continue;
                a.card = card;
                a.slot = slot;
                a.cost = Vision.COST[card];
                a.x = 145;
                a.y = 790;
                a.reason = "Corredor: pressão pela esquerda sugerida somente com arena sem ameaça confirmada; reserve elixir para Tesla, Mosqueteira ou Cavaleiro.";
                return a;
            }
        }

        boolean barrel = false;
        for (int c : r.cards) barrel |= DeckProfile.isSecondaryWinCondition(c);
        a.reason = barrel
                ? "Barril de Goblins reconhecido como condição secundária. Não sugerido automaticamente: ainda falta leitura confiável do feitiço pequeno e do ciclo do adversário."
                : "Mantenha defesa e elixir. Aguarde o Corredor ou uma defesa reconhecida.";
        return a;
    }
}
