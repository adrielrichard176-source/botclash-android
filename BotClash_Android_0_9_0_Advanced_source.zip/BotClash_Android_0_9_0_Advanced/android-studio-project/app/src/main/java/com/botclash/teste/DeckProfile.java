package com.botclash.teste;

/** User-configured Deck 4. Card ids refer to Vision.NAMES/COST. */
public final class DeckProfile {
    private DeckProfile() {}

    public static final String NAME = "Deck 4 • Corredor / Cavaleiro Herói";
    public static final int AVERAGE_ELIXIR_TENTHS = 30;

    public static final class Card {
        public final int id, cost, level;
        public final String role;
        Card(int id, int cost, int level, String role) {
            this.id = id; this.cost = cost; this.level = level; this.role = role;
        }
    }

    public static final Card[] CARDS = {
        new Card(10, 4, 11, "Condição de vitória principal"), // Corredor
        new Card(12, 3, 10, "Defesa/interceptação; herói"),   // Cavaleiro Herói
        new Card(11, 4, 8, "Defesa aérea e suporte"),         // Mosqueteira
        new Card(14, 1, 8, "Ciclo e distração"),              // Esqueletos
        new Card(9, 4, 8, "Construção defensiva"),            // Tesla
        new Card(8, 4, 10, "Defesa terrestre em área"),      // Príncipe das Trevas
        new Card(1, 3, 11, "Condição de vitória secundária"),// Barril de Goblins
        new Card(13, 1, 9, "Ciclo e suporte"),                // Espírito de Gelo
    };

    public static boolean contains(int id) {
        for (Card c : CARDS) if (c.id == id) return true;
        return false;
    }

    public static boolean isReserveCard(int id) {
        return id == 12 || id == 11 || id == 14 || id == 9 || id == 8 || id == 13;
    }

    public static boolean isPrimaryWinCondition(int id) { return id == 10; }
    public static boolean isSecondaryWinCondition(int id) { return id == 1; }

    public static int averageElixirTenths() {
        int total = 0; for (Card c : CARDS) total += c.cost;
        return (total * 10 + CARDS.length / 2) / CARDS.length;
    }

    public static String summary() {
        return "Deck 4 • Corredor 4, Cavaleiro Herói 3, Mosqueteira 4, Esqueletos 1, "
             + "Tesla 4, Príncipe das Trevas 4, Barril de Goblins 3, Espírito de Gelo 1 • média 3,0";
    }
}
