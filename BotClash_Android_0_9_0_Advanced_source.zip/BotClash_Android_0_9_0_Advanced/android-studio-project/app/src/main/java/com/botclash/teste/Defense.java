package com.botclash.teste;
import java.util.*;
/** Bounded role heuristics, evaluating identified threats in BOTH lanes. Not optimal play. */
public final class Defense {
 static boolean swarm(String n){return Arrays.asList("skeleton","guard","goblin","spear_goblin","royal_recruit","barbarian").contains(n);}
 static float urgency(Enemy.Unit u,List<Enemy.Unit> all){float score=(Enemy.buildingTarget(u.name)?14:Enemy.kite(u.name)?11:Enemy.splash(u.name)?9:4)+Math.max(0,u.y()-550)/35;
  for(Enemy.Unit v:all)if(v!=u&&!v.name.equals("unknown")&&Math.hypot(u.x()-v.x(),u.y()-v.y())<180)score+=1.5;
  if(u.y()>945&&u.x()>160&&u.x()<530)score+=25;return score;
 }
 public static Advice.Suggestion choose(Vision.Reading r,Enemy.Scene s,long now){
  Advice.Suggestion out=new Advice.Suggestion();out.reason="Aguardando uma ameaça reconhecida.";
  if(!r.valid||r.elixir<0||s==null||now-s.time>1400)return out;
  List<Enemy.Unit> units=new ArrayList<>(s.units);if(units.isEmpty()&&s.main!=null)units.add(s.main);
  float best=-1;boolean known=false,approaching=false;String approachingName="";
  for(Enemy.Unit u:units){if(u.name.equals("unknown")||now-u.time>1400&&u.time>0)continue;known=true;
   if(u.y()<565){approaching=true;approachingName=Enemy.label(u.name);continue;}
   boolean right=u.x()>345.5f,splash=false,uncertain=false;
   for(Enemy.Unit v:units)if((v.x()>345.5f)==right){splash|=Enemy.splash(v.name);uncertain|=v.name.equals("unknown");}
   Advice.Suggestion candidate=against(r,u,right,splash,uncertain,units);
   float score=urgency(u,units);if(candidate.slot>=0&&score>best){best=score;out=candidate;}
  }
  if(out.slot>=0){out.reason=(out.target.x()>345.5f?"Direita":"Esquerda")+" • "+Enemy.label(out.target.name)+". "+out.reason;return out;}
  if(!known)out.reason="Pressão detectada, tipo ainda incerto. Sem carta inventada.";
  else if(approaching)out.reason=approachingName+" a caminho. Prepare defesa; aguarde aproximar.";
  else {boolean partial=false;for(int c:r.cards)partial|=c<0;out.reason=partial?"Mão parcialmente reconhecida. Confira as cartas marcadas com ?.":"Nenhuma defesa compatível e acessível nesta leitura.";}
  return out;
 }
 static Advice.Suggestion against(Vision.Reading r,Enemy.Unit u,boolean right,boolean splash,boolean uncertain,List<Enemy.Unit> units){
  Advice.Suggestion a=new Advice.Suggestion();float y=u.y(),lane=Math.max(60,Math.min(630,u.x()));int[] options;
  if(Enemy.air(u.name))options=Enemy.buildingTarget(u.name)?new int[]{9,11,7,6,13}:new int[]{11,7,9,6,13};
  else if(Enemy.kite(u.name))options=new int[]{0,9,4,12,8,11,6,7,13,14};
  else if(Enemy.buildingTarget(u.name))options=new int[]{9,4,11,7,6,12,8,13,14};
  else if(Enemy.splash(u.name))options=new int[]{3,8,2,12,7,11};
  else if(swarm(u.name))options=new int[]{3,2,8,12,7,4,13};
  else options=new int[]{12,8,2,9,4,7,11,6,13,14};
  for(int card:options){if(card==0&&(y<650||y>865))continue;if((card==4||card==9)&&y>920)continue;if((card==6||card==14)&&(splash||uncertain))continue;if(card==13&&y<700)continue;
   for(int slot=0;slot<4;slot++)if(r.cards[slot]==card&&Vision.COST[card]<=r.elixir){a.card=card;a.slot=slot;a.cost=Vision.COST[card];break;}if(a.slot>=0)break;}
  if(a.slot<0)return a;a.target=u;
  PlacementPlanner.Point point=PlacementPlanner.defense(a.card,u,right,units);a.x=point.x;a.y=point.y;
  if(a.card==0)a.reason="Distraia no centro e reavalie o apoio.";
  else if(a.card==4||a.card==9)a.reason="Construção em zona central de atração; ajuste conforme a rota.";
  else if(a.card==3)a.reason="Barril sobre as tropas terrestres.";
  else if(a.card==14)a.reason="Esqueletos deslocados para distrair uma unidade terrestre sem dano em área; não use contra splash.";
  else if(a.card==13)a.reason="Espírito para ganhar tempo; não é uma defesa completa.";
  else if(a.card==11||a.card==7||a.card==6)a.reason="Apoio à distância, atrás e afastado da ameaça; evite agrupar tropas.";
  else a.reason="Intercepte com apoio da sua torre, sem colocar a tropa diretamente sobre o alvo.";
  return a;
 }
}
