package com.botclash.teste;
/** Confirm the selected slot independently; uncertainty elsewhere must not cancel it. */
public final class HandStability {
 private final int[] previous={-1,-1,-1,-1},counts=new int[4];
 public void reset(){java.util.Arrays.fill(previous,-1);java.util.Arrays.fill(counts,0);}
 public void observe(Vision.Reading r){if(!r.valid){reset();return;}for(int i=0;i<4;i++){int card=r.cards[i];counts[i]=card>=0?(previous[i]==card?Math.min(3,counts[i]+1):1):0;previous[i]=card;}}
 public boolean ready(Advice.Suggestion a,Vision.Reading r){return r.valid&&a!=null&&a.slot>=0&&a.slot<4&&a.card>=0&&r.cards[a.slot]==a.card&&counts[a.slot]>=2;}
}
