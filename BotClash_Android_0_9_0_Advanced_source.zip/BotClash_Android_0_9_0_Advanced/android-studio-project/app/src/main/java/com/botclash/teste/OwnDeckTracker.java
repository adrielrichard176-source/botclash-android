package com.botclash.teste;

import java.util.ArrayDeque;
import java.util.Arrays;

/**
 * Reconstructs the player's card-cycle events from stable hand transitions.
 * It only emits an event when the four visible cards match the exact
 * remove-one/shift-left/draw-one pattern. Ambiguous frames are ignored.
 */
public final class OwnDeckTracker {
    private static final int HAND_SIZE = 4;
    private static final int HISTORY_SIZE = 12;

    private int[] candidate;
    private int candidateFrames;
    private int[] stableHand;
    private long stableAtMs = -1L;
    private int totalPlays;
    private final ArrayDeque<Integer> recent = new ArrayDeque<>();

    public synchronized void reset() {
        candidate = null;
        candidateFrames = 0;
        stableHand = null;
        stableAtMs = -1L;
        totalPlays = 0;
        recent.clear();
    }

    public synchronized PlayEvent observe(Vision.Reading reading, long nowMs) {
        if (!complete(reading)) {
            candidate = null;
            candidateFrames = 0;
            return null;
        }

        if (candidate != null && Arrays.equals(candidate, reading.cards)) {
            candidateFrames = Math.min(3, candidateFrames + 1);
        } else {
            candidate = reading.cards.clone();
            candidateFrames = 1;
        }
        if (candidateFrames < 2) return null;

        if (stableHand == null) {
            stableHand = candidate.clone();
            stableAtMs = nowMs;
            return null;
        }
        if (Arrays.equals(stableHand, candidate)) return null;

        PlayEvent event = infer(stableHand, candidate, nowMs);
        stableHand = candidate.clone();
        stableAtMs = nowMs;
        if (event == null) return null;

        totalPlays++;
        recent.addLast(event.card);
        while (recent.size() > HISTORY_SIZE) recent.removeFirst();
        return event;
    }

    private static boolean complete(Vision.Reading reading) {
        if (reading == null || !reading.valid || reading.cards == null
                || reading.cards.length != HAND_SIZE) return false;
        for (int card : reading.cards) if (card < 0) return false;
        return true;
    }

    private static PlayEvent infer(int[] before, int[] after, long nowMs) {
        for (int slot = 0; slot < HAND_SIZE; slot++) {
            boolean shifted = true;
            for (int newSlot = 0; newSlot < HAND_SIZE - 1; newSlot++) {
                int oldSlot = newSlot < slot ? newSlot : newSlot + 1;
                if (after[newSlot] != before[oldSlot]) {
                    shifted = false;
                    break;
                }
            }
            if (!shifted) continue;

            int drawn = after[HAND_SIZE - 1];
            boolean alreadyInHand = false;
            for (int oldCard : before) alreadyInHand |= oldCard == drawn;
            if (alreadyInHand) continue;
            return new PlayEvent(before[slot], slot, drawn, nowMs);
        }
        return null;
    }

    public synchronized int totalPlays() { return totalPlays; }

    public synchronized int[] recentCards() {
        int[] out = new int[recent.size()];
        int i = 0;
        for (int card : recent) out[i++] = card;
        return out;
    }

    public synchronized String summary() {
        if (recent.isEmpty()) return "Histórico próprio: aguardando transições confirmadas";
        StringBuilder out = new StringBuilder("Jogadas próprias: ");
        for (int card : recent) {
            if (out.charAt(out.length() - 1) != ' ') out.append(" · ");
            out.append(card >= 0 && card < Vision.NAMES.length ? Vision.NAMES[card] : "?");
        }
        return out.toString();
    }

    public static final class PlayEvent {
        public final int card;
        public final int slot;
        public final int drawnCard;
        public final long atMs;

        PlayEvent(int card, int slot, int drawnCard, long atMs) {
            this.card = card;
            this.slot = slot;
            this.drawnCard = drawnCard;
            this.atMs = atMs;
        }
    }
}
