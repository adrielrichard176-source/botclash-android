package com.botclash.teste;
import java.util.*;
/** Learns next-card thumbnails only after two matching, independently observed single-card transitions. */
public final class NextLearner {
 Vision.Reading base,pending;int stable;long baseTime;int[][] candidates=new int[Vision.NAMES.length][];
 public void reset(){base=pending=null;stable=0;}
 public int observe(Vision.Reading r,long now,Vision v){if(!r.valid||r.elixir<0||r.nextPixels==null){reset();return -1;}for(int c:r.cards)if(c<0){pending=null;stable=0;if(now-baseTime>4000)base=null;return -1;}
 if(pending!=null&&Arrays.equals(pending.cards,r.cards))stable++;else{pending=r;stable=1;}if(stable<2)return -1;
 int learned=-1;if(base!=null&&!Arrays.equals(base.cards,r.cards)&&now-baseTime<=4000&&r.elixir<base.elixir){int changed=0,id=-1;for(int i=0;i<4;i++)if(base.cards[i]!=r.cards[i]){changed++;id=r.cards[i];}if(changed==1){boolean newCard=true;for(int old:base.cards)if(old==id)newCard=false;
 if(newCard&&(base.next<0||base.next==id)){int[] thumb=base.nextPixels.clone();if(candidates[id]!=null&&Vision.score(candidates[id],thumb)>=.92){v.templates.put("next_"+id+"_learned",thumb);learned=id;}candidates[id]=thumb;}}}
 base=r;baseTime=now;return learned;
 }
}
