package com.botclash.teste;
import java.util.*;
/** Pure Java visual reader; coordinates are in the supplied 691 x 1536 reference layout. */
public final class Vision {
 public static final String[] NAMES={"Golem de Gelo","Barril de Goblins","Fantasma Real","Barril de Bárbaro","Torre de Bombas","Relâmpago","Horda de Servos","Mago Elétrico","Príncipe das Trevas","Tesla","Corredor","Mosqueteira","Cavaleiro Herói","Espírito de Gelo","Esqueletos"};
 public static final int[] COST={2,3,3,2,4,6,5,4,4,4,4,4,3,1,1};
 public static int templateId(String key){try{String[] parts=key.split("_");int id=Integer.parseInt(parts[1]);return id>=0&&id<NAMES.length?id:-1;}catch(RuntimeException e){return -1;}}
 public final Map<String,int[]> templates=new HashMap<>();
 public static final class Reading {public boolean valid;public int elixir=-1,next=-1;public int[] nextPixels;public int[] cards={-1,-1,-1,-1};public double[] confidence=new double[4];}
 public static int[] crop(int[] src,int w,int h,int left,int top,int cw,int ch){int[] dst=new int[24*28];for(int y=0;y<28;y++)for(int x=0;x<24;x++){int sx=left+(int)((x+.5)*cw/24),sy=top+(int)((y+.5)*ch/28);dst[y*24+x]=(sx>=0&&sx<w&&sy>=0&&sy<h)?src[sy*w+sx]:0;}return dst;}
 public static double score(int[] a,int[] b){double error=0;for(int i=0;i<a.length;i++){int p=a[i],q=b[i];error+=Math.abs((p>>16&255)-(q>>16&255))+Math.abs((p>>8&255)-(q>>8&255))+Math.abs((p&255)-(q&255));}return 1-error/(a.length*765.0);}
 static boolean purple(int p){int r=p>>16&255,g=p>>8&255,b=p&255;return r>100&&b>90&&r>g*1.25&&b>g*1.15;}
 public Reading read(int[] p){Reading r=new Reading();int[] u=crop(p,691,1536,20,1414,90,22);int[] hud=templates.get("hud");if(hud==null||score(u,hud)<.88)return r;
 // Blue hand tray must be present as well as the text anchor.
 int blue=0;for(int x=130;x<680;x+=30){int c=p[1315*691+x];if((c&255)>(c>>16&255)+40)blue++;}if(blue<10)return r;
 r.valid=true;r.elixir=0;boolean gap=false;for(int i=0;i<10;i++){int x=188+(i+1)*48-8,hits=0;for(int y=1501;y<=1511;y+=2)if(purple(p[y*691+x]))hits++;boolean filled=hits>=4;if(filled&&gap){r.elixir=-1;break;}if(filled)r.elixir++;else gap=true;}
 for(int slot=0;slot<4;slot++){double[] scores=new double[NAMES.length];for(int dy=-24;dy<=4;dy+=4){int[] c=crop(p,691,1536,175+130*slot,1345+dy,80,100);for(Map.Entry<String,int[]> e:templates.entrySet()){if(!e.getKey().startsWith("hand_"))continue;int id=templateId(e.getKey());if(id>=0&&DeckProfile.contains(id))scores[id]=Math.max(scores[id],score(c,e.getValue()));}}
 int best=0;double second=0;for(int i=1;i<NAMES.length;i++)if(scores[i]>scores[best])best=i;for(int i=0;i<NAMES.length;i++)if(i!=best)second=Math.max(second,scores[i]);r.confidence[slot]=scores[best];if(scores[best]>=.88&&scores[best]-second>=.035)r.cards[slot]=best;}
 // No deck contains duplicate card identities: ambiguous duplicate detections are withheld.
 for(int i=0;i<4;i++)for(int j=i+1;j<4;j++)if(r.cards[i]>=0&&r.cards[i]==r.cards[j]){r.cards[i]=-1;r.cards[j]=-1;}
 r.nextPixels=smoothNext(p);r.next=matchNext(r.nextPixels);return r;
 }
 public static int[] smoothNext(int[] src){int[] out=new int[672];for(int y=0;y<28;y++)for(int x=0;x<24;x++){int xx=44+(int)((x+.5)*40/24),yy=1465+(int)((y+.5)*40/28);int red=0,green=0,blue=0;for(int dy=-2;dy<=2;dy++)for(int dx=-2;dx<=2;dx++){int c=src[(yy+dy)*691+xx+dx];red+=c>>16&255;green+=c>>8&255;blue+=c&255;}out[y*24+x]=(red/25<<16)|(green/25<<8)|(blue/25);}return out;}
 public int matchNext(int[] n){double[] scores=new double[NAMES.length];for(Map.Entry<String,int[]> e:templates.entrySet())if(e.getKey().startsWith("next_")){int id=templateId(e.getKey());if(id>=0&&id<NAMES.length&&DeckProfile.contains(id))scores[id]=Math.max(scores[id],score(n,e.getValue()));}int best=0;double second=0;for(int i=1;i<NAMES.length;i++)if(scores[i]>scores[best])best=i;for(int i=0;i<NAMES.length;i++)if(i!=best)second=Math.max(second,scores[i]);return scores[best]>=.86&&scores[best]-second>=.06?best:-1;}
}
