package com.botclash.teste;
/** Human-selected threat categories. This is a positioning guide, not an enemy detector or solver. */
public final class Advice {
 public static final String[] MODES={"Escolha ameaça","Solo","Grupo no chão","Ar","Tanque","Pressão"};
 private static final int[][] SUITABLE={{},{2,7,6},{3,2,4},{7,6},{4,6},{1,2}};
 public static class Suggestion {public int slot=-1,card=-1,cost;public Enemy.Unit target;public float x,y;public String reason="Escolha o tipo de ameaça e o lado.";}
 public static Suggestion choose(Vision.Reading r,int mode,boolean right){Suggestion a=new Suggestion();if(!r.valid||r.elixir<0){a.reason="Leitura incerta: aguarde.";return a;}if(mode<=0||mode>=SUITABLE.length)return a;
 // Card roles restrict candidates before selecting a lower cost option. Preserve two elixir for optional pressure.
 int budget=r.elixir-(mode==5?2:0);for(int card:SUITABLE[mode])for(int slot=0;slot<4;slot++)if(r.cards[slot]==card&&Vision.COST[card]<=budget&&(a.slot<0||Vision.COST[card]<a.cost)){a.slot=slot;a.card=card;a.cost=Vision.COST[card];}
 if(a.slot<0){a.reason="Sem opção reconhecida com elixir suficiente.";return a;}
 float lane=right?535:145;
 if(a.card==4){a.x=right?395:295;a.y=805;a.reason="Sugestão: construção central para atrair. Ajuste ao avanço inimigo.";}
 else if(a.card==1){a.x=right?550:140;a.y=360;a.reason="Pressão na torre; confira se pode defender depois.";}
 else if(a.card==3){a.x=lane;a.y=865;a.reason="Role o barril pelo grupo no chão. Confira a distância.";}
 else {a.x=lane;a.y=835;a.reason=mode==3?"Apoio contra ameaça aérea. Evite juntar tropas sob feitiços.":"Defesa com apoio da sua torre. Ajuste ao avanço inimigo.";}
 return a;
 }
}
