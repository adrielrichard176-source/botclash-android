package com.botclash.teste;
import android.accessibilityservice.*;import android.content.*;import android.graphics.*;import android.hardware.HardwareBuffer;import android.os.*;import android.view.*;import android.view.accessibility.*;import android.widget.*;import java.io.*;import java.util.*;import java.util.concurrent.*;
public class BotService extends AccessibilityService {
 public static BotService instance;
 final Handler h=new Handler(Looper.getMainLooper());final ExecutorService worker=Executors.newSingleThreadExecutor();
 WindowManager wm;LinearLayout panel,details;TextView status,decision,hand,handSummary,opponentSummary;Guide guide;
 Vision vision=new Vision();NextLearner learner=new NextLearner();Enemy tracker=new Enemy();OpponentPlayObserver opponentPlays=new OpponentPlayObserver();EnemyModel detector;Strategy strategy=new Strategy();HandStability handStability=new HandStability();OwnDeckTracker ownDeckTracker=new OwnDeckTracker();BattlePhaseTracker phaseTracker=new BattlePhaseTracker();OpponentDeckTracker opponentDeck=new OpponentDeckTracker();
 volatile int epoch=0;volatile boolean running=false,destroyed=false,resetTracking=false;boolean busy=false,fullDisplay=false,paused=false;int busyEpoch=-1,invalid=0,errors=0,interval=500;int sw,sh,frameX,frameY;long lastCapture=0,started=0,lastResult=0;String detailText="";final String GAME="com.supercell.clashroyale";
 protected void onServiceConnected(){instance=this;wm=(WindowManager)getSystemService(WINDOW_SERVICE);try{for(String name:getAssets().list("vision"))try(DataInputStream in=new DataInputStream(getAssets().open("vision/"+name))){vision.templates.put(name.replace(".rgb",""),readInts(in));}for(File f:getFilesDir().listFiles())if(f.getName().matches("next_[0-9]+_learned[.]rgb"))try(DataInputStream in=new DataInputStream(new FileInputStream(f))){vision.templates.put(f.getName().replace(".rgb",""),readInts(in));}}catch(Exception e){/* invalid learned files are ignored */}}
 int[] readInts(DataInputStream in)throws IOException{int[] p=new int[672];for(int i=0;i<p.length;i++)p[i]=in.readInt();return p;}
 public void onAccessibilityEvent(AccessibilityEvent e){if(running&&!gameVisible())softPause();}
 public void onInterrupt(){hideAll();}
 public void onDestroy(){destroyed=true;hideAll();instance=null;worker.execute(()->{if(detector!=null)detector.close();});worker.shutdown();super.onDestroy();}
 static class GameWindow {int id;Rect bounds;GameWindow(int i,Rect b){id=i;bounds=new Rect(b);}}
 GameWindow gameWindow(){
  android.app.KeyguardManager lock=(android.app.KeyguardManager)getSystemService(KEYGUARD_SERVICE);if(lock!=null&&lock.isKeyguardLocked())return null;
  java.util.List<AccessibilityWindowInfo> windows=getWindows();boolean appSeen=false;GameWindow found=null;
  try{
   for(AccessibilityWindowInfo w:windows){
    if(w.getType()!=AccessibilityWindowInfo.TYPE_APPLICATION)continue;
    appSeen=true;AccessibilityNodeInfo root=null;boolean isGame=false;
    try{root=w.getRoot();if(root!=null){CharSequence pkg=root.getPackageName();isGame=pkg!=null&&GAME.contentEquals(pkg);}}
    finally{if(root!=null)root.recycle();}
    if(isGame){Rect bounds=new Rect();w.getBoundsInScreen(bounds);found=new GameWindow(w.getId(),bounds);break;}
   }
  }finally{for(AccessibilityWindowInfo w:windows)w.recycle();}
  if(found!=null)return found;
  AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return null;try{CharSequence pkg=root.getPackageName();if(pkg==null||!GAME.contentEquals(pkg))return null;return new GameWindow(root.getWindowId(),new Rect(0,0,getResources().getDisplayMetrics().widthPixels,getResources().getDisplayMetrics().heightPixels));}finally{root.recycle();}
 }
 boolean gameVisible(){return gameWindow()!=null;}
 boolean activeRootIsGame(){AccessibilityNodeInfo n=getRootInActiveWindow();if(n==null)return false;try{CharSequence p=n.getPackageName();return p!=null&&GAME.contentEquals(p);}finally{n.recycle();}}
 void softPause(){if(!paused){paused=true;resetTracking=true;clearArrow();}if(panel!=null)panel.setVisibility(View.VISIBLE);msg("Pausa temporária • volte ao Clash");if(decision!=null)decision.setText("Retoma ao voltar. PARAR encerra o guia.");}
 int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 void msg(String s){if(status!=null)status.setText(s);}
 void clearArrow(){if(guide!=null){guide.suggestion=null;guide.scene=null;guide.setVisibility(View.INVISIBLE);}handStability.reset();}
 void stop(String s){running=false;paused=false;busy=false;epoch++;h.removeCallbacksAndMessages(null);clearArrow();learner.reset();strategy.reset();ownDeckTracker.reset();phaseTracker.reset();opponentDeck.reset();if(panel!=null)panel.setVisibility(View.VISIBLE);msg(s);if(decision!=null)decision.setText("Guia visual • você faz os toques");}
 void remove(View v){if(v!=null)try{wm.removeView(v);}catch(Exception ignored){}}
 public void hideAll(){stop("Parado");remove(guide);guide=null;remove(panel);panel=null;status=null;decision=null;hand=null;handSummary=null;opponentSummary=null;}
 WindowManager.LayoutParams params(int w,int he,int flags){WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,he,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,flags,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.LEFT;p.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;return p;}
 TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
 Button add(LinearLayout r,String text,Runnable action){Button b=new Button(this);b.setText(text);b.setTextSize(10);b.setPadding(0,0,0,0);r.addView(b,new LinearLayout.LayoutParams(0,dp(36),1));b.setOnClickListener(v->action.run());return b;}
 public void showPanel(){if(panel!=null)return;guide=new Guide();wm.addView(guide,params(-1,-1,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN));guide.setVisibility(View.INVISIBLE);
 panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(7),dp(5),dp(7),dp(5));panel.setBackgroundColor(0xf0111827);TextView title=label("BotClash Android 0.9.0-alpha • guia",12,0xffbcf47e);title.setPadding(0,dp(4),0,dp(5));panel.addView(title);status=label("Abra uma partida e toque GUIAR.",12,Color.WHITE);panel.addView(status);decision=label("Experimental • use partida de treino",11,0xffb9cad6);panel.addView(decision);handSummary=label("Mão: aguardando leitura",10,0xffbcf47e);panel.addView(handSummary);opponentSummary=label("Elixir rival: aguardando leitura",10,0xff93c5fd);panel.addView(opponentSummary);
 LinearLayout row=new LinearLayout(this);panel.addView(row);add(row,"GUIAR",()->start());add(row,"PARAR",()->stop("Parado"));add(row,"MAIS",()->details.setVisibility(details.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));
 details=new LinearLayout(this);details.setOrientation(1);panel.addView(details);hand=label("Tropas e tempo da leitura aparecerão aqui.",11,Color.WHITE);details.addView(hand);LinearLayout rr=new LinearLayout(this);details.addView(rr);add(rr,"Copiar leitura",()->{((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("BotClash",detailText));Toast.makeText(this,"Leitura copiada",0).show();});add(rr,"Fechar",()->hideAll());details.setVisibility(View.GONE);
 WindowManager.LayoutParams p=params(dp(255),-2,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);p.y=dp(40);wm.addView(panel,p);title.setOnTouchListener(new View.OnTouchListener(){float x,y;int ox,oy;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==0){x=e.getRawX();y=e.getRawY();ox=p.x;oy=p.y;}if(e.getAction()==2){p.x=Math.max(0,Math.min(getResources().getDisplayMetrics().widthPixels-dp(255),ox+Math.round(e.getRawX()-x)));p.y=Math.max(0,oy+Math.round(e.getRawY()-y));wm.updateViewLayout(panel,p);}return true;}});
 }
 void start(){stop("Carregando detector local...");if(!gameVisible()){msg("Abra uma partida primeiro.");return;}if(vision.templates.isEmpty()){msg("Referências ausentes. Reinstale.");return;}running=true;resetTracking=false;invalid=0;errors=0;interval=500;started=SystemClock.elapsedRealtime();opponentPlays.reset(started);ownDeckTracker.reset();phaseTracker.reset();opponentDeck.reset();final int token=epoch;
 worker.execute(()->{try{tracker.reset();if(detector==null)detector=new EnemyModel(this);h.post(()->{if(token==epoch&&running){msg("Lendo arena e cartas...");schedule(token);}});}catch(Exception|LinkageError ex){h.post(()->{if(token==epoch)stop("Detector não carregou: "+ex.getClass().getSimpleName());});}});
 }
 void schedule(int token){if(token!=epoch||!running)return;if(SystemClock.elapsedRealtime()-started>360000){stop("Sessão encerrada. Toque GUIAR para recomeçar.");return;}long delay=Math.max(30,interval-(SystemClock.elapsedRealtime()-lastCapture));h.postDelayed(()->capture(token),delay);}
 void capture(int token){if(token!=epoch||!running||destroyed)return;if(SystemClock.elapsedRealtime()-started>360000){stop("Sessão encerrada. Toque GUIAR para recomeçar.");return;}GameWindow game=gameWindow();if(game==null){softPause();h.postDelayed(()->capture(token),700);return;}paused=false;if(busy){h.postDelayed(()->capture(token),100);return;}
 final int windowId=game.id;Rect bounds=game.bounds;
 final boolean byWindow=Build.VERSION.SDK_INT>=34&&!fullDisplay;final Rect area=new Rect(bounds);final Rect overlayMask=new Rect();
 // In full-display fallback, keep the control panel visible. Only hide the drawing layer,
 // then mask the panel's rectangle from the analysis bitmap so it cannot become a false troop.
 if(!byWindow){if(panel!=null&&panel.getVisibility()==View.VISIBLE){int[] xy=new int[2];panel.getLocationOnScreen(xy);overlayMask.set(xy[0],xy[1],xy[0]+panel.getWidth(),xy[1]+panel.getHeight());}if(guide!=null)guide.setVisibility(View.INVISIBLE);}
 busy=true;busyEpoch=token;lastCapture=SystemClock.elapsedRealtime();final long requested=lastCapture;
 TakeScreenshotCallback cb=new TakeScreenshotCallback(){public void onSuccess(ScreenshotResult result){Bitmap bitmap=null;try(HardwareBuffer hb=result.getHardwareBuffer()){Bitmap hw=Bitmap.wrapHardwareBuffer(hb,result.getColorSpace());if(hw!=null){bitmap=hw.copy(Bitmap.Config.ARGB_8888,true);hw.recycle();}}catch(Exception ignored){}
 if(bitmap==null){h.post(()->failure(token,-1));return;}final Bitmap b=bitmap;if(token!=epoch||!running||destroyed){b.recycle();h.post(()->release(token));return;}
 try{Frame f=analyze(b,byWindow?area.left:0,byWindow?area.top:0,byWindow?null:overlayMask,requested);h.post(()->accept(token,f));}catch(Exception|LinkageError ex){h.post(()->{release(token);if(token==epoch)stop("Falha na leitura: "+ex.getClass().getSimpleName());});}finally{b.recycle();}}
 public void onFailure(int code){h.post(()->failure(token,code));}};
 Runnable take=()->{if(token!=epoch||!running){release(token);return;}if(!gameVisible()||(!byWindow&&!activeRootIsGame())){release(token);softPause();schedule(token);return;}try{if(byWindow)takeScreenshotOfWindow(windowId,worker,cb);else takeScreenshot(Display.DEFAULT_DISPLAY,worker,cb);}catch(Exception ex){failure(token,-2);}};
 if(byWindow)take.run();else h.postDelayed(take,80);
 }
 void release(int token){if(busyEpoch==token)busy=false;}
 void failure(int token,int code){release(token);if(panel!=null)panel.setVisibility(View.VISIBLE);if(token!=epoch||!running)return;clearArrow();if(code==ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT){interval=Math.min(1200,interval+100);msg("Ajustando o intervalo de captura...");schedule(token);return;}
 if(Build.VERSION.SDK_INT>=34&&!fullDisplay){fullDisplay=true;msg("Usando captura de tela alternativa...");schedule(token);return;}if(++errors<=2){msg("Captura indisponível; tentando novamente...");h.postDelayed(()->capture(token),900);}else stop("Captura recusada pelo Android: "+code);}
 static class Frame {Vision.Reading hand;Enemy.Scene scene;int w,h,x,y;long began,done;}
 Frame analyze(Bitmap b,int x,int y,Rect overlayMask,long requested)throws Exception{if(resetTracking){tracker.reset();resetTracking=false;}Frame f=new Frame();f.w=b.getWidth();f.h=b.getHeight();f.x=x;f.y=y;f.began=requested;f.hand=new Vision.Reading();boolean handLayoutCompatible=Math.abs((double)f.h/f.w-1536.0/691)<=.035;
  if(overlayMask!=null&&!overlayMask.isEmpty()){
   Rect local=new Rect(overlayMask);local.offset(-x,-y);if(local.intersect(0,0,b.getWidth(),b.getHeight())){Canvas canvas=new Canvas(b);Paint maskPaint=new Paint();maskPaint.setColor(0xff18202d);maskPaint.setStyle(Paint.Style.FILL);canvas.drawRect(local,maskPaint);}
  }
  Bitmap small=Bitmap.createScaledBitmap(b,691,1536,true);int[] pixels=new int[691*1536];small.getPixels(pixels,0,691,0,0,691,1536);if(small!=b)small.recycle();if(handLayoutCompatible)synchronized(vision){f.hand=vision.read(pixels);}if(detector!=null)f.scene=tracker.update(detector.detect(b),pixels,requested);f.done=SystemClock.elapsedRealtime();return f;}
 String name(int i){return i<0||i>=Vision.NAMES.length?"?":Vision.NAMES[i];}
 void accept(int token,Frame f){
  release(token);
  if(panel!=null)panel.setVisibility(View.VISIBLE);
  if(token!=epoch||!running||destroyed)return;
  if(!gameVisible()){softPause();schedule(token);return;}
  paused=false;errors=0;
  long now=SystemClock.elapsedRealtime(),age=now-f.began;
  if(age>1400){clearArrow();msg("Leitura lenta: "+age+" ms. Nenhuma seta antiga será usada.");schedule(token);return;}

  if(f.scene==null)f.scene=new Enemy.Scene();
  sw=f.w;sh=f.h;frameX=f.x;frameY=f.y;
  OwnDeckTracker.PlayEvent ownPlay=null;
  BattlePhaseTracker.Snapshot phase=phaseTracker.snapshot();
  if(f.hand.valid){
   ownPlay=ownDeckTracker.observe(f.hand,now);
   int spent=ownPlay==null?0:Vision.COST[ownPlay.card];
   phase=phaseTracker.observe(f.hand.elixir,spent,now);
   if(ownPlay!=null)strategy.noteOwnCardPlayed(now);
  }
  opponentDeck.observe(f.scene);
  OpponentElixirTracker.Snapshot rival=opponentPlays.observe(f.scene,now,phase.multiplier);
  String rivalText=rival.lastPlayMs<0?"Elixir rival: sem jogada reconhecida":now-rival.lastPlayMs>7000?"Elixir rival: faixa antiga":"Elixir rival ~ "+rival.label()+" • parcial";
  if(opponentSummary!=null)opponentSummary.setText(rivalText+" • deck "+opponentDeck.knownCount()+"/8");

  if(!f.hand.valid){
   invalid++;
   clearHandOnly();
   msg(f.scene.summary+"\nMão não reconhecida; leitura de tropas continua.");
   if(decision!=null)decision.setText("Sem cartas confiáveis. Nenhuma jogada será sugerida até a mão ser confirmada.");
   if(handSummary!=null)handSummary.setText("Mão: leitura parcial/indisponível");
   StringBuilder found=new StringBuilder();
   for(Enemy.Unit u:f.scene.units)found.append(Enemy.label(u.name)).append(" ").append(Math.round(u.confidence*100)).append("% @ ").append(Math.round(u.x())).append(',').append(Math.round(u.y())).append('\n');
   detailText="BotClash Android 0.9.0-alpha • detector local experimental\n"
      +"Mão: não confirmada; a arena continua sendo analisada.\n"
      +rivalText+"\nFase: "+phase.label+"\n"+opponentDeck.summary()+"\n"+opponentDeck.recentSummary()+"\n"
      +f.scene.summary+"\n"+found
      +"Captura + análise: "+age+" ms\n"+ownDeckTracker.summary()
      +"\nSem recomendação: a mão precisa estar confiável.";
   if(hand!=null)hand.setText(detailText);
   if(guide!=null){guide.scene=f.scene;guide.suggestion=null;guide.setVisibility(f.scene.main!=null||!f.scene.units.isEmpty()?View.VISIBLE:View.INVISIBLE);guide.invalidate();}
   schedule(token);return;
  }
  invalid=0;

  Vision.Reading r=f.hand;
  synchronized(vision){int learned=learner.observe(r,now,vision);if(learned>=0)try(DataOutputStream out=new DataOutputStream(openFileOutput("next_"+learned+"_learned.rgb",0))){for(int c:vision.templates.get("next_"+learned+"_learned"))out.writeInt(c);}catch(IOException ignored){}r.next=vision.matchNext(r.nextPixels);}
  handStability.observe(r);
  Advice.Suggestion a=strategy.choose(r,f.scene,now);
  boolean ready=handStability.ready(a,r);
  String threat=a.target==null?f.scene.summary:(a.target.x()>345.5f?"Direita":"Esquerda")+" • "+Enemy.label(a.target.name);
  msg(threat+"\nElixir ≈ "+r.elixir+" • Próxima: "+name(r.next));
  if(decision!=null)decision.setText(a.slot<0?a.reason:ready?name(a.card)+" • "+a.cost+" elixir\n"+a.reason:"Confirmando "+name(a.card)+" antes de mostrar a seta.");
  if(handSummary!=null)handSummary.setText("1 "+name(r.cards[0])+" · 2 "+name(r.cards[1])+"\n3 "+name(r.cards[2])+" · 4 "+name(r.cards[3]));
  StringBuilder found=new StringBuilder();
  for(Enemy.Unit u:f.scene.units)found.append(Enemy.label(u.name)).append(" ").append(Math.round(u.confidence*100)).append("% @ ").append(Math.round(u.x())).append(',').append(Math.round(u.y())).append('\n');
  StringBuilder cardDetails=new StringBuilder();
  for(int slot=0;slot<4;slot++)cardDetails.append("Slot ").append(slot+1).append(": ").append(name(r.cards[slot])).append(" conf=").append(String.format(java.util.Locale.US,"%.2f",r.confidence[slot])).append('\n');
  String ownPlayText=ownPlay==null?"Nenhuma transição própria confirmada nesta leitura":"Última jogada própria: "+name(ownPlay.card)+" (slot "+(ownPlay.slot+1)+")";
  detailText="BotClash Android 0.9.0-alpha • detector local experimental\n"
      +"Elixir rival: "+rivalText+"\nFase: "+phase.label+" ("+phase.samples+" amostras)\n"+opponentDeck.summary()+"\n"+opponentDeck.recentSummary()+"\n"
      +"Mão: "+name(r.cards[0])+" | "+name(r.cards[1])+" | "+name(r.cards[2])+" | "+name(r.cards[3])+"\n"
      +cardDetails+ownPlayText+"\n"+ownDeckTracker.summary()+"\n"
      +f.scene.summary+"\n"+found+"Captura + análise: "+age+" ms\n"
      +"Intervalo mínimo: "+interval+" ms • "+(fullDisplay?"tela inteira • painel mascarado":"janela sem sobreposição")+"\n"
      +a.reason+"\n97 classes de tropas no modelo; a mão é filtrada para as 8 cartas do Deck 4. "
      +"O detector também tenta acompanhar caixas sem barra de vida, com confiança reduzida. "
      +"Elixir rival continua parcial; feitiços e ciclo completo ainda não são reconhecidos. Sem toques automáticos.";
  if(hand!=null)hand.setText(detailText);
  lastResult=now;final long resultId=now;
  if(guide!=null){guide.scene=f.scene;guide.suggestion=ready?a:null;guide.setVisibility(f.scene.main!=null||!f.scene.units.isEmpty()||guide.suggestion!=null?View.VISIBLE:View.INVISIBLE);guide.invalidate();}
  h.postDelayed(()->{if(token==epoch&&lastResult==resultId&&guide!=null){guide.suggestion=null;guide.scene=null;guide.setVisibility(View.INVISIBLE);}},Math.max(50,1400-age));
  schedule(token);
 }
 void clearHandOnly(){handStability.reset();if(guide!=null)guide.suggestion=null;}
 class Guide extends View {Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);Advice.Suggestion suggestion;Enemy.Scene scene;Guide(){super(BotService.this);setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);}
 protected void onDraw(Canvas c){if(!running||sw<=0)return;int[] origin=new int[2];getLocationOnScreen(origin);c.save();c.translate(frameX-origin[0],frameY-origin[1]);c.scale(sw/691f,sh/1536f);
 if(scene!=null){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2);paint.setColor(0xffffbc70);for(Enemy.Unit u:scene.units)if(!u.name.equals("unknown")){c.drawRoundRect(u.x1,u.y1,u.x2,u.y2,8,8,paint);}}
 if(suggestion!=null){Advice.Suggestion a=suggestion;float sx=215+130*a.slot,sy=1395,tx=a.x,ty=a.y;paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(5);paint.setColor(0xff111827);Path path=new Path();path.moveTo(sx,sy-57);path.cubicTo(sx,1200,tx,ty+140,tx,ty+32);c.drawPath(path,paint);paint.setColor(0xffffdf70);paint.setStrokeWidth(3);c.drawPath(path,paint);c.drawCircle(sx,sy,55,paint);c.drawCircle(tx,ty,27,paint);c.drawLine(tx,ty+32,tx-10,ty+48,paint);c.drawLine(tx,ty+32,tx+10,ty+48,paint);
 paint.setStyle(Paint.Style.FILL);paint.setColor(0xee111827);c.drawRoundRect(sx-48,sy+56,sx+48,sy+82,7,7,paint);c.drawRoundRect(tx-72,ty-58,tx+72,ty-30,7,7,paint);paint.setColor(Color.WHITE);paint.setTextSize(18);paint.setTextAlign(Paint.Align.CENTER);c.drawText("Slot "+(a.slot+1),sx,sy+76,paint);c.drawText("2 • Posicione",tx,ty-38,paint);}c.restore();}
 }
}
