package com.botclash.teste;

/**
 * Estimates elixir regeneration phase from observed own-elixir changes.
 * It does not trust the time at which the guide was started, so starting
 * mid-match does not automatically label the match as single elixir.
 */
public final class BattlePhaseTracker {
    private long lastAtMs = -1L;
    private int lastElixir = -1;
    private double rateEma = Double.NaN;
    private int candidateMultiplier = 1;
    private int candidateHits;
    private int multiplier = 1;
    private int acceptedSamples;
    private int pendingSpend;

    public synchronized void reset() {
        lastAtMs = -1L;
        lastElixir = -1;
        rateEma = Double.NaN;
        candidateMultiplier = 1;
        candidateHits = 0;
        multiplier = 1;
        acceptedSamples = 0;
        pendingSpend = 0;
    }

    /**
     * @param elixir current visual elixir (0..10), or -1 when uncertain
     * @param confirmedSpend cost of a card confirmed by the hand-cycle tracker
     */
    public synchronized Snapshot observe(int elixir, int confirmedSpend, long nowMs) {
        if (confirmedSpend > 0) pendingSpend += confirmedSpend;
        if (elixir < 0 || elixir > 10) return snapshot();
        if (lastAtMs < 0L) {
            lastAtMs = nowMs;
            lastElixir = elixir;
            return snapshot();
        }

        long elapsedMs = nowMs - lastAtMs;
        if (elapsedMs < 5000L) return snapshot();
        // At the 10-elixir cap, the visible bar hides some regeneration.
        // Do not infer a phase from a clipped sample.
        if (lastElixir >= 10 || elixir >= 10) {
            lastAtMs = nowMs;
            lastElixir = elixir;
            pendingSpend = 0;
            return snapshot();
        }
        if (elapsedMs > 16000L) {
            lastAtMs = nowMs;
            lastElixir = elixir;
            pendingSpend = 0;
            return snapshot();
        }

        int gain = elixir - lastElixir + pendingSpend;
        double seconds = elapsedMs / 1000.0;
        double maxPlausible = seconds * (3.0 / 2.8) + 2.0;
        if (gain > 0 && gain <= maxPlausible) {
            double rate = gain / seconds;
            rateEma = Double.isNaN(rateEma) ? rate : rateEma * 0.55 + rate * 0.45;
            int detected = rateEma >= 0.88 ? 3 : rateEma >= 0.52 ? 2 : 1;
            acceptedSamples++;
            if (detected == candidateMultiplier) candidateHits++;
            else {
                candidateMultiplier = detected;
                candidateHits = 1;
            }
            if (candidateHits >= 2) multiplier = candidateMultiplier;
        }
        lastAtMs = nowMs;
        lastElixir = elixir;
        pendingSpend = 0;
        return snapshot();
    }

    public synchronized Snapshot snapshot() {
        String label;
        if (candidateHits < 2) label = "fase não confirmada";
        else if (multiplier == 3) label = "elixir triplo provável";
        else if (multiplier == 2) label = "elixir dobrado provável";
        else label = "elixir normal provável";
        double confidence = Math.min(1.0, acceptedSamples / 4.0);
        return new Snapshot(multiplier, label, confidence, acceptedSamples, candidateHits >= 2);
    }

    public static final class Snapshot {
        public final int multiplier;
        public final String label;
        public final double confidence;
        public final int samples;
        public final boolean confirmed;

        Snapshot(int multiplier, String label, double confidence, int samples, boolean confirmed) {
            this.multiplier = multiplier;
            this.label = label;
            this.confidence = confidence;
            this.samples = samples;
            this.confirmed = confirmed;
        }
    }
}
