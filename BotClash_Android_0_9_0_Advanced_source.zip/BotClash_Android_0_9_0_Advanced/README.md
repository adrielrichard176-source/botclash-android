# BotClash Android 0.9.0-alpha

Adaptação Android experimental inspirada no PyClashBot, configurada para o POCO X6 Pro 5G e o Deck 4 informado pelo usuário.

## Arquitetura

- **Captura:** AccessibilityService, captura local da janela do Clash e normalização para coordenadas de arena.
- **Percepção:** amostras RGB para a mão/elixir próprio e modelo ONNX INT8 local de 97 classes para tropas.
- **Estado:** rastreador de transições da mão própria, cartas rivais observadas, fase de elixir inferida por regeneração e faixa parcial de elixir adversário.
- **Decisão:** prioridade defensiva, heurísticas conservadoras de pressão e planejador de posicionamento por papel da carta.
- **HUD:** overlay com ameaças, histórico, confiança e setas temporárias.

## Melhorias 0.9.0

- A leitura de tropas continua mesmo se a mão não for reconhecida; mão incerta bloqueia sugestões, não a observação da arena.
- Fallback de detecção para caixas ONNX sem barra de vida, com confirmação temporal e salvaguarda de lado.
- Histórico próprio e transições do ciclo de quatro cartas confirmadas.
- Cartas rivais observadas e ciclo recente parcial, sem inferir uma mão que não foi vista.
- Estimativa de fase normal/dobrada/tripla usando a regeneração própria; só é exibida como provável após várias janelas.
- Posicionamento de apoio à distância separado da ameaça e construções em zona central.

## O que ainda não existe

- Não é um bot automático: não envia toques nem joga sozinho. O usuário escolhe e executa as cartas.
- Não há OCR robusto da vida das torres/cronômetro, nem detector dedicado de feitiços e efeitos.
- O deck rival pode ficar incompleto; a mão adversária não é inferida nesta versão.
- A estimativa do elixir rival parte de 5 quando GUIAR é iniciado. Iniciar no meio da partida pode produzir faixa errada; feitiços/edifícios não detectados também afetam o cálculo.
- A leitura de cartas depende de amostras RGB e pode retornar `?`.
- A estratégia é heurística, não equivale ao julgamento de um jogador profissional e não garante vitória.
- A captura, precisão, latência, bateria e temperatura ainda precisam ser medidos no POCO X6 Pro.

## Testes

Execute `bash scripts/run-pure-tests.sh`. Nesta revisão passaram onze conjuntos de testes Java puros, incluindo 120.960 casos de orçamento/geometria, ciclo próprio, fase de elixir, fallback de tropas, posicionamento e deck rival. Os testes não validam a integração Android nem uma partida real.

## Compilação

Use JDK 17, Android SDK Platform 35, Build Tools 35.0.0 e Gradle 8.13, ou siga `GITHUB_BUILD_PTBR.md` para compilar no GitHub Actions. O APK debug deve ser gerado pelo workflow; não foi compilado nesta sessão.

## Deck configurado

Corredor, Cavaleiro Herói, Mosqueteira, Esqueletos, Tesla, Príncipe das Trevas, Barril de Goblins e Espírito de Gelo. Média confirmada pelo jogo: 3,0.
