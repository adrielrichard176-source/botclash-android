# BotClash Android 0.8.2-alpha

## Melhorias desta atualização

- A leitura da mão e da próxima carta agora considera somente as oito cartas do Deck 4 configurado, reduzindo confusões com referências de outros decks.
- O detector de tropas marca quando uma identidade inimiga acaba de ser confirmada por leituras consecutivas.
- O estimador do elixir adversário agora recebe esses eventos confirmados, usa faixas de custo quando a identidade da carta é ambígua e ignora formas geradas por outras tropas (por exemplo, Golemites).
- O painel mostra uma faixa aproximada do elixir adversário. A estimativa é parcial: depende de tropas reconhecidas, supõe regeneração normal e parte de 5 elixires no momento em que o guia é iniciado. Se o guia for iniciado no meio da partida, a faixa pode estar errada.
- Foram adicionados testes para deduplicação de tropas, custos ambíguos, formas geradas e filtro de cartas do Deck 4.

## Limitações mantidas

- APK ainda precisa ser compilado em ambiente Android com SDK/Build Tools.
- Captura e visão computacional não foram testadas fisicamente no POCO X6 Pro nesta sessão.
- O reconhecimento de cartas continua limitado às oito cartas do Deck 4 configurado e às amostras visuais incluídas.
- O detector de tropas pode perder unidades ou confundir classes. Feitiços não são contabilizados como cartas jogadas.
- O aplicativo continua no modo GUIA: mostra informações e setas; o usuário confirma e realiza os toques. Não há execução automática de jogadas.
