# BotClash Android 0.9.0-alpha — arquitetura avançada (fundação)

**Alvo:** POCO X6 Pro 5G / Dimensity 8300-Ultra / Android 16.  
**Base:** adaptação Android independente inspirada no PyClashBot.  
**Modo desta versão:** GUIA manual. O aplicativo analisa e sugere; o usuário confirma e realiza os toques.

## Objetivo arquitetural

Sair de regras que reagem a uma captura isolada e manter um estado temporal da partida. A arquitetura foi separada em cinco camadas:

1. **Captura e normalização:** `BotService` captura a janela do Clash, normaliza coordenadas e mantém o ciclo de leitura.
2. **Percepção:** `Vision` lê mão/elixir próprios; `EnemyModel` executa o modelo ONNX local de 97 classes; `Enemy` associa caixas ao longo de vários frames e usa barras de vida quando disponíveis.
3. **Estado e memória:** `OwnDeckTracker` reconstrói jogadas próprias por transições estáveis da mão; `OpponentDeckTracker` registra cartas rivais efetivamente observadas; `BattlePhaseTracker` estima a fase pela taxa de regeneração própria; `OpponentElixirTracker` mantém uma faixa parcial do elixir rival.
4. **Decisão:** `Defense` prioriza ameaças reconhecidas; `Strategy` controla a pressão ofensiva conservadora; `PlacementPlanner` calcula zonas por papel da carta e separa apoio à distância do alvo.
5. **HUD:** `BotService` apresenta ameaças, confiança, histórico e setas que expiram. Não executa toques nesta versão.

## Componentes e mudanças 0.9.0

### Captura e percepção

- A análise da arena agora continua mesmo quando a leitura da mão falha. Uma mão incerta bloqueia recomendações, mas não interrompe a observação das tropas.
- O detector ONNX continua local, INT8 e com 97 classes.
- A região vertical analisada foi ampliada até perto da parte inferior da arena, sem incluir a maior parte da barra de cartas.
- `Enemy` mantém a associação temporal por barras de vida e ganhou uma rota de fallback para caixas do modelo sem barra detectada. O fallback só classifica diretamente como provável inimigo uma caixa no lado adversário; uma caixa nova no lado do jogador permanece incerta. A identidade precisa de confirmação em mais de um frame.
- A rota de fallback reduz perdas quando o OCR simples da barra falha, mas pode produzir incerteza; não é uma garantia de detecção perfeita.

### Memória própria e ciclo rival

- `OwnDeckTracker` compara duas leituras estáveis e só registra uma carta quando a mão segue o padrão de remoção, deslocamento e compra de uma nova carta.
- `OpponentDeckTracker` lista cartas rivais observadas em tropas confirmadas e mantém um histórico recente.
- O app **não infere a mão adversária** a partir de observações incompletas. Feitiços, edifícios e tropas não reconhecidas podem faltar; por isso, o ciclo rival ainda é parcial.

### Elixir e fase da partida

- `BattlePhaseTracker` estima regeneração normal/dobrada/tripla a partir de janelas de elixir próprio e custos de jogadas próprias confirmadas.
- A fase só é marcada como provável após janelas consistentes. Leituras no limite de 10 elixires são ignoradas porque o limite mascara regeneração.
- `OpponentElixirTracker` continua a fornecer um intervalo, não um número exato. Ele parte de 5 quando o guia é iniciado; começar no meio da partida pode invalidar o ponto inicial. Feitiços e edifícios ainda não entram no cálculo.

### Decisão e posicionamento

- `Defense` continua a priorizar ameaças reconhecidas e a não inventar uma resposta quando o tipo é incerto.
- `PlacementPlanner` separa Mosqueteira/apoio à distância do alvo, usa zona central para Tesla/edifícios e desloca Esqueletos para distração lateral.
- `Strategy` recebe eventos próprios confirmados, inclusive jogadas de baixo custo que antes podiam não ser percebidas por uma simples queda de elixir.
- O motor permanece heurístico e específico do Deck 4; não é um modelo de política treinado nem equivale a um jogador profissional.

## Deck configurado

Corredor, Cavaleiro Herói, Mosqueteira, Esqueletos, Tesla, Príncipe das Trevas, Barril de Goblins e Espírito de Gelo. Média confirmada pelo jogo: 3,0.

## Limites ainda abertos

- Reconhecimento de cartas continua baseado em amostras RGB e pode retornar `?`.
- Não há OCR robusto da vida das seis torres nem leitura confiável do cronômetro.
- Não há detector dedicado de feitiços/efeitos ou edifícios colocados pelo adversário.
- O deck rival pode ficar incompleto; a mão e a próxima carta do adversário não são inferidas nesta versão.
- Habilidade do Cavaleiro Herói não é detectada nem acionada.
- Não há execução automática de gestos/toques; o usuário continua realizando as jogadas.
- A precisão, latência, bateria e temperatura ainda precisam ser medidas no POCO X6 Pro em treino/replay.

## Testes

`bash scripts/run-pure-tests.sh` executa onze conjuntos de testes Java puros, incluindo 120.960 casos de orçamento/geometria, transições do ciclo próprio, inferência de fase, fallback de tropas, posicionamento de apoio e observações do deck rival. Eles validam lógica Java isolada, não a integração Android nem partidas reais.

## Compilação

JDK 17, Android SDK Platform 35, Build Tools 35.0.0 e Gradle 8.13. Use `GITHUB_BUILD_PTBR.md` para gerar o APK debug pelo GitHub Actions. O ambiente desta sessão não possui Android SDK/Gradle, portanto o APK precisa ser compilado no GitHub Actions.

## Segurança e licença

A captura e inferência são locais; não há endpoint de envio de frames no app. O serviço usa Acessibilidade para capturar a janela e desenhar o HUD. Mantenha o Play Protect ligado e conceda a permissão somente se concordar com esse comportamento. Preserve AGPL-3.0 e avisos de terceiros; revise a licença do modelo e dos assets antes de redistribuir.

O projeto é independente e não é afiliado à Supercell. Use primeiro em treino/replay. Nenhuma sugestão garante defesa, vitória ou ausência de penalidades de acordo com as regras do jogo.
