# BotClash Android 0.9.0-alpha

## Arquitetura e melhorias

- A captura da arena e o detector de tropas não dependem mais de a mão de cartas ter sido reconhecida. Se a mão falhar, o app continua observando ameaças, mas não sugere jogadas.
- Ampliada a região do detector para acompanhar melhor tropas que avançam na direção das torres do jogador.
- Adicionado fallback temporal para caixas ONNX sem barra de vida reconhecida. Caixas no lado adversário podem ser confirmadas após múltiplos frames; caixas novas no lado do jogador continuam incertas.
- Adicionado `OwnDeckTracker`: reconstrói jogadas próprias somente quando duas leituras estáveis confirmam remoção, deslocamento e compra de carta.
- Adicionado `OpponentDeckTracker`: mostra até oito identidades rivais observadas e o histórico recente, sem inventar a mão adversária.
- Adicionado `BattlePhaseTracker`: estima elixir normal/dobrado/triplo a partir de janelas de regeneração próprias e custos confirmados.
- Adicionado `PlacementPlanner`: posiciona apoio à distância atrás e afastado da ameaça, usa zona central para construções e desloca Esqueletos para distração.
- Estratégia recebe eventos próprios confirmados, incluindo cartas de baixo custo.
- Painel e diagnóstico passam a exibir fase estimada, histórico próprio, deck rival observado e limitações de inferência.
- Atualizado o fluxo de compilação para `android-actions/setup-android@v4` e artefatos 0.9.0.

## Limitações mantidas

- Leitura de cartas ainda usa amostras RGB e pode retornar `?`.
- Elixir rival continua parcial, parte de 5 ao iniciar GUIAR e não contabiliza feitiços/edifícios não detectados.
- O deck rival é apenas a lista de cartas vistas; mão/ciclo exatos ainda não são inferidos.
- Sem OCR de vida das torres, sem detector dedicado de feitiços e sem habilidade do Cavaleiro Herói.
- O app continua em modo GUIA manual. Não executa toques nem joga sozinho.
- O APK ainda precisa ser compilado pelo GitHub Actions e testado fisicamente no POCO X6 Pro.
