# BotClash Android 0.8.1-alpha — Deck 4

## Alterações
- Perfil Deck 4 configurado com as oito cartas da captura do usuário.
- Média de elixir conferida: 3,0.
- Corredor definido como condição de vitória principal.
- Barril de Goblins tratado como condição secundária, sem sugestão automática enquanto o ciclo de feitiço do adversário não for observado.
- Cavaleiro Herói fica como opção defensiva/interceptação; não é gasto como ataque de abertura.
- Esqueletos adicionados ao catálogo (1 elixir) e à lógica de distração contra unidade terrestre de alvo único, nunca contra splash/ameaça incerta.
- Novas amostras visuais de Esqueletos, Barril de Goblins e Espírito de Gelo derivadas da captura do deck.

## Validação
- `StrategyTest`: passou.
- `DeckProfileTest`: passou.
- `AdviceTest`: passou (120.960 casos).
- `OpponentElixirTrackerTest`: passou.

## Limitações
- As novas amostras ainda precisam ser verificadas com uma captura da mão durante batalha no POCO X6 Pro.
- APK não compilado neste ambiente: Android SDK/Build Tools e Gradle não estão instalados.
- Mantém modo GUIA, sem toques automáticos.
