import com.botclash.teste.*;

public final class OpponentDeckTrackerTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    private static Enemy.Unit unit(String name, float x, float y) {
        Enemy.Unit u = new Enemy.Unit(name, x - 15, y - 25, x + 15, y + 25, .95f);
        u.newlyConfirmed = true;
        return u;
    }

    public static void main(String[] args) {
        OpponentDeckTracker tracker = new OpponentDeckTracker();
        Enemy.Scene scene = new Enemy.Scene();
        scene.units.add(unit("hog_rider", 150, 700));
        scene.units.add(unit("musketeer", 180, 720));
        scene.units.add(unit("golemite", 210, 740));
        tracker.observe(scene);
        check(tracker.knownCount() == 2, "only confirmed playable card families enter the seen deck");
        check(tracker.summary().contains("2/8"), "known-deck coverage is explicit");
        check(tracker.recentSummary().contains("mão não inferida"),
                "partial troop observations do not fabricate the opponent hand");
        tracker.observe(scene);
        check(tracker.knownCount() == 2, "the same non-new detections are not counted twice");
        System.out.println("PASS opponent deck sightings and conservative cycle reporting");
    }
}
