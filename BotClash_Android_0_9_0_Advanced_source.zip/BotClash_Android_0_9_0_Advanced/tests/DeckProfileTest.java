import com.botclash.teste.*;
public class DeckProfileTest {
    static void ck(boolean b, String m) { if (!b) throw new AssertionError(m); }
    public static void main(String[] args) {
        ck(DeckProfile.CARDS.length == 8, "eight deck cards");
        ck(DeckProfile.averageElixirTenths() == 30, "average elixir 3.0");
        ck(DeckProfile.contains(10) && DeckProfile.isPrimaryWinCondition(10), "Hog primary win condition");
        ck(DeckProfile.contains(1) && DeckProfile.isSecondaryWinCondition(1), "Goblin Barrel secondary win condition");
        ck(Vision.NAMES.length == 15 && Vision.COST[14] == 1, "Skeletons in card catalog");
        ck(Vision.templateId("hand_14_userdeck") == 14, "Skeletons template id");
        ck(DeckProfile.isReserveCard(9) && DeckProfile.isReserveCard(11) && DeckProfile.isReserveCard(12), "defensive reserve");
        System.out.println("PASS Deck 4 profile, average elixir, card ids and reserve roles");
    }
}
