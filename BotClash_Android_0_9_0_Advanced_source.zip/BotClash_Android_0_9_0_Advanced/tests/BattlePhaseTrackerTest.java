import com.botclash.teste.*;

public final class BattlePhaseTrackerTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        BattlePhaseTracker normal = new BattlePhaseTracker();
        normal.observe(5, 0, 0L);
        normal.observe(7, 0, 6000L);
        BattlePhaseTracker.Snapshot n = normal.observe(9, 0, 12000L);
        check(n.confirmed && n.multiplier == 1, "normal regeneration is confirmed after repeated windows");

        BattlePhaseTracker doubled = new BattlePhaseTracker();
        doubled.observe(5, 0, 0L);
        doubled.observe(6, 3, 6000L);  // +3 regenerated, +3 spent = 6 total net accounting.
        BattlePhaseTracker.Snapshot d = doubled.observe(7, 3, 12000L);
        check(d.confirmed && d.multiplier == 2, "double elixir inferred from corrected elixir deltas");

        BattlePhaseTracker tripled = new BattlePhaseTracker();
        tripled.observe(5, 0, 0L);
        tripled.observe(7, 4, 6000L);
        BattlePhaseTracker.Snapshot t = tripled.observe(9, 4, 12000L);
        check(t.confirmed && t.multiplier == 3, "triple elixir inferred from corrected elixir deltas");

        BattlePhaseTracker midMatch = new BattlePhaseTracker();
        check(!midMatch.snapshot().confirmed, "starting guide mid-match does not claim a known phase");
        System.out.println("PASS conservative elixir phase inference and mid-match uncertainty");
    }
}
