import com.botclash.teste.*;
import java.util.*;

public final class EnemyFallbackTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    private static Enemy.Unit unit(String name, float x, float y) {
        return new Enemy.Unit(name, x - 25, y - 55, x + 25, y + 45, .90f);
    }

    public static void main(String[] args) {
        int[] blank = new int[691 * 1536];
        Enemy tracker = new Enemy();
        List<Enemy.Unit> raw = Collections.singletonList(unit("hog_rider", 180, 650));
        Enemy.Scene first = tracker.update(raw, blank, 1000L);
        check(first.units.isEmpty() && first.uncertain,
                "one raw frame is a possible threat, not a confirmed identity");
        Enemy.Scene second = tracker.update(raw, blank, 1500L);
        check(second.units.size() == 1 && "hog_rider".equals(second.units.get(0).name),
                "raw detector boxes can be confirmed when health-bar OCR misses");
        check(second.units.get(0).newlyConfirmed,
                "confirmed fallback detection emits one card-play event");
        Enemy.Scene third = tracker.update(raw, blank, 2000L);
        check(!third.units.get(0).newlyConfirmed,
                "same tracked troop does not emit a duplicate play event");

        tracker.reset();
        List<Enemy.Unit> lower = Collections.singletonList(unit("musketeer", 500, 950));
        Enemy.Scene ownHalf = tracker.update(lower, blank, 3000L);
        check(ownHalf.units.isEmpty(),
                "an untracked box on the player's half is not automatically called an enemy");
        System.out.println("PASS health-bar-independent enemy fallback with team-side safeguards");
    }
}
