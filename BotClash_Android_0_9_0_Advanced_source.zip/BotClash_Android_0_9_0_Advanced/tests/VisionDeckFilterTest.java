import com.botclash.teste.*;
import java.util.Arrays;

public final class VisionDeckFilterTest {
    public static void main(String[] args) {
        Vision vision = new Vision();
        int[] sample = new int[24 * 28];
        Arrays.fill(sample, 0x334455);
        vision.templates.put("next_0", sample.clone()); // Ice Golem is not in the configured deck.
        vision.templates.put("next_10", sample.clone()); // Hog Rider is in the configured deck.
        if (vision.matchNext(sample) != 10) {
            throw new AssertionError("next-card matching must ignore identities outside Deck 4");
        }
        System.out.println("PASS next-card recognition is restricted to the configured deck");
    }
}
