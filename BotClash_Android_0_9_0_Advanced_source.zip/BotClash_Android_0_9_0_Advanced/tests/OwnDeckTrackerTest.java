import com.botclash.teste.*;

public final class OwnDeckTrackerTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    private static Vision.Reading hand(int... cards) {
        Vision.Reading r = new Vision.Reading();
        r.valid = true;
        r.elixir = 8;
        r.cards = cards;
        return r;
    }

    public static void main(String[] args) {
        OwnDeckTracker tracker = new OwnDeckTracker();
        Vision.Reading base = hand(10, 12, 11, 14);
        check(tracker.observe(base, 1000L) == null, "first hand frame is only a candidate");
        check(tracker.observe(base, 1500L) == null, "initial stable hand establishes baseline");

        Vision.Reading afterSlot1 = hand(10, 11, 14, 13);
        check(tracker.observe(afterSlot1, 2000L) == null, "one changed frame cannot emit a play");
        OwnDeckTracker.PlayEvent event = tracker.observe(afterSlot1, 2500L);
        check(event != null, "confirmed remove/shift/draw transition emits event");
        check(event.card == 12 && event.slot == 1 && event.drawnCard == 13,
                "event identifies the removed card, slot and newly drawn card");
        check(tracker.totalPlays() == 1, "one transition counts once");
        check(tracker.observe(afterSlot1, 3000L) == null, "same stable hand does not double count");

        Vision.Reading afterSlot0 = hand(11, 14, 13, 8);
        tracker.observe(afterSlot0, 3500L);
        event = tracker.observe(afterSlot0, 4000L);
        check(event != null && event.card == 10 && event.slot == 0,
                "slot-zero transition is reconstructed");
        check(tracker.totalPlays() == 2, "second transition increments count");

        Vision.Reading ambiguous = hand(11, -1, 13, 8);
        check(tracker.observe(ambiguous, 4500L) == null, "partial hand never invents a play");
        Vision.Reading unrelated = hand(10, 12, 11, 14);
        tracker.observe(unrelated, 5000L);
        check(tracker.observe(unrelated, 5500L) == null, "non-cycle transition is not guessed");
        check(tracker.totalPlays() == 2, "ambiguous transition leaves history unchanged");
        System.out.println("PASS own hand-cycle tracking, stable confirmation and conservative event inference");
    }
}
