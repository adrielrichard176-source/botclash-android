#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="$ROOT/android-studio-project/app/src/main/java/com/botclash/teste"
TESTS="$ROOT/tests"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT

javac -encoding UTF-8 -d "$OUT" \
  "$APP/Advice.java" \
  "$APP/BattlePhaseTracker.java" \
  "$APP/DeckProfile.java" \
  "$APP/Defense.java" \
  "$APP/Enemy.java" \
  "$APP/HandStability.java" \
  "$APP/NextLearner.java" \
  "$APP/OwnDeckTracker.java" \
  "$APP/PlacementPlanner.java" \
  "$APP/OpponentDeckTracker.java" \
  "$APP/OpponentElixirTracker.java" \
  "$APP/OpponentPlayObserver.java" \
  "$APP/Strategy.java" \
  "$APP/Vision.java" \
  "$TESTS/AdviceTest.java" \
  "$TESTS/BattlePhaseTrackerTest.java" \
  "$TESTS/EnemyFallbackTest.java" \
  "$TESTS/OwnDeckTrackerTest.java" \
  "$TESTS/PlacementPlannerTest.java" \
  "$TESTS/DeckProfileTest.java" \
  "$TESTS/OpponentDeckTrackerTest.java" \
  "$TESTS/OpponentElixirTrackerTest.java" \
  "$TESTS/OpponentPlayObserverTest.java" \
  "$TESTS/VisionDeckFilterTest.java" \
  "$TESTS/StrategyTest.java"

for test in AdviceTest BattlePhaseTrackerTest DeckProfileTest EnemyFallbackTest OwnDeckTrackerTest PlacementPlannerTest OpponentDeckTrackerTest OpponentElixirTrackerTest OpponentPlayObserverTest VisionDeckFilterTest StrategyTest; do
  java -cp "$OUT" "$test"
done
