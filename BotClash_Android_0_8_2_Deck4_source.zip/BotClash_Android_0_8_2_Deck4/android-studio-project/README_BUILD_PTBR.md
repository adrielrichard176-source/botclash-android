# Compilação Android

Este diretório contém um projeto Android Gradle convencional, separado do pacote de prévia manual.

## Requisitos

- Android Studio compatível com Android Gradle Plugin 8.13.2.
- JDK 17 ou superior.
- Android SDK Platform 35 e Build Tools compatíveis.
- Acesso ao Maven Central para resolver `onnxruntime-android:1.23.2`.

## Gerar APK de teste

1. Abra `android-studio-project` no Android Studio.
2. Aguarde o Gradle Sync e aceite as licenças do SDK.
3. Selecione `app` e a variante `debug`.
4. Execute **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de teste será criado em `app/build/outputs/apk/debug/`.

A variante debug usa sufixo de pacote `.debug`, então pode coexistir com outra instalação. Para uma versão de atualização com o mesmo identificador do app anterior, será necessário gerar uma assinatura compatível; a chave privada da versão antiga não está neste pacote.

## Limitação desta entrega

O ambiente de trabalho desta sessão não contém Android SDK, Build Tools nem Gradle, e não conseguiu acessar os servidores de download. Portanto, este projeto foi organizado, mas **nenhum APK foi compilado ou validado neste turno**.
