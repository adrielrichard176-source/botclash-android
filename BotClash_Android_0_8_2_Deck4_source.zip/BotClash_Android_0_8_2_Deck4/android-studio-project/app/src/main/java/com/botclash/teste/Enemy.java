package com.botclash.teste;
import java.util.*;
/** Detection filtering and short temporal confirmation. Coordinates: 691 x 1536. */
public final class Enemy {
 public static class Unit {public String name;public float x1,y1,x2,y2,confidence;public int hits=1;public long time;public boolean enemy,newlyConfirmed;public float x(){return (x1+x2)/2;}public float y(){return y2;}public Unit(String n,float l,float t,float r,float b,float c){name=n;x1=l;y1=t;x2=r;y2=b;confidence=c;}}
 public static class Scene {public List<Unit> units=new ArrayList<>();public Unit main;public boolean right,splash,air,uncertain;public long time;public int markers;public String summary="Nenhuma ameaça confirmada";}
 static class Badge {float x,y;boolean red;Badge(float a,float b,boolean c){x=a;y=b;red=c;}}
 private long last;
 public void reset(){tracks.clear();last=0;}
 static boolean color(int p,boolean red){int r=p>>16&255,g=p>>8&255,b=p&255;return red?r>70&&r<210&&g<90&&b>20&&r>g*1.6&&r>b*1.12:b>80&&r<g*.85&&g>50&&g<180&&b>r*1.3;}
 static boolean white(int p){int r=p>>16&255,g=p>>8&255,b=p&255;return Math.min(r,Math.min(g,b))>205&&Math.max(r,Math.max(g,b))-Math.min(r,Math.min(g,b))<55;}
 static List<Badge> badges(int[] p){
  List<Badge> out=new ArrayList<>();int w=691;int[] directions={-1,1,-w,w};boolean[] seen=new boolean[p.length];int[] queue=new int[p.length];
  // Read white digits with a colored border: a red flood fill merges into arena lanes.
  for(int y=420;y<1115;y++)for(int x=28;x<663;x++){
   int start=y*w+x;if(seen[start]||!white(p[start]))continue;int head=0,tail=0,l=x,r=x,t=y,b=y;queue[tail++]=start;seen[start]=true;
   while(head<tail){int i=queue[head++],xx=i%w,yy=i/w;l=Math.min(l,xx);r=Math.max(r,xx);t=Math.min(t,yy);b=Math.max(b,yy);for(int d:directions){int j=i+d,jx=j%w,jy=j/w;if(jx<28||jx>=663||jy<420||jy>=1115||seen[j]||!white(p[j]))continue;seen[j]=true;queue[tail++]=j;}}
   int bw=r-l+1,bh=b-t+1;if(bw<3||bw>19||bh<8||bh>20||tail<12)continue;
   int red=0,blue=0,tr=0,br=0,tb=0,bb=0;
   for(int yy=t-3;yy<=b+3;yy++)for(int xx=l-3;xx<=r+3;xx++){int c=p[yy*w+xx];if(color(c,true)){red++;if(yy<t)tr++;if(yy>b)br++;}if(color(c,false)){blue++;if(yy<t)tb++;if(yy>b)bb++;}}
   boolean hostile=red>=30&&red>blue*2&&tr>=4&&br>=4;boolean ally=blue>=30&&blue>red*2&&tb>=4&&bb>=4;
   if(!hostile&&!ally)continue;float cx=(l+r)/2f,cy=(t+b)/2f;Badge merged=null;
   for(Badge v:out)if(v.red==hostile&&Math.abs(v.x-cx)<19&&Math.abs(v.y-cy)<5){merged=v;break;}
   if(merged==null)out.add(new Badge(cx,cy,hostile));else{merged.x=(merged.x+cx)/2;merged.y=(merged.y+cy)/2;}
  }return out;
 }
 static boolean outside(Unit u){float x=u.x(),y=(u.y1+u.y2)/2;return y<300||y>1130||x<28||x>663;}
 static double badgeDistance(Unit u,Badge b){if(b.x<u.x1-27||b.x>u.x2+20||b.y<u.y1-58||b.y>u.y1+(u.y2-u.y1)*.6)return 1e6;return Math.abs(b.x-u.x())*.45+Math.abs(b.y-u.y1);}
 static class Track {float x,y;int hits;long seen;Unit box;boolean playEventEmitted;ArrayDeque<String> votes=new ArrayDeque<>();}
 private final List<Track> tracks=new ArrayList<>();
 public Scene update(List<Unit> raw,int[] pixels,long now){
  if(last!=0&&(now-last>1400||now<last))tracks.clear();last=now;
  Scene s=new Scene();s.time=now;List<Badge> marks=badges(pixels);List<Track> next=new ArrayList<>();Set<Track> used=new HashSet<>();Set<Unit> usedUnits=new HashSet<>();
  for(Badge b:marks){if(!b.red)continue;s.markers++;Track track=null;double nearest=85;
   for(Track t:tracks){double dist=Math.hypot(t.x-b.x,t.y-b.y);if(!used.contains(t)&&now-t.seen<=1100&&dist<nearest){track=t;nearest=dist;}}
   if(track==null)track=new Track();else used.add(track);Unit best=null;double quality=-1;
   for(Unit u:raw){if(usedUnits.contains(u)||u.confidence<.62f||outside(u)||u.name.equals("giant_snowball")||u.name.equals("phoenix_egg"))continue;
    double red=badgeDistance(u,b);if(red>=1e6)continue;double blue=1e6,otherRed=red;
    for(Badge m:marks){if(!m.red)blue=Math.min(blue,badgeDistance(u,m));else otherRed=Math.min(otherRed,badgeDistance(u,m));}
    if(red>otherRed+1||red+10>=blue)continue;double q=u.confidence-red*.003;if(q>quality){best=u;quality=q;}
   }
   track.x=b.x;track.y=b.y;track.seen=now;track.hits++;track.votes.addLast(best==null?"?":best.name);while(track.votes.size()>4)track.votes.removeFirst();
   String name="unknown";int agree=0;
   if(best!=null){usedUnits.add(best);for(String n:track.votes)if(n.equals(best.name))agree++;if(agree>=2&&agree*3>=track.votes.size()*2)name=best.name;}
   Unit u=best==null?new Unit(name,b.x-25,b.y+8,b.x+30,Math.min(1130,b.y+85),0):new Unit(name,best.x1,best.y1,best.x2,best.y2,best.confidence);
   boolean newlyConfirmed=!name.equals("unknown")&&!track.playEventEmitted;
   if(newlyConfirmed)track.playEventEmitted=true;
   u.enemy=true;u.newlyConfirmed=newlyConfirmed;u.time=now;u.hits=track.hits;track.box=u;next.add(track);if(name.equals("unknown"))s.uncertain=true;if(track.hits>=2)s.units.add(u);
  }
  // A brief occlusion retains only presence, never a stale identity.
  for(Track t:tracks)if(!used.contains(t)&&now-t.seen<=750&&t.hits>=2){next.add(t);s.uncertain=true;s.markers++;Unit b=t.box;Unit u=new Unit("unknown",b.x1,b.y1,b.x2,b.y2,0);u.enemy=true;u.time=t.seen;s.units.add(u);}
  tracks.clear();tracks.addAll(next);float left=0,right=0;
  for(Unit u:s.units){float d=danger(u);if(u.x()>345.5f)right+=d;else left+=d;}s.right=right>left;
  for(Unit u:s.units)if((u.x()>345.5f)==s.right){if(s.main==null||danger(u)>danger(s.main))s.main=u;if(splash(u.name))s.splash=true;if(air(u.name))s.air=true;}
  if(s.main!=null&&s.main.name.equals("unknown")){Unit known=null;for(Unit u:s.units)if(!u.name.equals("unknown")&&(u.x()>345.5f)==s.right&&(known==null||danger(u)>danger(known)))known=u;if(known!=null&&s.main.y()-known.y()<130)s.main=known;}
  if(s.main!=null){StringBuilder names=new StringBuilder();Set<String> added=new HashSet<>();List<Unit> sorted=new ArrayList<>(s.units);sorted.sort((a,b)->{if(a.name.equals("unknown")!=b.name.equals("unknown"))return a.name.equals("unknown")?1:-1;return Float.compare(danger(b),danger(a));});for(Unit u:sorted)if((u.x()>345.5f)==s.right&&added.add(u.name)&&added.size()<=2){if(names.length()>0)names.append(" + ");names.append(label(u.name));}s.summary=(s.right?"Direita":"Esquerda")+" • "+names;}
  else if(s.markers>0)s.summary="Inimigo visível • confirmando posição";
  else s.summary="Sem inimigo identificado nesta leitura";return s;
 }
 static float iou(Unit a,Unit b){float inter=Math.max(0,Math.min(a.x2,b.x2)-Math.max(a.x1,b.x1))*Math.max(0,Math.min(a.y2,b.y2)-Math.max(a.y1,b.y1));return inter/Math.max(1,(a.x2-a.x1)*(a.y2-a.y1)+(b.x2-b.x1)*(b.y2-b.y1)-inter);}
 public static boolean air(String n){return Arrays.asList("balloon","bat","electro_dragon","flying_machine","hungry_dragon","inferno_dragon","lava_hound","lava_pup","mega_minion","minion","phoenix_large","phoenix_small","skeleton_dragon").contains(n);}
 public static boolean splash(String n){return Arrays.asList("witch","wizard","executioner","hungry_dragon","electro_dragon","firecracker","ice_wizard","magic_archer").contains(n);}
 public static boolean kite(String n){return Arrays.asList("pekka","minipekka","knight","prince","elite_barbarian","lumberjack").contains(n);}
 public static boolean buildingTarget(String n){return Arrays.asList("hog_rider","hog","royal_hog","ram_rider","battle_ram","giant","golem","golemite","royal_giant","electro_giant","elixir_golem_large","balloon","lava_hound","wall_breaker").contains(n);}
 static float danger(Unit u){float base=u.name.equals("unknown")?5:kite(u.name)?8:buildingTarget(u.name)?9:splash(u.name)?7:2;return base*(.5f+Math.max(0,u.y()-400)/400f);}
 public static String label(String n){switch(n){case "unknown":return "tipo incerto";case "guard":return "Guarda";case "musketeer":return "Mosqueteira";case "battle_healer":return "Curadora Guerreira";case "golden_knight":return "Cavaleiro Dourado";case "pekka":return "P.E.K.K.A";case "witch":return "Bruxa";case "minipekka":return "Mini P.E.K.K.A";case "knight":return "Cavaleiro";case "royal_recruit":return "Recruta Real";case "skeleton":return "Esqueleto";case "wizard":return "Mago";case "hog_rider":return "Corredor";case "giant":return "Gigante";case "golem":return "Golem";case "balloon":return "Balão";case "valkyrie":return "Valquíria";case "minion":return "Servo";case "hungry_dragon":return "Bebê Dragão";case "prince":return "Príncipe";case "mega_knight":return "Megacavaleiro";case "electro_wizard":return "Mago Elétrico";default:return n.replace('_',' ');}}
}
