# BotClash Android 0.8.2-alpha

Adaptação Android experimental inspirada no py-clash-bot. Projeto configurado para o POCO X6 Pro 5G e o Deck 4 informado pelo usuário.

## O que existe nesta versão

- Captura local da janela do Clash Royale por AccessibilityService (Android 14+ usa captura da janela; há fallback de tela inteira).
- Leitura visual da mão e da próxima carta usando amostras RGB locais. A classificação foi limitada às oito cartas do Deck 4 configurado.
- Detector de tropas inimigas com modelo ONNX local de 97 classes e confirmação temporal por barras de vida.
- Estratégia heurística de defesa nas duas pistas e sugestão de pressão com Corredor quando as condições conservadoras são atendidas.
- Estimativa intervalar e parcial do elixir adversário, baseada em tropas recém-confirmadas. Usa custos em faixa para classes ambíguas e ignora formas geradas por outras cartas.
- HUD flutuante com setas, leitura e botão para copiar diagnóstico.

## O que ainda não existe / não está validado

- Não é um bot automático: não envia toques nem joga sozinho. O usuário escolhe e joga as cartas.
- A estimativa do elixir adversário supõe regeneração normal e começa com 5 elixires quando o guia é iniciado. Iniciar no meio da partida pode produzir uma faixa incorreta. Feitiços não são detectados como jogadas.
- A captura, a taxa de quadros, o consumo de bateria e a precisão do detector ainda precisam ser medidos no POCO X6 Pro.
- A leitura de cartas depende das amostras incluídas e pode retornar `?` quando não houver confiança suficiente.
- A estratégia é heurística, não equivale ao julgamento de um jogador profissional e não garante vitória.

## Testes locais executados

Execute `bash scripts/run-pure-tests.sh`. Nesta revisão passaram seis conjuntos de testes: orçamento/roles/geometria (120.960 casos), perfil do Deck 4, estimador intervalar, observador de jogadas adversárias, filtro visual do deck e estratégia nas duas pistas. Esses testes validam somente a lógica Java pura; não validam a integração Android nem uma partida real.

## Compilação

Abra `android-studio-project` no Android Studio com JDK 17+, Android SDK Platform 35 e Build Tools 35.0.0. Ou use o fluxo de GitHub Actions descrito em `GITHUB_BUILD_PTBR.md`. O ambiente desta sessão não possui Android SDK/Gradle nem acesso aos servidores de download; portanto, nenhum APK foi compilado aqui.

## Deck configurado

Corredor, Cavaleiro Herói, Mosqueteira, Esqueletos, Tesla, Príncipe das Trevas, Barril de Goblins e Espírito de Gelo. Média de elixir indicada pelo jogo: 3,0.
