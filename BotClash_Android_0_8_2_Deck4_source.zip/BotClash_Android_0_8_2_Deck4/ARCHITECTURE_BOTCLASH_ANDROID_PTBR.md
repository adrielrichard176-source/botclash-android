# BotClash Android 0.8.2-alpha - arquitetura atual

**Alvo:** POCO X6 Pro 5G, Dimensity 8300-Ultra, Android 16.
**Objetivo desta fase:** assistente local de visao computacional e estrategia para Clash Royale, instalado como APK.
**Modo desta versao:** GUIA manual. O app nao executa toques nem joga sozinho.

## Principios

1. Android nativo: APK instalavel, sem PC ou emulador para usar depois de compilado.
2. Local-first: captura e inferencia no aparelho; as imagens nao sao enviadas a um servidor pelo app.
3. Sem falsa certeza: cartas, tropas e elixir adversario podem ficar como incertos.
4. Defesa primeiro: nao sugerir ataque quando a arena, a mao ou o elixir proprio estiverem incertos.
5. Acao humana: o app mostra a carta e o local sugerido; o usuario confirma e faz o toque.
6. Medicao real: latencia, bateria, temperatura e precisao precisam ser medidas no POCO.

## Componentes implementados

### Aplicativo e permissoes

- `MainActivity`: instrucoes, permissao de acessibilidade, abertura do Clash e limpeza do aprendizado local.
- `BotService`: ciclo de captura, overlay, pausa ao sair do jogo e diagnostico.
- `AccessibilityService`: captura da janela do Clash quando suportada; fallback para tela inteira com mascara do painel.

### Visao computacional

- `Vision`: leitura da mao, elixir proprio e proxima carta por comparacao de amostras RGB.
- A leitura da mao e da proxima carta esta restrita as oito identidades do Deck 4 configurado, para reduzir confusao com amostras de outros decks.
- `EnemyModel`: modelo ONNX local INT8 com 97 classes de unidades.
- `Enemy`: usa barras de vida inimigas e confirmacao temporal para associar caixas do modelo a tropas do adversario.

### Estado e estrategia

- `DeckProfile`: Corredor, Cavaleiro Heroi, Mosqueteira, Esqueletos, Tesla, Principe das Trevas, Barril de Goblins e Espirito de Gelo. Media 3,0.
- `Strategy` e `Defense`: heuristicas de defesa nas duas pistas, reserva de elixir e pressao com Corredor quando a leitura permite.
- `OpponentPlayObserver` + `OpponentElixirTracker`: faixa parcial de elixir adversario a partir de tropas recem-confirmadas. Custos ambiguos usam intervalos; tokens gerados por outras cartas sao ignorados.

## Limites conhecidos

- O elixir adversario comeca em 5 quando o usuario toca GUIAR. Se o guia for iniciado no meio da partida, a estimativa pode estar errada.
- A regeneracao e presumida normal. A fase de elixir dobrado/triplo ainda nao e reconhecida.
- Feiticos nao sao detectados como jogadas; tropas que o modelo nao reconhece tambem nao entram no calculo. Por isso, a faixa e parcial, nao uma leitura exata.
- O reconhecimento das cartas depende das amostras RGB e pode retornar `?`.
- O detector de tropas pode perder unidades ou confundir classes.
- O ciclo adversario completo nao esta implementado.
- O Cavaleiro Heroi ainda nao tem leitura/acionamento de habilidade.
- Nao existe automacao de toques nesta versao.
- Nenhum benchmark fisico foi executado no POCO X6 Pro nesta sessao.

## Seguranca e uso

Use primeiro em treino ou replay. O usuario deve conferir a arena antes de jogar qualquer carta. A estrategia e heuristica e nao garante defesa perfeita, vitoria ou pontuacao. O projeto e independente e nao e afiliado a Supercell.

## Testes

`bash scripts/run-pure-tests.sh` executa seis conjuntos de testes Java puros. Eles cobrem regras e modulos sem Android; nao substituem build Android, instalacao ou teste real no aparelho.

## Compilacao

O projeto Android usa Android Gradle Plugin 8.13.2, Gradle 8.13, JDK 17, SDK Platform 35 e Build Tools 35.0.0. O ambiente atual nao possui Android SDK/Gradle nem acesso aos servidores de download; use o fluxo de GitHub Actions descrito em `GITHUB_BUILD_PTBR.md`.

## Licencas

Manter AGPL-3.0 e avisos de terceiros incluidos no projeto. Revisar as licencas de codigo, modelo e assets antes de redistribuir publicamente ou comercializar.
