# Gerar e baixar o APK BotClash Android 0.8.2-alpha

Este pacote contém o projeto Android e um fluxo de GitHub Actions. O ambiente desta sessão não tem Android SDK/Build Tools nem acesso aos servidores do Gradle; por isso, o APK precisa ser compilado remotamente.

## O que o fluxo faz

1. Baixa o repositório.
2. Prepara Java 17, Android SDK 35, Build Tools 35.0.0 e Gradle 8.13.
3. Executa os seis conjuntos de testes Java puros.
4. Compila a variante `debug` do Android.
5. Publica o APK e o SHA-256 como artefato da execução e anexa os arquivos a um GitHub Release de pré-lançamento `v0.8.2-alpha`.

## Configuração pelo Android

1. Abra `https://github.com/new` e crie um repositório (pode ser privado).
2. Envie `BotClash_Android_0_8_2_Deck4_source.zip` para a raiz do repositório e faça o commit.
3. Crie o arquivo `.github/workflows/build-android.yml`. Cole nele o conteúdo completo de `GITHUB_ACTIONS_WORKFLOW.yml` deste pacote e faça o commit.
4. Abra a aba **Actions**. Se necessário, selecione **BotClash Android APK** e toque em **Run workflow**.
5. Aguarde a execução terminar. O APK aparecerá em **Artifacts** e também na página **Releases** como `BotClash-Android-0.8.2-debug.apk`. A página será `https://github.com/SEU_USUARIO/SEU_REPOSITORIO/releases/tag/v0.8.2-alpha`.
6. Baixe o APK, abra no POCO X6 Pro e autorize a instalação para o navegador/Arquivos, se o Android solicitar.

## Importante

- O APK é `debug`, assinado com chave de teste gerada pelo Android Gradle Plugin.
- O pacote usa `applicationId` `com.botclash.teste.debug`, portanto pode coexistir com outra instalação de ID diferente.
- Esta versão é um GUIA visual: captura a tela, reconhece parte da mão e das tropas e mostra sugestões/setas. Você confirma e realiza os toques. Não executa jogadas automaticamente.
- O elixir adversário é uma faixa aproximada baseada em tropas confirmadas; assume regeneração normal e 5 elixires quando o guia é iniciado. Iniciar no meio da partida, feitiços, tropas não reconhecidas e unidades geradas podem afetar a estimativa.
- Valide em treino/replay antes de usar em partidas valendo troféus. Não há garantia de precisão ou vitória.
- Não publique o APK publicamente sem revisar a licença AGPL-3.0 e os avisos de terceiros incluídos no projeto.
