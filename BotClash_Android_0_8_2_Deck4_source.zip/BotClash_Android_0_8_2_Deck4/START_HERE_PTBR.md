# BotClash Android 0.8.2-alpha — inicio rapido

Este pacote continua a adaptacao Android da base 0.7-preview. A versao 0.8.2 restringe a leitura ao Deck 4 e conecta eventos confirmados do detector ao estimador parcial do elixir adversario.

## O que foi iniciado

- Arquitetura modular de captura, visao, estado, estrategia e HUD.
- Modo GUIA manual: o app sugere; voce confirma e faz os toques.
- `OpponentPlayObserver`: conecta unidades inimigas recém-confirmadas ao estimador de elixir. Usa faixas para classes ambíguas, deduplica enxames e ignora unidades geradas por outras cartas. A estimativa é parcial e supõe regeneração normal.
- Testes automatizados do estimador.

## O que ainda não está pronto

- Este pacote ainda não é APK instalável.
- O serviço existente continua sem enviar gestos automáticos (`canPerformGestures=false`).
- O leitor da mao depende das amostras RGB e pode retornar `?`.
- O modelo de tropas e a estratégia precisam ser validados com replays e partidas de teste no POCO X6 Pro.

## Testes locais executados

Com Java 21, foram compiladas as classes puras e executados:

- `AdviceTest`: 120.960 casos de orçamento, função de carta e geometria.
- `DeckProfileTest`: custos, ids e papéis das oito cartas.
- `StrategyTest`: defesa nos dois lados, custo, papéis, cooldown, preparação ofensiva e confirmação por frame.
- `OpponentElixirTrackerTest` e `OpponentPlayObserverTest`: regeneração, custos intervalares, deduplicação e filtro de unidades geradas.
- `VisionDeckFilterTest`: impede que cartas fora do Deck 4 sejam sugeridas como próxima carta.

Todos passaram. Os testes não comprovam funcionamento Android nem força de jogo equivalente a um jogador profissional.

## Próximo marco

Compilar o APK pelo GitHub Actions, instalar no POCO X6 Pro e validar captura, mao, tropas, setas e latencia em treino. Esta versao nao habilita gestos automaticos.


## Seu deck configurado

O perfil inicial é o Deck 4 da imagem enviada: Corredor, Cavaleiro Herói, Mosqueteira, Esqueletos, Tesla, Príncipe das Trevas, Barril de Goblins e Espírito de Gelo (média 3,0). O guia prioriza Corredor como pressão principal, mantém as cartas defensivas como reserva e não recomenda Barril de Goblins sem conhecer a resposta de feitiço do adversário.

Teste recomendado: inicie o guia antes da primeira jogada inimiga, em batalha amistosa/treino. Confirme as quatro cartas, a leitura do elixir, as tropas e as setas. O elixir rival supoe 5 no inicio do guia e regeneracao normal; nao confie na faixa se iniciar no meio da partida.


A leitura da mão e da próxima carta agora considera somente as oito identidades do Deck 4 configurado. A qualidade real só pode ser confirmada quando o app capturar a mão na tela de batalha.
